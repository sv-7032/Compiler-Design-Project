#include "compiler.h"
#include "optimizer.h"
#include "codegen.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

typedef struct { Grammar g; SLRTable t; } Frontend;
typedef struct { int quiet, tables; } Opts;

static double numeric(Operand o) { return o.d == T_INT ? (double)o.i : o.f; }
static void section(int n, const char *title)
{
    printf("\n==============================================================================\n [%d] %s\n==============================================================================\n", n, title);
}

/* Parser generation: grammar -> LR(0) item sets -> SLR(1) ACTION/GOTO tables (with conflict detection). */
static int frontend_build(Frontend *f)
{
    if (grammar_load_compiler(&f->g) != 0) { fprintf(stderr, "Could not initialize grammar\n"); return 0; }
    if (slr_generate(&f->t, &f->g) != 0) { fprintf(stderr, "SLR table generation failed\n"); return 0; }
    return 1;
}

static void print_table_report(const Frontend *f)
{
    const SLRTable *t = &f->t; int sh = 0, rd = 0, ac = 0, go = 0, sr = 0, rr = 0, ot = 0;
    for (int s = 0; s < t->num_states; s++)
        for (int x = 0; x < f->g.num_symbols; x++) {
            if (f->g.symbols[x].is_terminal) { Action a = slr_get_action(t, s, x); sh += a.type == ACTION_SHIFT; rd += a.type == ACTION_REDUCE; ac += a.type == ACTION_ACCEPT; }
            else if (slr_get_goto(t, s, x) >= 0) go++;
        }
    for (int i = 0; i < slr_conflict_count(t); i++) {
        ConflictType c = slr_get_conflict(t, i)->type;
        sr += c == CONFLICT_SHIFT_REDUCE; rr += c == CONFLICT_REDUCE_REDUCE; ot += c == CONFLICT_OTHER;
    }
    section(2, "GRAMMAR AND PRODUCTION RULES");
    slr_print_grammar(t); printf("\n"); slr_print_first_follow(t);
    section(3, "LR(0) ITEM SETS AND PARSING STATES");
    slr_print_states(t);
    section(4, "GENERATED ACTION AND GOTO PARSING TABLES (SLR(1))");
    slr_print_action_table(t); printf("\n"); slr_print_goto_table(t);
    printf("\n%d states | ACTION entries: %d shift, %d reduce, %d accept | GOTO entries: %d\n", t->num_states, sh, rd, ac, go);
    section(5, "CONFLICT DETECTION RESULTS");
    slr_print_conflicts(t);
    printf("\nShift/reduce conflicts: %d | Reduce/reduce conflicts: %d | Other: %d\n", sr, rr, ot);
    printf("Parsing table is %s.\n", slr_is_slr1(t) ? "CONFLICT-FREE (the grammar is SLR(1))" : "NOT conflict-free");
}

/* returns 1 = accepted and all phases agree, 0 = accepted but a later phase disagreed, -1 = syntax error */
static int run_one(const char *src, const Frontend *f, const Opts *o, int first)
{
    Token tokens[2048]; IR original, optimized; Target target; ReductionHistory hist; ParseSummary sum;
    const Grammar *g = &f->g; const SLRTable *table = &f->t; int v = !o->quiet;
    size_t n = lexer_tokenize(src, tokens, sizeof tokens / sizeof tokens[0]);
    if (n == 0 || n >= sizeof tokens / sizeof tokens[0]) { fprintf(stderr, "Input exceeds token buffer\n"); return 0; }

    if (v) { section(1, "INPUT EXPRESSION AND TOKEN STREAM"); printf("Input: %s\n\n", src); compiler_print_tokens(tokens, (int)n); }
    if (v && o->tables && first) print_table_report(f);
    else if (v && o->tables) printf("\n[2]-[5] Grammar, LR item sets, ACTION/GOTO tables and conflict report: same generated table as printed for the first expression.\n");

    ir_init(&original); reduction_init(&hist);                       /* fresh IR and fresh reduction history per expression */
    if (v) { section(6, "STEP-BY-STEP SHIFT-REDUCE PARSING TRACE"); }
    compiler_parse(g, table, tokens, (int)n, &original, &hist, &sum, v);
    if (v) { section(7, "COMPLETE REDUCTION HISTORY"); reduction_print(&hist, stdout); compiler_print_derivation(g, &hist); }

    section(8, "FINAL SYNTAX ANALYSIS RESULT");
    if (!sum.accepted) {
        printf("Input: %s\nResult: REJECTED - syntax error at token #%d '%s' (parser state %d)\n", src, sum.err_pos + 1, sum.err_token, sum.err_state);
        printf("Expected one of: %s\nParser actions before the error: %d steps (%d shifts, %d reductions)\n", sum.expected[0] ? sum.expected : "(none)", sum.steps, sum.shifts, sum.reduces);
        printf("\n[9]-[11] Skipped: no successful parse, so no intermediate code is generated.\n");
        reduction_free(&hist); ir_free(&original); return -1;
    }
    printf("Input: %s\nResult: ACCEPTED - valid expression\n", src);
    printf("Parser actions: %d steps = %d shifts + %d reductions + 1 accept\n", sum.steps, sum.shifts, sum.reduces);
    printf("Result type: %s\n", sum.result.d == T_INT ? "int" : "float");

    ir_finish(&original, sum.result); ir_copy(&optimized, &original);
    section(9, "THREE-ADDRESS CODE GENERATION");
    printf("TAC emitted by semantic actions attached to reductions:\n"); reduction_print_emitters(&hist, stdout);
    ir_print(&original, "Generated TAC");

    section(10, "CODE OPTIMIZATION RESULTS (supporting phase)");
    OptStats stats = opt_run(&optimized, 0); opt_print(&optimized, &stats);

    section(11, "TARGET CODE GENERATION RESULTS (supporting phase)");
    cg_generate(&optimized, &target); cg_print(&target);
    double a = numeric(ir_eval(&original)), b = numeric(ir_eval(&optimized)), c = numeric(cg_run(&target));
    int ok = fabs(a - b) < 1e-9 && fabs(a - c) < 1e-9;
    printf("\nCheck: original TAC = %.12g | optimized TAC = %.12g | target machine = %.12g -> %s\n", a, b, c, ok ? "PASS" : "FAIL (results disagree)");
    reduction_free(&hist); ir_free(&original); ir_free(&optimized); cg_free(&target); return ok;
}

/* Conflict detection on two deliberately non-SLR(1) grammars (the compiler grammar itself is conflict-free). */
static int conflict_demo(void)
{
    static const struct { const char *title, *terms, *rules[4][2]; int n; } demos[] = {
        {"Ambiguous grammar:  E -> E PLUS E | ID", "PLUS ID", {{"E", "E PLUS E"}, {"E", "ID"}}, 2},
        {"Reduce/reduce grammar:  S -> A | B ; A -> ID ; B -> ID", "ID", {{"S", "A"}, {"S", "B"}, {"A", "ID"}, {"B", "ID"}}, 4}};
    int found = 0;
    for (size_t d = 0; d < 2; d++) {
        Grammar g; SLRTable t; char terms[64], *tok;
        grammar_init(&g); snprintf(terms, sizeof terms, "%s", demos[d].terms);
        for (tok = strtok(terms, " "); tok; tok = strtok(NULL, " ")) grammar_add_terminal(&g, tok);
        for (int i = 0; i < demos[d].n; i++) grammar_add_rule(&g, demos[d].rules[i][0], demos[d].rules[i][1]);
        if (slr_generate(&t, &g) != 0) return 0;
        printf("\n--- %s ---\n", demos[d].title);
        slr_print_grammar(&t); printf("\n"); slr_print_action_table(&t); printf("\n"); slr_print_conflicts(&t);
        found += slr_conflict_count(&t) > 0; slr_free(&t);
    }
    printf("\nCONFLICT DEMO: %s\n", found == 2 ? "conflicts reported for both grammars" : "unexpected result");
    return found == 2;
}

int main(int argc, char **argv)
{
    Opts o = {0, 1}; int demo = 0, cdemo = 0; const char *expr = NULL; Frontend f;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--quiet")) o.quiet = 1;
        else if (!strcmp(argv[i], "--table")) o.tables = 1;
        else if (!strcmp(argv[i], "--no-table")) o.tables = 0;
        else if (!strcmp(argv[i], "--demo")) demo = 1;
        else if (!strcmp(argv[i], "--conflict-demo")) cdemo = 1;
        else if (!expr) expr = argv[i];
        else { fprintf(stderr, "Quote the expression, e.g. ./mini_compiler \"3 + 5 * 2\"\n"); return 2; }
    }
    if (cdemo) return conflict_demo() ? 0 : 1;
    if (!frontend_build(&f)) return 1;
    if (!slr_is_slr1(&f.t)) { section(5, "CONFLICT DETECTION RESULTS"); slr_print_conflicts(&f.t); fprintf(stderr, "Compiler grammar has conflicts; parsing aborted.\n"); slr_free(&f.t); return 1; }
    int status;
    if (demo) {
        static const struct { const char *src; int valid; } tests[] = {
            {"3 + 5 * 2", 1}, {"-(4 + 6) * 2", 1}, {"5 & 3 | 2", 1}, {"3.5 + 2 * 4", 1}, {"~~5", 1}, {"8 / 2 + 3", 1},
            {"-3 * +4", 1}, {"(1 + 2) * (3 + 4)", 1}, {"10 - 4 - 3", 1}, {"3 + * 5", 0}, {"(3 + 4", 0}};
        int all = 1, acc = 0, rej = 0;
        for (size_t i = 0; i < sizeof tests / sizeof tests[0]; i++) {
            printf("\n################ TEST %zu: %s ################\n", i + 1, tests[i].src);
            int r = run_one(tests[i].src, &f, &o, i == 0);
            if (tests[i].valid) { all &= r == 1; acc += r == 1; } else { all &= r == -1; rej += r == -1; }
        }
        printf("\nDEMO SUMMARY: %s (%d valid expressions parsed and verified, %d invalid expressions rejected as expected)\n", all ? "ALL PASS" : "ONE OR MORE FAILURES", acc, rej);
        status = all ? 0 : 1;
    } else {
        if (!expr) expr = "3 + 5 * 2";
        status = run_one(expr, &f, &o, 1) == 1 ? 0 : 1;
    }
    slr_free(&f.t);
    return status;
}
