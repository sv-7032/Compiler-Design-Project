# Integration Audit Report

## Summary

The four ZIP submissions were individually inspected, built where a Makefile was provided, and then combined into a single project. The integrated compiler now uses a runtime-generated SLR(1) table, performs table-driven shift-reduce parsing, records reductions, generates TAC, optimizes TAC, and translates optimized TAC to a custom target instruction set.

## Main integration problems found

1. **Two incompatible grammar APIs.** Member 1 and Member 2 both supplied `grammar.h/.c`, but they use different structure layouts and symbol-ID schemes. Both cannot be compiled into the same program as-is.
2. **Member 3 was a standalone parser demonstration.** Its Makefile used a test lexer and a stub SLR table instead of the real lexer and table generator. Its local grammar/token enums were not the same types as Member 1's lexer or Member 2's dynamic grammar symbols.
3. **Member 3's TAC interface was a stub.** Its `tac.c` stored formatted strings and did not match Member 4's structured IR interface.
4. **Member 4's main program was a backend test harness.** It built sample IR programmatically; it did not receive TAC from the parser.
5. **The modules used different symbol representations.** The lexer uses an enum for token kinds; the SLR generator uses grammar symbol IDs; the parser stub uses another terminal/non-terminal encoding.

## Integration changes

- Kept Member 1's hand-written lexer.
- Used Member 2's grammar representation and SLR(1) table generator as the single grammar/table API.
- Added a small token-to-grammar-terminal mapping by terminal name.
- Added an integrated table-driven parser that uses the generated ACTION/GOTO table and the shared production numbering.
- Reused Member 3's reduction-history implementation.
- Connected reductions directly to Member 4's structured TAC/IR API.
- Reused Member 4's optimizer and custom target-code generator.
- Replaced the standalone test `main.c` with a full compiler driver.
- Kept formal error recovery out of scope as requested.

## Verification performed

- Each original submission's supplied build/test path was inspected. Member 1's lexer/frontend test compiled and ran. Member 2's SLR tests reported 97 checks passed. Member 3's parser tests passed against its stubs, which did not prove integration with the real table generator. Member 4's standalone backend harness passed its listed backend cases.
- The integrated project builds with `-std=c99 -Wall -Wextra -pedantic`.
- The integrated demo verifies that original IR, optimized IR, and the target-machine simulator agree for the main arithmetic, unary/parentheses, bitwise, floating-point, unary-NOT, and division examples.
- Additional associativity, precedence, parenthesis, and float cases were tested.
- An AddressSanitizer/UndefinedBehaviorSanitizer build ran the integrated demo without runtime sanitizer reports.

## Known scope limitations

- The language accepts valid expressions only; formal error recovery is not implemented.
- Identifiers are not supported by the lexer/grammar. Member 4's backend can represent variables, but they are not part of the integrated source language.
- Bitwise operations are intended for integer operands. There is no semantic error subsystem for bitwise operations on floats.
- Target code is for a custom simulated machine, not native machine code.
- The parser semantic-action switch depends on the shared production numbering. If grammar production order changes, update the semantic-action mapping as well.

## Syntax-analyzer-focused revision

- Program output reorganized into 11 sections with the parser first: tokens, grammar, LR item sets, ACTION/GOTO tables, conflict report, shift-reduce trace, reduction history, final result, then TAC, optimization and target code (the last two are brief).
- Trace rows now show the explicit state/symbol stack, remaining input, action (`sN`, `rN`, `acc`, `err`) and, for reductions, the pop count and the GOTO lookup used.
- Reduction history records stack before/after, the remaining input and the TAC emitted by each reduction; a rightmost derivation is rebuilt from the recorded reductions.
- Conflicts are counted by kind in the output; `--conflict-demo` runs the real table generator on non-SLR(1) grammars to show a populated conflict report.
- Syntax errors are reported with the offending token, state and expected terminals; downstream phases are skipped.
- `compiler_parse` now takes a caller-owned `ReductionHistory` and returns a `ParseSummary`; the table is generated once per run and the stack, history and IR are re-initialized for every expression.
- Optimizer, target-code generator, lexer, grammar and table-generation algorithms are unchanged (optimizer round-by-round printing is no longer shown by default).
- Verified: 97 table-generator checks; 9 valid and 2 invalid demo expressions; clean build with `-Wall -Wextra -pedantic`; ASan/UBSan run of the full demo and conflict demo with no reports.
