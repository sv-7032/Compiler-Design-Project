#include "compiler.h"
#include "reduction.h"
#include <stdio.h>
#include <string.h>

#define PARSER_STACK_MAX 4096
typedef struct { int state; int symbol; Operand value; } ParseEntry;
typedef struct { ParseEntry entries[PARSER_STACK_MAX]; int n; } ParseStack;

static const char *lexer_symbol_names[TOK_TERMINAL_COUNT] = {
    "INT_CONST", "FLOAT_CONST", "PLUS", "MINUS", "STAR", "SLASH",
    "AMP", "PIPE", "CARET", "TILDE", "LPAREN", "RPAREN", "$"
};

int compiler_token_terminal(const Grammar *g, TokenType type)
{
    if (type < 0 || type >= TOK_TERMINAL_COUNT) return -1;
    return grammar_find_symbol(g, lexer_symbol_names[type]);
}

void compiler_print_tokens(const Token *tokens, int n)
{
    printf("%-4s %-24s %s\n", "#", "Token", "Position");
    for (int i = 0; i < n; i++) {
        char b[128]; token_format(&tokens[i], b, sizeof b);
        printf("%-4d %-24s %d:%d\n", i + 1, b, tokens[i].line, tokens[i].column);
        if (tokens[i].type == TOK_END_OF_INPUT) break;
    }
}

static void format_stack(const Grammar *g, const ParseStack *st, char *buf, size_t cap)
{
    size_t off = 0; buf[0] = '\0';
    for (int i = 0; i < st->n && off + 1 < cap; i++) {
        char piece[64];
        if (i == 0) snprintf(piece, sizeof piece, "%d", st->entries[i].state);
        else snprintf(piece, sizeof piece, " %s %d", g->symbols[st->entries[i].symbol].name, st->entries[i].state);
        int n = snprintf(buf + off, cap - off, "%s", piece);
        if (n < 0) break;
        off += (size_t)n;
    }
}

static void format_input(const Token *tokens, int n, int pos, char *buf, size_t cap)
{
    size_t off = 0; buf[0] = '\0';
    for (int i = pos; i < n && off + 1 < cap; i++) {
        char piece[80];
        if (tokens[i].type == TOK_INTEGER || tokens[i].type == TOK_FLOAT) snprintf(piece, sizeof piece, "%s ", tokens[i].lexeme);
        else snprintf(piece, sizeof piece, "%s ", token_symbol(tokens[i].type));
        int w = snprintf(buf + off, cap - off, "%s", piece);
        if (w < 0) break;
        off += (size_t)w;
        if (tokens[i].type == TOK_END_OF_INPUT) break;
    }
}

static void format_production(const Grammar *g, int pno, char *buf, size_t cap)
{
    const Production *p = &g->prods[pno];
    int n = snprintf(buf, cap, "%s ->", g->symbols[p->lhs].name);
    for (int i = 0; i < p->rhs_len && n > 0 && (size_t)n < cap; i++)
        n += snprintf(buf + n, cap - (size_t)n, " %s", g->symbols[p->rhs[i]].name);
}

static void expected_terminals(const Grammar *g, const SLRTable *t, int state, char *buf, size_t cap)
{
    size_t off = 0; buf[0] = '\0';
    for (int s = 0; s < g->num_symbols; s++) {
        if (!g->symbols[s].is_terminal || slr_get_action(t, state, s).type == ACTION_ERROR) continue;
        int w = snprintf(buf + off, cap - off, "%s%s", off ? ", " : "", g->symbols[s].name);
        if (w < 0 || (size_t)w >= cap - off) break;
        off += (size_t)w;
    }
}

void compiler_print_derivation(const Grammar *g, const ReductionHistory *h)
{
    int form[256], nf = 1;
    if (!h->count) return;
    form[0] = g->prods[h->recs[h->count - 1].prod_no].lhs;
    printf("\nRightmost derivation (the reductions above, read from last to first):\n  %s\n", g->symbols[form[0]].name);
    for (int i = h->count - 1; i >= 0; i--) {
        const Production *p = &g->prods[h->recs[i].prod_no];
        int k = nf - 1;
        while (k >= 0 && g->symbols[form[k]].is_terminal) k--;
        if (k < 0 || form[k] != p->lhs || nf - 1 + p->rhs_len > 256) { puts("  (derivation check failed)"); return; }
        memmove(&form[k + p->rhs_len], &form[k + 1], (size_t)(nf - k - 1) * sizeof form[0]);
        memcpy(&form[k], p->rhs, (size_t)p->rhs_len * sizeof form[0]);
        nf += p->rhs_len - 1;
        printf("  => ");
        for (int j = 0; j < nf; j++) printf("%s%s", j ? " " : "", g->symbols[form[j]].name);
        printf("\n");
    }
}

int compiler_parse(const Grammar *g, const SLRTable *table, const Token *tokens, int ntokens,
                   IR *ir, ReductionHistory *hist, ParseSummary *sum, int verbose)
{
    ParseStack st; int pos = 0, step = 0;
    memset(&st, 0, sizeof st); memset(sum, 0, sizeof *sum); sum->err_pos = -1;
    st.entries[st.n++] = (ParseEntry){0, -1, {0}};
    if (verbose) {
        printf("%-5s %-6s %-46s %-30s %-6s %s\n", "Step", "State", "Parsing stack (state symbol state ...)", "Remaining input", "Action", "Description");
        puts("-------------------------------------------------------------------------------------------------------------------------------------");
    }
    while (step < 100000 && pos < ntokens) {
        const Token *tk = &tokens[pos];
        int term = compiler_token_terminal(g, tk->type);
        if (term < 0) { snprintf(sum->err_token, sizeof sum->err_token, "%s", token_name(tk->type)); sum->err_pos = pos; sum->err_state = st.entries[st.n - 1].state; break; }
        int state = st.entries[st.n - 1].state;
        Action a = slr_get_action(table, state, term);          /* every decision comes from the generated table */
        char sb[512], ib[512], ab[32], ob[200];
        format_stack(g, &st, sb, sizeof sb); format_input(tokens, ntokens, pos, ib, sizeof ib); ++step;
        if (a.type == ACTION_SHIFT) {
            snprintf(ab, sizeof ab, "s%d", a.value);
            snprintf(ob, sizeof ob, "SHIFT %s, push state %d", g->symbols[term].name, a.value);
            if (verbose) printf("%-5d %-6d %-46s %-30s %-6s %s\n", step, state, sb, ib, ab, ob);
            if (st.n >= PARSER_STACK_MAX) break;
            Operand v = {0};
            if (tk->type == TOK_INTEGER) v = ir_int(tk->int_value);
            else if (tk->type == TOK_FLOAT) v = ir_float(tk->float_value);
            st.entries[st.n++] = (ParseEntry){a.value, term, v};
            sum->shifts++;
            if (tk->type == TOK_END_OF_INPUT) break;
            ++pos;
        } else if (a.type == ACTION_REDUCE) {
            int pno = a.value;
            if (pno <= 0 || pno >= g->num_prods) { fprintf(stderr, "Invalid reduce production %d\n", pno); break; }
            const Production *p = &g->prods[pno]; int len = p->rhs_len;
            if (len < 0 || st.n <= len || len > 10) break;
            int gs = slr_get_goto(table, st.entries[st.n - 1 - len].state, p->lhs);
            char prodtext[192]; format_production(g, pno, prodtext, sizeof prodtext);
            snprintf(ab, sizeof ab, "r%d", pno);
            snprintf(ob, sizeof ob, "REDUCE %.80s : pop %d, GOTO[%d,%s]=%d", prodtext, len, st.entries[st.n - 1 - len].state, g->symbols[p->lhs].name, gs);
            if (verbose) printf("%-5d %-6d %-46s %-30s %-6s %s\n", step, state, sb, ib, ab, ob);
            Operand rhs[10] = {{0}}, out = {0}; int base = st.n - len, before = ir->n;
            for (int j = 0; j < len; j++) rhs[j] = st.entries[base + j].value;
            /* Semantic actions (TAC generation). Production numbering matches the shared grammar contract. */
            switch (pno) {
                case 1: out = ir_binary(ir, OP_OR, rhs[0], rhs[2], T_INT); break;
                case 2: out = rhs[0]; break;
                case 3: out = ir_binary(ir, OP_XOR, rhs[0], rhs[2], T_INT); break;
                case 4: out = rhs[0]; break;
                case 5: out = ir_binary(ir, OP_AND, rhs[0], rhs[2], T_INT); break;
                case 6: out = rhs[0]; break;
                case 7: out = ir_binary(ir, OP_ADD, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;
                case 8: out = ir_binary(ir, OP_SUB, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;
                case 9: out = rhs[0]; break;
                case 10: out = ir_binary(ir, OP_MUL, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;
                case 11: out = ir_binary(ir, OP_DIV, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;
                case 12: out = rhs[0]; break;
                case 13: out = rhs[1]; break;
                case 14: out = ir_unary(ir, OP_NEG, rhs[1], rhs[1].d); break;
                case 15: out = ir_unary(ir, OP_NOT, rhs[1], T_INT); break;
                case 16: out = rhs[0]; break;
                case 17: out = rhs[1]; break;
                case 18: out = rhs[0]; break;
                case 19: out = rhs[0]; break;
                default: fprintf(stderr, "No semantic action for production %d\n", pno); goto finish;
            }
            st.n -= len;
            if (gs < 0 || st.n >= PARSER_STACK_MAX) break;
            st.entries[st.n++] = (ParseEntry){gs, p->lhs, out};
            char after[512]; format_stack(g, &st, after, sizeof after);
            reduction_add(hist, pno, prodtext, sb, after, ib, ab);
            if (ir->n > before) {                               /* remember which reduction produced which TAC */
                char e[400] = "", one[160];
                for (int k = before; k < ir->n; k++) { ir_fmt_tac(&ir->code[k], one); snprintf(e + strlen(e), sizeof e - strlen(e), "%s%s", k > before ? " ; " : "", one); }
                reduction_set_emitted(hist, e);
            }
            sum->reduces++;
        } else if (a.type == ACTION_ACCEPT) {
            if (verbose) printf("%-5d %-6d %-46s %-30s %-6s %s\n", step, state, sb, ib, "acc", "ACCEPT: input is a valid sentence of the grammar");
            sum->result = st.entries[st.n - 1].value; sum->accepted = 1; break;
        } else {
            sum->err_pos = pos; sum->err_state = state;
            snprintf(sum->err_token, sizeof sum->err_token, "%s", token_symbol(tk->type));
            expected_terminals(g, table, state, sum->expected, sizeof sum->expected);
            if (verbose) printf("%-5d %-6d %-46s %-30s %-6s ERROR: ACTION[%d,%s] is blank\n", step, state, sb, ib, "err", state, g->symbols[term].name);
            break;
        }
    }
finish:
    sum->steps = step;
    return sum->accepted;
}
