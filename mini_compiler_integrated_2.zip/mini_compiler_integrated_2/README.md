# Mini Compiler (C99) - Shift-Reduce Syntax Analyzer with Intermediate Code Generation

**Primary contribution:** a table-driven shift-reduce (SLR(1)) syntax analyzer with an explicit parse stack,
reduction tracking, algorithmic parsing-table generation and conflict detection.
Three-address code (TAC) generation shows how successful parsing feeds the rest of the compiler;
the optimizer and the target-code generator are retained as supporting phases.

## Modules

| Role | Files |
| --- | --- |
| **Syntax analyzer (primary)** | `grammar.*` (grammar + augmentation), `lr_items.*` (LR(0) item sets, closure/goto), `syntax_table.*` (FIRST/FOLLOW, ACTION/GOTO generation, conflict detection), `compiler.c` (stack-based shift-reduce driver), `reduction.*` (reduction history) |
| Front end | `lexer.*` (hand-written lexer) |
| Intermediate code (supporting) | `ir.*` (TAC); semantic actions run inside the parser's reduce step |
| Optimization / target code (supporting) | `optimizer.*`, `codegen.*` |

Every parser decision is `slr_get_action()` / `slr_get_goto()` on the generated table; nothing in the driver is hard-coded
to a particular input. Each expression gets a fresh parse stack, reduction history and TAC buffer.

## Build and test

```sh
make          # builds ./mini_compiler
make test     # table-generator unit tests (97 checks) + demo of 9 valid and 2 invalid expressions + conflict demo
```

## Run

```sh
./mini_compiler "3 + 5 * 2"          # full 11-section output
./mini_compiler --no-table "3 + 5 * 2"   # skip sections 2-5 (grammar, item sets, tables, conflicts)
./mini_compiler --quiet "3 + 5 * 2"      # only sections 8-11 (result, TAC, optimization, target code)
./mini_compiler --demo [--quiet]         # representative expressions, incl. two syntax errors
./mini_compiler --conflict-demo          # conflict detection on two deliberately non-SLR(1) grammars
```

## Output order

1. Input expression and token stream
2. Grammar and production rules (plus FIRST/FOLLOW)
3. LR(0) item sets and parsing states
4. Generated ACTION and GOTO tables (with entry counts)
5. Conflict detection results (shift/reduce, reduce/reduce; conflict-free or not)
6. Step-by-step shift-reduce trace: stack, remaining input, action (shift / reduce / accept / error)
7. Complete reduction history: production, stack before => after, emitted TAC, and the rightmost derivation rebuilt from the reductions
8. Final syntax analysis result (accepted/rejected, step counts; on error: token, state and expected terminals)
9. Three-address code, with the reduction that emitted each instruction
10. Code optimization results (brief)
11. Target code generation results (brief), plus a consistency check of original TAC, optimized TAC and the target-machine simulator

With `--demo`, sections 2-5 are printed once (first expression); every expression still gets its own 1 and 6-11.
On a syntax error, sections 9-11 are skipped because there is no valid parse to translate.

## Language and assumptions

Integer and floating-point constants; binary `+ - * /`, `& | ^`; unary `+ - ~`; parentheses.
Precedence, high to low: parentheses, unary `+ - ~`, `* /`, `+ -`, `&`, `^`, `|`; binary operators are left-associative.
No formal error recovery (the parser reports the first error and stops); integer division truncates; mixed arithmetic promotes to float;
bitwise operators are intended for integer operands; target code is for a custom simulated register machine.
If the grammar is edited, update the semantic-action `switch` in `compiler.c`, which is keyed on production numbers.
