/* grammar.c -- see grammar.h */
#include "grammar.h"
#include <stdio.h>
#include <string.h>

void grammar_init(Grammar *g)
{
    memset(g, 0, sizeof *g);
    g->start_symbol = -1;
    g->aug_start    = -1;

    strcpy(g->symbols[SYM_END].name, "$");
    g->symbols[SYM_END].is_terminal = 1;
    g->num_symbols = 1;

    g->prods[0].lhs = -1;          /* slot 0 reserved for S' -> S */
    g->num_prods = 1;
}

int grammar_find_symbol(const Grammar *g, const char *name)
{
    for (int i = 0; i < g->num_symbols; i++)
        if (strcmp(g->symbols[i].name, name) == 0)
            return i;
    return -1;
}

static int add_symbol(Grammar *g, const char *name, int is_terminal)
{
    size_t len = strlen(name);
    if (len == 0 || len >= MAX_NAME) return -1;

    int id = grammar_find_symbol(g, name);
    if (id >= 0)                                   /* already declared */
        return (g->symbols[id].is_terminal == is_terminal) ? id : -1;

    if (g->num_symbols >= MAX_SYMBOLS) return -1;
    id = g->num_symbols++;
    strcpy(g->symbols[id].name, name);
    g->symbols[id].is_terminal = is_terminal;
    return id;
}

int grammar_add_terminal(Grammar *g, const char *name)    { return add_symbol(g, name, 1); }
int grammar_add_nonterminal(Grammar *g, const char *name) { return add_symbol(g, name, 0); }

int grammar_add_production(Grammar *g, int lhs, const int *rhs, int rhs_len)
{
    if (g->augmented) return -1;
    if (lhs <= 0 || lhs >= g->num_symbols || g->symbols[lhs].is_terminal) return -1;
    if (rhs_len < 0 || rhs_len > MAX_RHS || g->num_prods >= MAX_PRODUCTIONS) return -1;
    for (int i = 0; i < rhs_len; i++)
        if (rhs[i] <= 0 || rhs[i] >= g->num_symbols) return -1;   /* '$' is not allowed in a rhs */

    int p = g->num_prods++;
    g->prods[p].lhs = lhs;
    g->prods[p].rhs_len = rhs_len;
    for (int i = 0; i < rhs_len; i++) g->prods[p].rhs[i] = rhs[i];

    if (g->start_symbol < 0) g->start_symbol = lhs;    /* first rule defines the start symbol */
    return p;
}

/* split "A B  C" into words; returns the count or -1 if too long / too many */
static int split_words(const char *text, char words[][MAX_NAME], int max)
{
    int n = 0;
    const char *p = text;
    while (*p) {
        while (*p == ' ' || *p == '\t') p++;
        if (!*p) break;
        int len = 0;
        while (p[len] && p[len] != ' ' && p[len] != '\t') len++;
        if (len >= MAX_NAME || n >= max) return -1;
        memcpy(words[n], p, (size_t)len);
        words[n][len] = '\0';
        n++;
        p += len;
    }
    return n;
}

int grammar_add_rule(Grammar *g, const char *lhs_name, const char *rhs_text)
{
    char words[MAX_RHS][MAX_NAME];
    int ids[MAX_RHS];

    int n = split_words(rhs_text, words, MAX_RHS);
    if (n < 0) return -1;

    int lhs = grammar_find_symbol(g, lhs_name);
    if (lhs < 0) lhs = grammar_add_nonterminal(g, lhs_name);
    if (lhs < 0) return -1;

    for (int i = 0; i < n; i++) {
        ids[i] = grammar_find_symbol(g, words[i]);
        if (ids[i] < 0) ids[i] = grammar_add_nonterminal(g, words[i]);   /* forward reference */
        if (ids[i] < 0) return -1;
    }
    return grammar_add_production(g, lhs, ids, n);
}

int grammar_find_rule(const Grammar *g, const char *lhs_name, const char *rhs_text)
{
    char words[MAX_RHS][MAX_NAME];
    int ids[MAX_RHS];

    int n = split_words(rhs_text, words, MAX_RHS);
    if (n < 0) return -1;
    int lhs = grammar_find_symbol(g, lhs_name);
    if (lhs < 0) return -1;
    for (int i = 0; i < n; i++) {
        ids[i] = grammar_find_symbol(g, words[i]);
        if (ids[i] < 0) return -1;
    }
    for (int p = 1; p < g->num_prods; p++) {
        const Production *pr = &g->prods[p];
        if (pr->lhs != lhs || pr->rhs_len != n) continue;
        int same = 1;
        for (int i = 0; i < n; i++)
            if (pr->rhs[i] != ids[i]) { same = 0; break; }
        if (same) return p;
    }
    return -1;
}

int grammar_augment(Grammar *g)
{
    if (g->augmented) return 0;
    if (g->start_symbol < 0) {
        fprintf(stderr, "grammar_augment: grammar has no productions\n");
        return -1;
    }

    /* every non-terminal must be defined by at least one production */
    for (int s = 1; s < g->num_symbols; s++) {
        if (g->symbols[s].is_terminal) continue;
        int defined = 0;
        for (int p = 1; p < g->num_prods; p++)
            if (g->prods[p].lhs == s) { defined = 1; break; }
        if (!defined) {
            fprintf(stderr, "grammar_augment: non-terminal '%s' has no productions "
                            "(misspelled or undeclared terminal?)\n", g->symbols[s].name);
            return -1;
        }
    }

    char name[MAX_NAME];
    snprintf(name, sizeof name, "%.*s'", MAX_NAME - 2, g->symbols[g->start_symbol].name);
    int aug = grammar_add_nonterminal(g, name);
    if (aug < 0) return -1;

    g->aug_start = aug;
    g->prods[0].lhs = aug;
    g->prods[0].rhs_len = 1;
    g->prods[0].rhs[0] = g->start_symbol;
    g->augmented = 1;
    return 0;
}

void grammar_print_production(const Grammar *g, int p)
{
    const Production *pr = &g->prods[p];
    printf("%s ->", g->symbols[pr->lhs].name);
    if (pr->rhs_len == 0) printf(" (epsilon)");
    for (int i = 0; i < pr->rhs_len; i++)
        printf(" %s", g->symbols[pr->rhs[i]].name);
}

void grammar_print(const Grammar *g)
{
    printf("Terminals   :");
    for (int s = 0; s < g->num_symbols; s++)
        if (g->symbols[s].is_terminal) printf(" %s", g->symbols[s].name);
    printf("\nNon-terminals:");
    for (int s = 0; s < g->num_symbols; s++)
        if (!g->symbols[s].is_terminal) printf(" %s", g->symbols[s].name);
    printf("\nStart symbol : %s\n", g->start_symbol >= 0 ? g->symbols[g->start_symbol].name : "(none)");
    printf("Productions%s:\n", g->augmented ? " (0 = augmented)" : "");
    for (int p = g->augmented ? 0 : 1; p < g->num_prods; p++) {
        printf("  [%2d] ", p);
        grammar_print_production(g, p);
        printf("\n");
    }
}

/* ------------------------------------------------------------------------- */
/*  The compiler's expression grammar (Member 1's deliverable)               */
/*                                                                           */
/*  Precedence is encoded in the grammar itself (one level per operator      */
/*  class, lowest first), so no precedence declarations are needed and the   */
/*  grammar is unambiguous.  Binary operators are left-associative.          */
/*                                                                           */
/*      Expr   : |          (bitwise OR,  lowest)                            */
/*      Xor    : ^                                                           */
/*      And    : &                                                           */
/*      Sum    : + -                                                         */
/*      Term   : * /                                                         */
/*      Unary  : + - ~      (prefix, right-recursive)                        */
/*      Factor : ( Expr ) | INT_CONST | FLOAT_CONST     (highest)            */
/* ------------------------------------------------------------------------- */
int grammar_load_compiler(Grammar *g)
{
    static const char *terminals[] = {
        "PLUS", "MINUS", "STAR", "SLASH", "AMP", "PIPE", "CARET", "TILDE",
        "LPAREN", "RPAREN", "INT_CONST", "FLOAT_CONST"
    };
    static const char *rules[][2] = {
        { "Expr",   "Expr PIPE Xor"            },
        { "Expr",   "Xor"                      },
        { "Xor",    "Xor CARET And"            },
        { "Xor",    "And"                      },
        { "And",    "And AMP Sum"              },
        { "And",    "Sum"                      },
        { "Sum",    "Sum PLUS Term"            },
        { "Sum",    "Sum MINUS Term"           },
        { "Sum",    "Term"                     },
        { "Term",   "Term STAR Unary"          },
        { "Term",   "Term SLASH Unary"         },
        { "Term",   "Unary"                    },
        { "Unary",  "PLUS Unary"               },
        { "Unary",  "MINUS Unary"              },
        { "Unary",  "TILDE Unary"              },
        { "Unary",  "Factor"                   },
        { "Factor", "LPAREN Expr RPAREN"       },
        { "Factor", "INT_CONST"                },
        { "Factor", "FLOAT_CONST"              },
    };

    grammar_init(g);
    for (size_t i = 0; i < sizeof terminals / sizeof terminals[0]; i++)
        if (grammar_add_terminal(g, terminals[i]) < 0) return -1;
    for (size_t i = 0; i < sizeof rules / sizeof rules[0]; i++)
        if (grammar_add_rule(g, rules[i][0], rules[i][1]) < 0) return -1;
    return 0;
}
