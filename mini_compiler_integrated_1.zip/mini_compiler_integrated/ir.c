#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "ir.h"

static const char *SYM[] = {"+", "-", "*", "/", "&", "|", "^", "~", "-", "+", "(float) ", ""};
static struct { char name[16]; Operand val; } VT[32];
static int nvars;

Operand ir_int(long long v) { Operand o = {0}; o.k = K_CONST; o.d = T_INT; o.i = (int32_t)v; return o; }
Operand ir_float(double v) { Operand o = {0}; o.k = K_CONST; o.d = T_FLOAT; o.f = v; return o; }

Operand ir_var(const char *name, DType d) {
    Operand o = {0};
    int i;
    for (i = 0; i < nvars && strcmp(VT[i].name, name); i++);
    if (i == 32) i = 31;
    if (i == nvars) { strncpy(VT[i].name, name, 15); nvars++; }
    o.k = K_VAR; o.d = d; o.t = i;
    return o;
}

void ir_bind(Operand v, Operand val) { VT[v.t].val = val; }
const char *ir_var_name(int id) { return VT[id].name; }
Operand ir_var_get(int id) { return VT[id].val; }
DType ir_promote(DType a, DType b) { return (a == T_FLOAT || b == T_FLOAT) ? T_FLOAT : T_INT; }

void ir_init(IR *ir) { *ir = (IR){0}; }
void ir_free(IR *ir) { free(ir->code); *ir = (IR){0}; }

void ir_copy(IR *dst, const IR *src) {
    *dst = *src;
    dst->cap = src->n ? src->n : 1;
    dst->code = malloc(dst->cap * sizeof(TAC));
    memcpy(dst->code, src->code, src->n * sizeof(TAC));
}

void ir_delete(IR *ir, int idx) {
    memmove(&ir->code[idx], &ir->code[idx + 1], (ir->n - idx - 1) * sizeof(TAC));
    ir->n--;
}

static Operand emit(IR *ir, Op op, Form f, Operand a, Operand b, DType ty) {
    TAC *c;
    Operand r = {0};
    if (ir->n == ir->cap) {
        ir->cap = ir->cap ? ir->cap * 2 : 16;
        ir->code = realloc(ir->code, ir->cap * sizeof(TAC));
    }
    c = &ir->code[ir->n++];
    c->op = op; c->form = f; c->a = a; c->b = b; c->type = ty; c->res = ++ir->ntemp;
    r.k = K_TEMP; r.d = ty; r.t = c->res;
    return r;
}

static Operand conv(IR *ir, Operand o, DType ty) {
    if (ty == T_FLOAT && o.d == T_INT) {
        if (o.k == K_CONST) return ir_float((double)o.i);
        return emit(ir, OP_ITOF, F_UNARY, o, (Operand){0}, T_FLOAT);
    }
    return o;
}

Operand ir_binary(IR *ir, Op op, Operand l, Operand r, DType ty) {
    l = conv(ir, l, ty);
    r = conv(ir, r, ty);
    return emit(ir, op, F_BINARY, l, r, ty);
}

Operand ir_unary(IR *ir, Op op, Operand a, DType ty) {
    a = conv(ir, a, ty);
    return op == OP_POS ? a : emit(ir, op, F_UNARY, a, (Operand){0}, ty);
}

void ir_finish(IR *ir, Operand top) {
    if (top.k == K_TEMP && ir->n && ir->code[ir->n - 1].res == top.t) return;
    emit(ir, OP_ASSIGN, F_ASSIGN, top, (Operand){0}, top.d);
}

Operand ir_result(const IR *ir) {
    Operand r = {0};
    if (ir->n) { r.k = K_TEMP; r.d = ir->code[ir->n - 1].type; r.t = ir->code[ir->n - 1].res; }
    return r;
}

static long long iv(Operand o) { return o.d == T_INT ? o.i : (long long)o.f; }
static double dv(Operand o) { return o.d == T_FLOAT ? o.f : (double)o.i; }

int ir_apply(Op op, DType ty, Operand a, Operand b, Operand *out) {
    if (ty == T_INT) {
        uint32_t x = (uint32_t)iv(a), y = (uint32_t)iv(b), r;
        switch (op) {
        case OP_ADD: r = x + y; break;
        case OP_SUB: r = x - y; break;
        case OP_MUL: r = x * y; break;
        case OP_DIV:
            if (!y) return 0;
            r = ((int32_t)x == INT32_MIN && (int32_t)y == -1) ? x : (uint32_t)((int32_t)x / (int32_t)y);
            break;
        case OP_AND: r = x & y; break;
        case OP_OR: r = x | y; break;
        case OP_XOR: r = x ^ y; break;
        case OP_NOT: r = ~x; break;
        case OP_NEG: r = 0u - x; break;
        case OP_POS: case OP_ASSIGN: r = x; break;
        default: return 0;
        }
        *out = ir_int((int32_t)r);
        return 1;
    } else {
        double x = dv(a), y = dv(b), r;
        switch (op) {
        case OP_ADD: r = x + y; break;
        case OP_SUB: r = x - y; break;
        case OP_MUL: r = x * y; break;
        case OP_DIV: if (y == 0.0) return 0; r = x / y; break;
        case OP_NEG: r = -x; break;
        case OP_POS: case OP_ASSIGN: case OP_ITOF: r = x; break;
        default: return 0;
        }
        *out = ir_float(r);
        return 1;
    }
}

Operand ir_eval(const IR *ir) {
    Operand *v = calloc(ir->ntemp + 1, sizeof *v), r = {0};
    for (int i = 0; i < ir->n; i++) {
        const TAC *c = &ir->code[i];
        Operand a = c->a, b = c->b, o = {0};
        if (a.k == K_TEMP) a = v[a.t]; else if (a.k == K_VAR) a = VT[a.t].val;
        if (b.k == K_TEMP) b = v[b.t]; else if (b.k == K_VAR) b = VT[b.t].val;
        ir_apply(c->op, c->type, a, b, &o);
        v[c->res] = r = o;
    }
    free(v);
    return r;
}

void ir_fmt_double(char *b, double v) {
    sprintf(b, "%.6g", v);
    if (!strpbrk(b, ".eEn")) strcat(b, ".0");
}

void ir_fmt(char *b, Operand o) {
    if (o.k == K_TEMP) sprintf(b, "t%d", o.t);
    else if (o.k == K_VAR) sprintf(b, "%s", VT[o.t].name);
    else if (o.k == K_NONE) b[0] = 0;
    else if (o.d == T_INT) sprintf(b, "%lld", o.i);
    else ir_fmt_double(b, o.f);
}

void ir_print(const IR *ir, const char *title) {
    char a[48], b[48], line[160];
    printf("\n--- %s ---\n", title);
    if (!ir->n) printf("  (empty)\n");
    for (int i = 0; i < ir->n; i++) {
        const TAC *c = &ir->code[i];
        ir_fmt(a, c->a);
        ir_fmt(b, c->b);
        if (c->form == F_BINARY) sprintf(line, "t%d = %s %s %s", c->res, a, SYM[c->op], b);
        else sprintf(line, "t%d = %s%s", c->res, SYM[c->op], a);
        printf("  %-30s [%s]\n", line, c->type == T_INT ? "int" : "float");
    }
}
