/*
 * syntax_table.h  --  FIRST/FOLLOW sets and the SLR(1) ACTION/GOTO table.
 *
 * PUBLIC INTERFACE FOR MEMBER 3 (the shift-reduce parser)
 * -------------------------------------------------------
 *     Grammar  g;
 *     SLRTable t;
 *     grammar_load_compiler(&g);              // Member 1
 *     if (slr_generate(&t, &g) != 0) ...      // init + states + tables
 *     if (!slr_is_slr1(&t)) ...               // optional: refuse a conflicting grammar
 *
 *     Action a = slr_get_action(&t, state, terminal_id);
 *       a.type == ACTION_SHIFT   -> push state a.value, consume the token
 *       a.type == ACTION_REDUCE  -> production a.value: pop slr_prod_length() states,
 *                                   then push slr_get_goto(&t, top, slr_prod_lhs())
 *       a.type == ACTION_ACCEPT  -> input accepted
 *       a.type == ACTION_ERROR   -> syntax error
 *
 *     Token ids: terminal_id is the grammar symbol id, i.e.
 *         grammar_find_symbol(&g, "PLUS");  and  SYM_END for end of input ($).
 *
 * ALGORITHM (SLR(1) table construction)
 * -------------------------------------
 * For every state I of the LR(0) automaton:
 *   - item  A -> alpha . a beta   (a terminal)  =>  ACTION[I, a]  = SHIFT GOTO(I, a)
 *   - item  A -> alpha .          (A != S')     =>  ACTION[I, t]  = REDUCE (A -> alpha)
 *                                                    for every t in FOLLOW(A)
 *   - item  S' -> S .                           =>  ACTION[I, $]  = ACCEPT
 *   - for every non-terminal B with GOTO(I, B) = J   =>  GOTO[I, B] = J
 * Everything left blank is ACTION_ERROR.
 * If a cell would receive two different actions, the first one is KEPT, nothing
 * is overwritten, and the clash is recorded as a conflict.  Shifts are written
 * before reductions within each state, so "existing" is normally the shift.
 * A grammar is SLR(1) exactly when no conflict is recorded.
 *
 * FIRST / FOLLOW
 *   nullable(A)  A =>* epsilon
 *   FIRST(X)     terminals that can begin a string derived from X
 *   FOLLOW(A)    terminals that can appear right after A in some sentential form
 *                (FOLLOW(S') = { $ })
 * All three are computed by repeating the defining rules until nothing changes.
 */
#ifndef SYNTAX_TABLE_H
#define SYNTAX_TABLE_H

#include <stdint.h>
#include "grammar.h"
#include "lr_items.h"

/* compile-time check: symbol sets are 64-bit masks */
typedef char syntax_table_needs_max_symbols_le_64[(MAX_SYMBOLS <= 64) ? 1 : -1];

/* ---------------------------------------------------------------- symbol sets */
typedef uint64_t SymSet;
#define SYMSET_BIT(x)    (((SymSet)1) << (x))
#define SYMSET_HAS(s, x) ((((s) >> (x)) & 1u) != 0)

typedef struct {
    SymSet first[MAX_SYMBOLS];
    SymSet follow[MAX_SYMBOLS];
    int    nullable[MAX_SYMBOLS];
} FirstFollow;

void first_follow_compute(const Grammar *g, FirstFollow *ff);
void first_follow_print(const Grammar *g, const FirstFollow *ff);

/* --------------------------------------------------------------------- actions */
typedef enum {
    ACTION_ERROR = 0,         /* blank cell = syntax error */
    ACTION_SHIFT,             /* value = destination state */
    ACTION_REDUCE,            /* value = production number */
    ACTION_ACCEPT             /* value unused              */
} ActionType;

typedef struct {
    ActionType type;
    int        value;
} Action;

/* ------------------------------------------------------------------- conflicts */
typedef enum {
    CONFLICT_SHIFT_REDUCE,
    CONFLICT_REDUCE_REDUCE,
    CONFLICT_OTHER            /* e.g. accept vs reduce */
} ConflictType;

typedef struct {
    ConflictType type;
    int    state;
    int    terminal;          /* lookahead symbol id           */
    Action existing;          /* action already in the cell (kept) */
    Action conflicting;       /* action that was rejected      */
} Conflict;

/* ----------------------------------------------------------------------- table */
typedef struct {
    Grammar     *grammar;     /* not owned; augmented by slr_init() */
    FirstFollow  ff;
    LRCollection lr;
    int          num_states;
    int          num_symbols;
    Action      *action;      /* [state * num_symbols + terminal]    */
    int         *go;          /* [state * num_symbols + nonterminal] (-1 = none) */
    Conflict    *conflicts;
    int          num_conflicts;
    int          conflict_cap;
    int         *first_reduce;/* scratch used while building         */
    int          states_built;
    int          tables_built;
} SLRTable;

/* ---- generation ---- */
int  slr_init(SLRTable *t, Grammar *g);   /* augment grammar, compute FIRST/FOLLOW. 0 = ok */
int  slr_build_states(SLRTable *t);       /* canonical collection; returns #states or -1   */
int  slr_build_tables(SLRTable *t);       /* ACTION/GOTO; returns #conflicts or -1         */
int  slr_generate(SLRTable *t, Grammar *g);/* all of the above; 0 = tables built (check slr_is_slr1) */
void slr_free(SLRTable *t);

/* ---- queries (what the parser uses) ---- */
Action slr_get_action(const SLRTable *t, int state, int terminal);     /* ACTION_ERROR if blank/invalid */
int    slr_get_goto(const SLRTable *t, int state, int nonterminal);    /* -1 if none */
int    slr_num_states(const SLRTable *t);
int    slr_prod_lhs(const SLRTable *t, int prod);      /* non-terminal id of the production */
int    slr_prod_length(const SLRTable *t, int prod);   /* number of rhs symbols (states to pop) */

/* ---- conflicts ---- */
int             slr_is_slr1(const SLRTable *t);        /* 1 if tables built and no conflicts */
int             slr_conflict_count(const SLRTable *t);
const Conflict *slr_get_conflict(const SLRTable *t, int index);

/* ---- printing ---- */
void slr_print_grammar(const SLRTable *t);
void slr_print_first_follow(const SLRTable *t);
void slr_print_states(const SLRTable *t);        /* item sets + transitions per state */
void slr_print_transitions(const SLRTable *t);
void slr_print_action_table(const SLRTable *t);
void slr_print_goto_table(const SLRTable *t);
void slr_print_conflicts(const SLRTable *t);

#endif /* SYNTAX_TABLE_H */
