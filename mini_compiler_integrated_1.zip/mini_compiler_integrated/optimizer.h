#ifndef OPTIMIZER_H
#define OPTIMIZER_H
#include "ir.h"

typedef struct { int folded, propagated, simplified, removed, rounds; } OptStats;

int opt_fold(IR *ir);
int opt_propagate(IR *ir);
int opt_simplify(IR *ir);
int opt_dead(IR *ir);

OptStats opt_run(IR *ir, int verbose);
void opt_print(const IR *ir, const OptStats *s);

#endif
