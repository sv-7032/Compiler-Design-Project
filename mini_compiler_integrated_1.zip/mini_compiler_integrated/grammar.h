/*
 * grammar.h  --  Grammar representation shared by Member 1 (grammar/lexer),
 *                Member 2 (this SLR(1) table generator) and Member 3 (parser).
 *
 * NOTE FOR THE TEAM
 * -----------------
 * This file is the *interface contract* the table generator is written against.
 * If Member 1 already has their own grammar structs, only grammar.h/grammar.c
 * need to be adapted; lr_items.* and syntax_table.* only touch the fields
 * documented below.
 *
 * Conventions
 *   - Terminals and non-terminals share ONE symbol-id space (0 .. num_symbols-1).
 *   - Symbol 0 is always the end-of-input marker "$" (a terminal).
 *   - Production 0 is RESERVED for the augmented production  S' -> S.
 *     User productions are therefore numbered 1, 2, 3 ... in the order added.
 *     REDUCE actions carry these production numbers, so Member 4 can attach
 *     semantic actions (TAC generation) to them.
 *   - An empty right-hand side (rhs_len == 0) means an epsilon production.
 */
#ifndef GRAMMAR_H
#define GRAMMAR_H

#define MAX_SYMBOLS      64   /* must stay <= 64: FIRST/FOLLOW sets are 64-bit masks */
#define MAX_PRODUCTIONS  128
#define MAX_RHS          10
#define MAX_NAME         32

#define SYM_END 0             /* the "$" end-of-input terminal */

typedef struct {
    char name[MAX_NAME];
    int  is_terminal;
} Symbol;

typedef struct {
    int lhs;                  /* non-terminal symbol id (-1 for the unused slot 0) */
    int rhs_len;              /* number of symbols on the right-hand side          */
    int rhs[MAX_RHS];         /* symbol ids                                        */
} Production;

typedef struct {
    Symbol     symbols[MAX_SYMBOLS];
    int        num_symbols;
    Production prods[MAX_PRODUCTIONS];
    int        num_prods;     /* counts the reserved slot 0 as well               */
    int        start_symbol;  /* user start symbol (lhs of first rule added)      */
    int        aug_start;     /* S' (valid once augmented == 1)                   */
    int        augmented;
} Grammar;

/* ---- building a grammar (grammar ingestion) -------------------------------- */

void grammar_init(Grammar *g);

/* Declare all terminals BEFORE adding rules.  Return the symbol id or -1.       */
int  grammar_add_terminal(Grammar *g, const char *name);
int  grammar_add_nonterminal(Grammar *g, const char *name);

/* Look a symbol up by name; -1 if unknown.                                      */
int  grammar_find_symbol(const Grammar *g, const char *name);

/* Add A -> rhs[0..rhs_len-1].  Returns the production number (>= 1) or -1.      */
int  grammar_add_production(Grammar *g, int lhs, const int *rhs, int rhs_len);

/*
 * Convenience: add one production from text, e.g.
 *     grammar_add_rule(g, "Sum", "Sum PLUS Term");
 *     grammar_add_rule(g, "A",   "");            <- epsilon production
 * Symbols are separated by spaces.  The lhs, and any rhs symbol that was not
 * declared as a terminal, is created as a non-terminal automatically.
 * The first rule added defines the start symbol.  Returns the production
 * number or -1.
 */
int  grammar_add_rule(Grammar *g, const char *lhs, const char *rhs);

/* Find the production number of a rule given as text (see above); -1 if absent. */
int  grammar_find_rule(const Grammar *g, const char *lhs, const char *rhs);

/*
 * Build the augmented grammar: create S' and fill production 0 with S' -> S.
 * Also checks that every non-terminal has at least one production (this catches
 * a misspelled terminal name).  Idempotent.  Returns 0 on success, -1 on error.
 */
int  grammar_augment(Grammar *g);

/* ---- printing -------------------------------------------------------------- */
void grammar_print_production(const Grammar *g, int prod);   /* "A -> x y z" */
void grammar_print(const Grammar *g);

/* ---- Member 1's grammar for the compiler ------------------------------------
 * Returns an UN-augmented grammar; slr_init() augments it.                      */
int  grammar_load_compiler(Grammar *g);

#endif /* GRAMMAR_H */
