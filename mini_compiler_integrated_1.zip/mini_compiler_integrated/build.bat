@echo off
setlocal

echo Building Mini Compiler...
gcc -std=c99 -Wall -Wextra -pedantic -O2 main.c compiler.c lexer.c grammar.c lr_items.c syntax_table.c reduction.c ir.c optimizer.c codegen.c -o mini_compiler.exe -lm
if errorlevel 1 (
    echo Build failed. Check the compiler messages above.
    exit /b 1
)

echo.
echo Build successful.
echo Running demo tests...
mini_compiler.exe --quiet --demo
exit /b %errorlevel%
