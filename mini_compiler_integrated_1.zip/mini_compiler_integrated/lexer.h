#ifndef LEXER_H
#define LEXER_H
#include <stddef.h>

#define MAX_LEXEME 64

typedef enum {
    TOK_INVALID = -1,
    TOK_INTEGER = 0,
    TOK_FLOAT,
    TOK_PLUS,
    TOK_MINUS,
    TOK_MULTIPLY,
    TOK_DIVIDE,
    TOK_BIT_AND,
    TOK_BIT_OR,
    TOK_BIT_XOR,
    TOK_BIT_NOT,
    TOK_LEFT_PAREN,
    TOK_RIGHT_PAREN,
    TOK_END_OF_INPUT,
    TOK_TERMINAL_COUNT
} TokenType;

typedef struct {
    TokenType type;
    long long int_value;
    double float_value;
    char lexeme[MAX_LEXEME];
    size_t offset;
    int line;
    int column;
} Token;

typedef struct {
    const char *src;
    size_t pos;
    int line;
    int column;
    Token peeked;
    int has_peek;
} Lexer;

void lexer_init(Lexer *lx, const char *src);
Token lexer_next(Lexer *lx);
Token lexer_peek(Lexer *lx);
size_t lexer_tokenize(const char *src, Token *out, size_t cap);

const char *token_name(TokenType t);
const char *token_symbol(TokenType t);
void token_format(const Token *tk, char *buf, size_t n);

#endif
