#ifndef CODEGEN_H
#define CODEGEN_H
#include "ir.h"

#define NREG 4

typedef enum {
    M_LOADI, M_FLOADI, M_LOAD, M_STORE, M_MOV,
    M_ADD, M_SUB, M_MUL, M_DIV, M_AND, M_OR, M_XOR, M_NOT, M_NEG,
    M_FADD, M_FSUB, M_FMUL, M_FDIV, M_FNEG, M_ITOF, M_HALT
} MOp;

typedef struct { MOp op; int rd, rs1, rs2, mem; Operand imm; } MInstr;
typedef struct { MInstr *code; int n, cap, ntemp; DType rtype; } Target;

void cg_generate(const IR *opt, Target *t);
void cg_print(const Target *t);
Operand cg_run(const Target *t);
void cg_free(Target *t);

#endif
