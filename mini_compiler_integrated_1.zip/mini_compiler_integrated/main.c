#include "compiler.h"
#include "optimizer.h"
#include "codegen.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

static double numeric(Operand o) { return o.d == T_INT ? (double)o.i : o.f; }
static int run_one(const char *src, int verbose, int show_table)
{
    Grammar g; SLRTable table; Token tokens[2048]; IR original, optimized; Target target; Operand parsed = {0};
    size_t n;
    if (grammar_load_compiler(&g) != 0) { fprintf(stderr, "Could not initialize grammar\n"); return 0; }
    if (slr_generate(&table, &g) != 0) { fprintf(stderr, "SLR table generation failed\n"); return 0; }
    if (!slr_is_slr1(&table)) { fprintf(stderr, "Compiler grammar has conflicts:\n"); slr_print_conflicts(&table); slr_free(&table); return 0; }
    if (show_table) { slr_print_grammar(&table); slr_print_first_follow(&table); slr_print_states(&table); slr_print_action_table(&table); slr_print_goto_table(&table); slr_print_conflicts(&table); }
    n = lexer_tokenize(src, tokens, sizeof tokens / sizeof tokens[0]);
    if (n == 0 || n >= sizeof tokens / sizeof tokens[0]) { fprintf(stderr, "Input exceeds token buffer\n"); slr_free(&table); return 0; }
    if (verbose) { printf("\nSOURCE: %s\n", src); compiler_print_tokens(tokens, (int)n); }
    ir_init(&original);
    if (!compiler_parse(&g, &table, tokens, (int)n, &original, &parsed, verbose)) { fprintf(stderr, "Parsing failed: %s\n", src); ir_free(&original); slr_free(&table); return 0; }
    ir_finish(&original, parsed); ir_copy(&optimized, &original);
    ir_print(&original, "Original Three-Address Code (TAC)");
    OptStats stats = opt_run(&optimized, 1); opt_print(&optimized, &stats);
    cg_generate(&optimized, &target); cg_print(&target);
    Operand va = ir_eval(&original), vb = ir_eval(&optimized), vc = cg_run(&target);
    double a = numeric(va), b = numeric(vb), c = numeric(vc);
    printf("\nRESULT CHECK\n  Original IR:  %.12g\n  Optimized IR: %.12g\n  Target run:   %.12g\n", a, b, c);
    int ok = fabs(a-b) < 1e-9 && fabs(a-c) < 1e-9;
    printf("  Status: %s\n", ok ? "PASS (all three results agree)" : "FAIL (results disagree)");
    ir_free(&original); ir_free(&optimized); cg_free(&target); slr_free(&table); return ok;
}
int main(int argc, char **argv)
{
    int verbose = 1, show_table = 0, demo = 0; const char *expr = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--quiet")) verbose = 0;
        else if (!strcmp(argv[i], "--table")) show_table = 1;
        else if (!strcmp(argv[i], "--demo")) demo = 1;
        else if (!expr) expr = argv[i];
        else { fprintf(stderr, "Quote the expression, e.g. ./mini_compiler \"3 + 5 * 2\"\n"); return 2; }
    }
    if (demo) {
        const char *tests[] = {"3 + 5 * 2", "-(4 + 6) * 2", "5 & 3 | 2", "3.5 + 2 * 4", "~~5", "8 / 2 + 3"};
        int all = 1;
        for (size_t i = 0; i < sizeof tests / sizeof tests[0]; i++) { printf("\n================ %s ================\n", tests[i]); all &= run_one(tests[i], verbose, show_table && i == 0); }
        printf("\nDEMO SUMMARY: %s\n", all ? "ALL PASS" : "ONE OR MORE FAILURES"); return all ? 0 : 1;
    }
    if (!expr) expr = "3 + 5 * 2";
    return run_one(expr, verbose, show_table) ? 0 : 1;
}
