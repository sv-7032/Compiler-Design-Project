# Integrated Mini Compiler (C99)

This integrated build combines the four submissions:

- Member 1: hand-written lexer (`lexer.c/.h`)
- Member 2: grammar loader, LR(0) items, SLR(1) table generation and conflict detection (`grammar.*`, `lr_items.*`, `syntax_table.*`)
- Member 3: reduction-history implementation (`reduction.*`); parser driver adapted to the real generated table
- Member 4: TAC, optimizer and custom target machine (`ir.*`, `optimizer.*`, `codegen.*`)

The two submissions included incompatible `grammar.h/.c` interfaces. This integrated version uses Member 2's grammar representation for table generation, maps Member 1's lexer token kinds to grammar terminal names, and keeps the agreed production numbering for semantic actions.

## Build and test

```sh
make
make test
```

## Run

```sh
./mini_compiler "3 + 5 * 2"
./mini_compiler "-(4 + 6) * 2"
./mini_compiler "5 & 3 | 2"
./mini_compiler "3.5 + 2 * 4"
./mini_compiler --demo --quiet
./mini_compiler --table "3 + 5 * 2"
```

The regular run prints tokens, shift/reduce trace, reduction history, original TAC, optimized TAC, target instructions, and checks that original IR, optimized IR, and the custom target-machine simulator agree. `--table` prints the generated grammar, FIRST/FOLLOW sets, LR states, ACTION table, GOTO table, and conflict report.

Assumptions: valid input; no formal error recovery; integer/integer division truncates; mixed arithmetic promotes to float; bitwise operators are intended for integer operands; generated target code is for the custom simulated machine, not native x86/ARM.
