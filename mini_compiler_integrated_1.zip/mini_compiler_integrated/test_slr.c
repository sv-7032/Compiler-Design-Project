/*
 * test_slr.c -- standalone tests for the SLR(1) table generator.
 *
 *   ./test_slr        compact run (pass/fail lines + conflict demos)
 *   ./test_slr -v     also dumps grammar, FIRST/FOLLOW, item sets, transitions,
 *                     ACTION and GOTO tables for the compiler grammar
 *
 * parse_tokens() below is ONLY a minimal test harness that drives the generated
 * table; the real shift-reduce parser is Member 3's work.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grammar.h"
#include "lr_items.h"
#include "syntax_table.h"

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, ...) do {                                              \
        if (cond) { g_pass++; }                                            \
        else { g_fail++; printf("  [FAIL] "); printf(__VA_ARGS__);         \
               printf("  (%s:%d)\n", __FILE__, __LINE__); }                \
    } while (0)

/* ------------------------------------------------------------------ helpers */

/* "PLUS MINUS $" -> bit mask of those symbols ("$" is symbol 0) */
static SymSet set_of(const Grammar *g, const char *names)
{
    char buf[256];
    SymSet s = 0;
    strncpy(buf, names, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    for (char *w = strtok(buf, " "); w; w = strtok(NULL, " ")) {
        int id = grammar_find_symbol(g, w);
        if (id < 0) { printf("  [test bug] unknown symbol %s\n", w); exit(2); }
        s |= SYMSET_BIT(id);
    }
    return s;
}

static int sym(const Grammar *g, const char *name) { return grammar_find_symbol(g, name); }

/* Build a grammar from a space-separated terminal list and (lhs, rhs) rules. */
static int load_spec(Grammar *g, const char *terms, const char *const rules[][2], int nrules)
{
    char buf[256];
    grammar_init(g);
    strncpy(buf, terms, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    for (char *w = strtok(buf, " "); w; w = strtok(NULL, " "))
        if (grammar_add_terminal(g, w) < 0) return -1;
    for (int i = 0; i < nrules; i++)
        if (grammar_add_rule(g, rules[i][0], rules[i][1]) < 0) return -1;
    return 0;
}

/* Minimal table-driven LR driver used only for testing. Returns 1 = accept. */
static int parse_tokens(const SLRTable *t, const char *text, int *reds, int *nreds)
{
    const Grammar *g = t->grammar;
    char buf[512];
    int toks[128], n = 0;
    int stack[256], sp = 0, pos = 0;

    strncpy(buf, text, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    for (char *w = strtok(buf, " "); w; w = strtok(NULL, " ")) {
        int id = grammar_find_symbol(g, w);
        if (id < 0) return 0;
        toks[n++] = id;
    }
    toks[n++] = SYM_END;

    *nreds = 0;
    stack[sp++] = 0;
    for (;;) {
        Action a = slr_get_action(t, stack[sp - 1], toks[pos]);
        if (sp > 250 || *nreds > 250) return 0;
        switch (a.type) {
            case ACTION_SHIFT:
                stack[sp++] = a.value;
                pos++;
                break;
            case ACTION_REDUCE: {
                sp -= slr_prod_length(t, a.value);
                int go = slr_get_goto(t, stack[sp - 1], slr_prod_lhs(t, a.value));
                if (go < 0) return 0;
                stack[sp++] = go;
                reds[(*nreds)++] = a.value;
                break;
            }
            case ACTION_ACCEPT: return 1;
            default:            return 0;
        }
    }
}

static int index_of(const int *a, int n, int v)
{
    for (int i = 0; i < n; i++) if (a[i] == v) return i;
    return -1;
}

static int generate_quiet(SLRTable *t, Grammar *g)
{
    return slr_generate(t, g);
}

/* ------------------------------------------------------------------- tests */

static void test_closure_goto_dedup(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    printf("\n[Test] CLOSURE / GOTO / state deduplication (compiler grammar)\n");

    /* closure of { S' -> . Expr } pulls in all 19 user productions + S' item */
    ItemSet s;
    itemset_init(&s);
    LRItem first = { 0, 0 };
    itemset_add(&s, first);
    CHECK(!itemset_add(&s, first), "adding a duplicate item must be rejected");
    itemset_closure(g, &s);
    CHECK(s.count == 20, "closure of the start item should have 20 items, got %d", s.count);
    CHECK(itemset_equal(&s, &t->lr.states[0].set), "state 0 must equal CLOSURE({S' -> . Expr})");

    /* GOTO(I0, Factor) = { Unary -> Factor . } */
    ItemSet gf = itemset_goto(g, &s, sym(g, "Factor"));
    CHECK(gf.count == 1 && item_is_complete(g, &gf.items[0]) &&
          g->prods[gf.items[0].prod].lhs == sym(g, "Unary"),
          "GOTO(I0, Factor) should be the single item Unary -> Factor .");
    itemset_free(&gf);

    /* GOTO(I0, INT_CONST) = { Factor -> INT_CONST . } */
    ItemSet gi = itemset_goto(g, &s, sym(g, "INT_CONST"));
    CHECK(gi.count == 1 && item_is_complete(g, &gi.items[0]),
          "GOTO(I0, INT_CONST) should be a single complete item");
    itemset_free(&gi);

    /* GOTO(I0, LPAREN) = kernel Factor -> ( . Expr ) + 19 closure items */
    ItemSet gl = itemset_goto(g, &s, sym(g, "LPAREN"));
    CHECK(gl.count == 20, "GOTO(I0, LPAREN) should have 20 items, got %d", gl.count);
    itemset_free(&gl);

    /* GOTO on a symbol that cannot follow the dot is empty */
    ItemSet ge = itemset_goto(g, &s, sym(g, "RPAREN"));
    CHECK(ge.count == 0, "GOTO(I0, RPAREN) must be empty");
    itemset_free(&ge);
    itemset_free(&s);

    /* every state is distinct */
    int dup = 0;
    for (int i = 0; i < t->num_states; i++)
        for (int j = i + 1; j < t->num_states; j++)
            if (itemset_equal(&t->lr.states[i].set, &t->lr.states[j].set)) dup++;
    CHECK(dup == 0, "no two states may have the same item set (%d duplicates)", dup);

    /* reuse: after a unary PLUS the same states are reached as from state 0 */
    int sp = t->lr.states[0].next[sym(g, "PLUS")];
    CHECK(sp > 0, "state 0 must have a PLUS transition");
    CHECK(t->lr.states[sp].next[sym(g, "PLUS")] == sp, "unary PLUS state must loop to itself");
    CHECK(t->lr.states[sp].next[sym(g, "MINUS")]  == t->lr.states[0].next[sym(g, "MINUS")],
          "MINUS after unary PLUS must reuse the state reached from state 0");
    CHECK(t->lr.states[sp].next[sym(g, "LPAREN")] == t->lr.states[0].next[sym(g, "LPAREN")],
          "LPAREN after unary PLUS must reuse the state reached from state 0");
    CHECK(t->lr.states[sp].next[sym(g, "INT_CONST")] == t->lr.states[0].next[sym(g, "INT_CONST")],
          "INT_CONST after unary PLUS must reuse the state reached from state 0");
}

static void test_first_follow(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    const FirstFollow *ff = &t->ff;
    printf("\n[Test] FIRST / FOLLOW (compiler grammar)\n");

    SymSet operand = set_of(g, "LPAREN INT_CONST FLOAT_CONST");
    SymSet unary   = operand | set_of(g, "PLUS MINUS TILDE");
    CHECK(ff->first[sym(g, "Factor")] == operand, "FIRST(Factor)");
    CHECK(ff->first[sym(g, "Unary")]  == unary,   "FIRST(Unary)");
    CHECK(ff->first[sym(g, "Term")]   == unary,   "FIRST(Term)");
    CHECK(ff->first[sym(g, "Expr")]   == unary,   "FIRST(Expr)");

    SymSet f_expr = set_of(g, "$ RPAREN PIPE");
    SymSet f_xor  = f_expr | set_of(g, "CARET");
    SymSet f_and  = f_xor  | set_of(g, "AMP");
    SymSet f_sum  = f_and  | set_of(g, "PLUS MINUS");
    SymSet f_term = f_sum  | set_of(g, "STAR SLASH");   /* Term -> Term STAR Unary adds * and / */
    SymSet f_un   = f_term;                              /* Unary only ever ends a Term */
    CHECK(ff->follow[sym(g, "Expr")]   == f_expr, "FOLLOW(Expr)");
    CHECK(ff->follow[sym(g, "Xor")]    == f_xor,  "FOLLOW(Xor)");
    CHECK(ff->follow[sym(g, "And")]    == f_and,  "FOLLOW(And)");
    CHECK(ff->follow[sym(g, "Sum")]    == f_sum,  "FOLLOW(Sum)");
    CHECK(ff->follow[sym(g, "Term")]   == f_term, "FOLLOW(Term)");
    CHECK(ff->follow[sym(g, "Unary")]  == f_un,   "FOLLOW(Unary)");
    CHECK(ff->follow[sym(g, "Factor")] == f_un,   "FOLLOW(Factor)");
    CHECK(ff->follow[g->aug_start] == SYMSET_BIT(SYM_END), "FOLLOW(S') = { $ }");

    int any_nullable = 0;
    for (int s = 1; s < g->num_symbols; s++) if (ff->nullable[s]) any_nullable = 1;
    CHECK(!any_nullable, "compiler grammar has no epsilon productions");
}

static void test_first_follow_epsilon(void)
{
    printf("\n[Test] FIRST / FOLLOW with an epsilon production:  S -> A B ; A -> a | (empty) ; B -> b\n");
    static const char *const rules[][2] = {
        { "S", "A B" }, { "A", "a" }, { "A", "" }, { "B", "b" }
    };
    Grammar g;
    SLRTable t;
    CHECK(load_spec(&g, "a b", rules, 4) == 0, "grammar loads");
    CHECK(generate_quiet(&t, &g) == 0, "tables generate");

    CHECK(t.ff.nullable[sym(&g, "A")] == 1, "A is nullable");
    CHECK(t.ff.nullable[sym(&g, "S")] == 0, "S is not nullable");
    CHECK(t.ff.first[sym(&g, "S")]  == set_of(&g, "a b"), "FIRST(S) = { a, b }");
    CHECK(t.ff.first[sym(&g, "A")]  == set_of(&g, "a"),   "FIRST(A) = { a }");
    CHECK(t.ff.follow[sym(&g, "A")] == set_of(&g, "b"),   "FOLLOW(A) = { b }");
    CHECK(t.ff.follow[sym(&g, "B")] == set_of(&g, "$"),   "FOLLOW(B) = { $ }");
    CHECK(slr_is_slr1(&t), "grammar is SLR(1)");

    int reds[64], nr;
    CHECK(parse_tokens(&t, "b",   reds, &nr) == 1, "parse: b");
    CHECK(parse_tokens(&t, "a b", reds, &nr) == 1, "parse: a b");
    CHECK(parse_tokens(&t, "a",   reds, &nr) == 0, "reject: a");
    slr_free(&t);
}

static void test_tables(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    printf("\n[Test] ACTION / GOTO generation (compiler grammar)\n");

    CHECK(slr_conflict_count(t) == 0, "compiler grammar must be conflict-free, got %d", slr_conflict_count(t));
    CHECK(slr_is_slr1(t), "compiler grammar must be SLR(1)");

    CHECK(slr_get_action(t, 0, sym(g, "INT_CONST")).type == ACTION_SHIFT, "state 0 shifts INT_CONST");
    CHECK(slr_get_action(t, 0, sym(g, "LPAREN")).type    == ACTION_SHIFT, "state 0 shifts LPAREN");
    CHECK(slr_get_action(t, 0, sym(g, "MINUS")).type     == ACTION_SHIFT, "state 0 shifts unary MINUS");
    CHECK(slr_get_action(t, 0, SYM_END).type             == ACTION_ERROR, "state 0 has no action on $");
    CHECK(slr_get_action(t, 0, sym(g, "STAR")).type      == ACTION_ERROR, "state 0 has no action on STAR");

    int after_expr = slr_get_goto(t, 0, sym(g, "Expr"));
    CHECK(after_expr > 0, "GOTO(0, Expr) exists");
    Action acc = slr_get_action(t, after_expr, SYM_END);
    CHECK(acc.type == ACTION_ACCEPT, "ACCEPT on $ in the state after Expr");
    CHECK(slr_get_action(t, after_expr, sym(g, "PIPE")).type == ACTION_SHIFT, "Expr . PIPE Xor shifts PIPE");

    int n_accept = 0, bad = 0;
    for (int s = 0; s < t->num_states; s++)
        for (int x = 0; x < g->num_symbols; x++) {
            if (!g->symbols[x].is_terminal) continue;
            Action a = slr_get_action(t, s, x);
            if (a.type == ACTION_ACCEPT) n_accept++;
            if (a.type == ACTION_SHIFT  && (a.value < 0 || a.value >= t->num_states)) bad++;
            if (a.type == ACTION_REDUCE && (a.value < 1 || a.value >= g->num_prods))  bad++;
        }
    CHECK(n_accept == 1, "exactly one ACCEPT entry, got %d", n_accept);
    CHECK(bad == 0, "all SHIFT/REDUCE values must be valid, %d bad", bad);

    CHECK(slr_get_goto(t, 0, sym(g, "Term"))  >= 0, "GOTO(0, Term) exists");
    CHECK(slr_get_goto(t, 0, sym(g, "Factor")) >= 0, "GOTO(0, Factor) exists");
    CHECK(slr_get_goto(t, 0, sym(g, "PLUS"))  == -1, "GOTO on a terminal is -1");
    CHECK(slr_get_action(t, 9999, 1).type == ACTION_ERROR, "out-of-range state is ACTION_ERROR");
}

static void test_determinism(const SLRTable *a)
{
    printf("\n[Test] deterministic numbering (generate twice, compare)\n");
    Grammar g2;
    SLRTable b;
    grammar_load_compiler(&g2);
    CHECK(generate_quiet(&b, &g2) == 0, "second generation succeeds");
    CHECK(a->num_states == b.num_states, "same number of states (%d vs %d)", a->num_states, b.num_states);
    int diff = 0;
    for (int s = 0; s < a->num_states && s < b.num_states; s++) {
        if (!itemset_equal(&a->lr.states[s].set, &b.lr.states[s].set)) diff++;
        for (int x = 0; x < a->num_symbols; x++) {
            if (a->lr.states[s].next[x] != b.lr.states[s].next[x]) diff++;
            if (a->grammar->symbols[x].is_terminal) {
                Action p = slr_get_action(a, s, x), q = slr_get_action(&b, s, x);
                if (p.type != q.type || p.value != q.value) diff++;
            }
        }
    }
    CHECK(diff == 0, "identical item sets, transitions and ACTION entries (%d differences)", diff);
    slr_free(&b);
}

static void test_parses(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    int reds[256], nr;
    printf("\n[Test] table-driven parses with the generated table\n");

    static const char *const good[] = {
        "INT_CONST",
        "FLOAT_CONST PLUS INT_CONST STAR FLOAT_CONST",
        "LPAREN INT_CONST PLUS INT_CONST RPAREN STAR INT_CONST",
        "MINUS MINUS INT_CONST",
        "TILDE INT_CONST AMP INT_CONST PIPE INT_CONST CARET INT_CONST",
        "PLUS INT_CONST MINUS MINUS INT_CONST",
        "LPAREN LPAREN FLOAT_CONST RPAREN RPAREN SLASH TILDE INT_CONST",
    };
    static const char *const bad[] = {
        "", "INT_CONST PLUS", "LPAREN INT_CONST", "INT_CONST INT_CONST",
        "STAR INT_CONST", "INT_CONST RPAREN", "LPAREN RPAREN", "TILDE",
    };
    for (size_t i = 0; i < sizeof good / sizeof good[0]; i++)
        CHECK(parse_tokens(t, good[i], reds, &nr) == 1, "accept: %s", good[i]);
    for (size_t i = 0; i < sizeof bad / sizeof bad[0]; i++)
        CHECK(parse_tokens(t, bad[i], reds, &nr) == 0, "reject: \"%s\"", bad[i]);

    /* precedence is visible in the order of reductions */
    int p_star = grammar_find_rule(g, "Term", "Term STAR Unary");
    int p_plus = grammar_find_rule(g, "Sum",  "Sum PLUS Term");
    int p_and  = grammar_find_rule(g, "And",  "And AMP Sum");
    int p_or   = grammar_find_rule(g, "Expr", "Expr PIPE Xor");
    int p_neg  = grammar_find_rule(g, "Unary", "MINUS Unary");

    parse_tokens(t, "INT_CONST PLUS INT_CONST STAR INT_CONST", reds, &nr);
    CHECK(index_of(reds, nr, p_star) >= 0 && index_of(reds, nr, p_star) < index_of(reds, nr, p_plus),
          "1 + 2 * 3 : '*' reduced before '+'");
    parse_tokens(t, "INT_CONST PIPE INT_CONST AMP INT_CONST", reds, &nr);
    CHECK(index_of(reds, nr, p_and) >= 0 && index_of(reds, nr, p_and) < index_of(reds, nr, p_or),
          "1 | 2 & 3 : '&' reduced before '|'");
    parse_tokens(t, "MINUS INT_CONST STAR INT_CONST", reds, &nr);
    CHECK(index_of(reds, nr, p_neg) >= 0 && index_of(reds, nr, p_neg) < index_of(reds, nr, p_star),
          "-1 * 2 : unary minus reduced before '*'");
}

static void test_conflict_grammars(void)
{
    Grammar g;
    SLRTable t;

    printf("\n[Test] conflict detection -- separate grammars, NOT the compiler grammar\n");

    /* 1. ambiguous grammar: shift/reduce on PLUS after  E + E . */
    printf("\n--- Grammar 1: ambiguous   E -> E PLUS E | ID ---\n");
    static const char *const r1[][2] = { { "E", "E PLUS E" }, { "E", "ID" } };
    CHECK(load_spec(&g, "PLUS ID", r1, 2) == 0, "grammar 1 loads");
    CHECK(generate_quiet(&t, &g) == 0, "grammar 1 tables generate");
    slr_print_grammar(&t);
    printf("\n");
    slr_print_conflicts(&t);
    CHECK(slr_conflict_count(&t) == 1, "grammar 1: exactly 1 conflict, got %d", slr_conflict_count(&t));
    const Conflict *c = slr_get_conflict(&t, 0);
    CHECK(c && c->type == CONFLICT_SHIFT_REDUCE, "grammar 1: conflict is Shift/Reduce");
    CHECK(c && c->terminal == sym(&g, "PLUS"), "grammar 1: lookahead is PLUS");
    CHECK(c && c->existing.type == ACTION_SHIFT && c->conflicting.type == ACTION_REDUCE,
          "grammar 1: existing = SHIFT, conflicting = REDUCE");
    CHECK(c && slr_get_action(&t, c->state, c->terminal).type == ACTION_SHIFT,
          "grammar 1: the existing shift was NOT overwritten");
    CHECK(!slr_is_slr1(&t), "grammar 1 is not SLR(1)");
    slr_free(&t);

    /* 2. reduce/reduce */
    printf("\n--- Grammar 2: reduce/reduce   S -> A | B ; A -> ID ; B -> ID ---\n");
    static const char *const r2[][2] = { { "S", "A" }, { "S", "B" }, { "A", "ID" }, { "B", "ID" } };
    CHECK(load_spec(&g, "ID", r2, 4) == 0, "grammar 2 loads");
    CHECK(generate_quiet(&t, &g) == 0, "grammar 2 tables generate");
    slr_print_conflicts(&t);
    CHECK(slr_conflict_count(&t) == 1, "grammar 2: exactly 1 conflict, got %d", slr_conflict_count(&t));
    c = slr_get_conflict(&t, 0);
    CHECK(c && c->type == CONFLICT_REDUCE_REDUCE, "grammar 2: conflict is Reduce/Reduce");
    CHECK(c && c->terminal == SYM_END, "grammar 2: lookahead is $");
    slr_free(&t);

    /* 3. unambiguous, LR(1) but NOT SLR(1) (Aho/Sethi/Ullman pointer-assignment grammar) */
    printf("\n--- Grammar 3: LR(1) but not SLR(1)   S -> L EQ R | R ; L -> STAR R | ID ; R -> L ---\n");
    static const char *const r3[][2] = {
        { "S", "L EQ R" }, { "S", "R" }, { "L", "STAR R" }, { "L", "ID" }, { "R", "L" }
    };
    CHECK(load_spec(&g, "EQ STAR ID", r3, 5) == 0, "grammar 3 loads");
    CHECK(generate_quiet(&t, &g) == 0, "grammar 3 tables generate");
    slr_print_conflicts(&t);
    CHECK(slr_conflict_count(&t) == 1, "grammar 3: exactly 1 conflict, got %d", slr_conflict_count(&t));
    c = slr_get_conflict(&t, 0);
    CHECK(c && c->type == CONFLICT_SHIFT_REDUCE && c->terminal == sym(&g, "EQ"),
          "grammar 3: Shift/Reduce on EQ (FOLLOW(R) is too coarse for SLR)");
    slr_free(&t);

    /* 4. cell with a shift AND two different reductions: both clashes must be reported */
    printf("\n--- Grammar 4: two reductions competing on two lookaheads ---\n");
    static const char *const r4[][2] = {
        { "S", "A X" }, { "S", "B X" }, { "S", "A" }, { "S", "B" },
        { "A", "ID" }, { "B", "ID" }
    };
    /* After ID: A -> ID . and B -> ID . ; FOLLOW(A) and FOLLOW(B) both contain X and $.
       No shift exists in that state, so this exercises Reduce/Reduce on two terminals. */
    CHECK(load_spec(&g, "ID X", r4, 6) == 0, "grammar 4 loads");
    CHECK(generate_quiet(&t, &g) == 0, "grammar 4 tables generate");
    int rr = 0;
    for (int i = 0; i < slr_conflict_count(&t); i++)
        if (slr_get_conflict(&t, i)->type == CONFLICT_REDUCE_REDUCE) rr++;
    CHECK(rr == 2, "grammar 4: Reduce/Reduce reported on both X and $, got %d", rr);
    slr_free(&t);
}

/* -------------------------------------------------------------------- main */

int main(int argc, char **argv)
{
    int verbose = (argc > 1 && strcmp(argv[1], "-v") == 0);
    Grammar g;
    SLRTable t;

    printf("=== SLR(1) table generator: tests ===\n");
    CHECK(grammar_load_compiler(&g) == 0, "compiler grammar loads");
    CHECK(slr_generate(&t, &g) == 0, "tables generate for the compiler grammar");

    printf("\nCompiler grammar: %d productions (incl. augmented), %d LR(0) states\n",
           g.num_prods, slr_num_states(&t));

    if (verbose) {
        printf("\n================ GRAMMAR ================\n");
        slr_print_grammar(&t);
        printf("\n================ FIRST / FOLLOW ================\n");
        slr_print_first_follow(&t);
        printf("\n================ LR(0) ITEM SETS ================\n");
        slr_print_states(&t);
        printf("\n================ TRANSITIONS ================\n");
        slr_print_transitions(&t);
        printf("\n================ ACTION TABLE ================\n");
        slr_print_action_table(&t);
        printf("\n================ GOTO TABLE ================\n");
        slr_print_goto_table(&t);
        printf("\n================ CONFLICTS ================\n");
    }
    slr_print_conflicts(&t);

    test_closure_goto_dedup(&t);
    test_first_follow(&t);
    test_tables(&t);
    test_determinism(&t);
    test_parses(&t);
    test_first_follow_epsilon();
    test_conflict_grammars();

    slr_free(&t);
    printf("\n=== %d checks passed, %d failed ===\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
