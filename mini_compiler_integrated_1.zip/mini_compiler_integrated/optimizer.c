#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "optimizer.h"

#define MAXIT 10
#define R(x) (r = (x), ok = 1)

static int isc(Operand o, int v) { return o.k == K_CONST && (o.d == T_INT ? o.i == v : o.f == v); }
static int same(Operand a, Operand b) { return a.k == b.k && (a.k == K_TEMP || a.k == K_VAR) && a.t == b.t; }

static void to_assign(TAC *c, Operand r) {
    c->form = F_ASSIGN; c->op = OP_ASSIGN; c->a = r; c->b = (Operand){0};
}

int opt_fold(IR *ir) {
    int n = 0;
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand o;
        if (c->form == F_ASSIGN || c->a.k != K_CONST) continue;
        if (c->form == F_BINARY && c->b.k != K_CONST) continue;
        if (ir_apply(c->op, c->type, c->a, c->b, &o)) { to_assign(c, o); n++; }
    }
    return n;
}

int opt_propagate(IR *ir) {
    int n = 0, m = ir->ntemp + 1;
    Operand *v = calloc(m, sizeof *v);
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand *p[2] = {&c->a, &c->b};
        for (int j = 0; j < (c->form == F_BINARY ? 2 : 1); j++)
            if (p[j]->k == K_TEMP && v[p[j]->t].k != K_NONE) { *p[j] = v[p[j]->t]; n++; }
        for (int u = 1; u < m; u++) if (v[u].k == K_TEMP && v[u].t == c->res) v[u] = (Operand){0};
        v[c->res] = (Operand){0};
        if (c->form == F_ASSIGN && c->a.k != K_NONE && !(c->a.k == K_TEMP && c->a.t == c->res)) v[c->res] = c->a;
    }
    free(v);
    return n;
}

int opt_simplify(IR *ir) {
    int n = 0;
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand a = c->a, b = c->b, r = {0};
        int ok = 0, fl = c->type == T_FLOAT;
        if (c->form != F_BINARY) continue;
        switch (c->op) {
        case OP_ADD:
            if (!fl) { if (isc(b, 0)) R(a); else if (isc(a, 0)) R(b); }
            break;
        case OP_SUB:
            if (isc(b, 0) && (!fl || !signbit(b.f))) R(a);
            else if (!fl && same(a, b)) R(ir_int(0));
            break;
        case OP_MUL:
            if (isc(b, 1)) R(a);
            else if (isc(a, 1)) R(b);
            else if (!fl && (isc(a, 0) || isc(b, 0))) R(ir_int(0));
            break;
        case OP_DIV:
            if (isc(b, 1)) R(a);
            break;
        case OP_AND:
            if (fl) break;
            if (isc(a, 0) || isc(b, 0)) R(ir_int(0));
            else if (isc(b, -1)) R(a);
            else if (isc(a, -1)) R(b);
            else if (same(a, b)) R(a);
            break;
        case OP_OR:
            if (fl) break;
            if (isc(a, -1) || isc(b, -1)) R(ir_int(-1));
            else if (isc(b, 0)) R(a);
            else if (isc(a, 0)) R(b);
            else if (same(a, b)) R(a);
            break;
        case OP_XOR:
            if (fl) break;
            if (isc(b, 0)) R(a);
            else if (isc(a, 0)) R(b);
            else if (same(a, b)) R(ir_int(0));
            break;
        default: break;
        }
        if (ok) { to_assign(c, r); n++; }
    }
    return n;
}

int opt_dead(IR *ir) {
    int n = 0;
    char *live = calloc(ir->ntemp + 1, 1);
    if (ir->n) live[ir->code[ir->n - 1].res] = 1;
    for (int i = ir->n - 1; i >= 0; i--) {
        TAC *c = &ir->code[i];
        if (!live[c->res]) { ir_delete(ir, i); n++; continue; }
        live[c->res] = 0;
        if (c->a.k == K_TEMP) live[c->a.t] = 1;
        if (c->form == F_BINARY && c->b.k == K_TEMP) live[c->b.t] = 1;
    }
    free(live);
    return n;
}

OptStats opt_run(IR *ir, int verbose) {
    static const char *nm[] = {"Constant Folding", "Constant Propagation", "Algebraic Simplification", "Dead Temporary Elimination"};
    int (*pass[4])(IR *) = {opt_fold, opt_propagate, opt_simplify, opt_dead};
    OptStats s = {0};
    int *cnt[4] = {&s.folded, &s.propagated, &s.simplified, &s.removed};
    char t[80];
    for (int r = 1; r <= MAXIT; r++) {
        int ch = 0;
        s.rounds = r;
        for (int p = 0; p < 4; p++) {
            int k = pass[p](ir);
            *cnt[p] += k;
            ch += k;
            if (k && verbose) {
                sprintf(t, "Round %d: %s (%d change%s)", r, nm[p], k, k == 1 ? "" : "s");
                ir_print(ir, t);
            }
        }
        if (!ch) break;
    }
    return s;
}

void opt_print(const IR *ir, const OptStats *s) {
    ir_print(ir, "Optimized TAC");
    printf("  [folded=%d propagated=%d simplified=%d removed=%d, rounds=%d]\n",
           s->folded, s->propagated, s->simplified, s->removed, s->rounds);
}
