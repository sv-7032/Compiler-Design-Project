#include "lexer.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *NAMES[TOK_TERMINAL_COUNT] = {
    "INTEGER", "FLOAT", "PLUS", "MINUS", "MULTIPLY", "DIVIDE", "BIT_AND",
    "BIT_OR", "BIT_XOR", "BIT_NOT", "LEFT_PAREN", "RIGHT_PAREN", "END_OF_INPUT"
};

static const char *SYMBOLS[TOK_TERMINAL_COUNT] = {
    "int", "float", "+", "-", "*", "/", "&", "|", "^", "~", "(", ")", "$"
};

const char *token_name(TokenType t) {
    return (t >= 0 && t < TOK_TERMINAL_COUNT) ? NAMES[t] : "INVALID";
}

const char *token_symbol(TokenType t) {
    return (t >= 0 && t < TOK_TERMINAL_COUNT) ? SYMBOLS[t] : "?";
}

void token_format(const Token *tk, char *buf, size_t n) {
    if (tk->type == TOK_INTEGER || tk->type == TOK_FLOAT)
        snprintf(buf, n, "%s(%s)", token_name(tk->type), tk->lexeme);
    else
        snprintf(buf, n, "%s", token_name(tk->type));
}

void lexer_init(Lexer *lx, const char *src) {
    memset(lx, 0, sizeof *lx);
    lx->src = src;
    lx->line = 1;
    lx->column = 1;
}

static int cur(const Lexer *lx) { return (unsigned char)lx->src[lx->pos]; }

static void adv(Lexer *lx) {
    if (lx->src[lx->pos] == '\n') { lx->line++; lx->column = 1; }
    else lx->column++;
    lx->pos++;
}

static void take(Lexer *lx, Token *t, size_t *n) {
    if (*n < MAX_LEXEME - 1) t->lexeme[(*n)++] = (char)cur(lx);
    adv(lx);
}

static Token scan(Lexer *lx) {
    Token t;
    memset(&t, 0, sizeof t);
    while (cur(lx) && isspace(cur(lx))) adv(lx);
    t.offset = lx->pos;
    t.line = lx->line;
    t.column = lx->column;
    int c = cur(lx);
    if (c == 0) {
        t.type = TOK_END_OF_INPUT;
        strcpy(t.lexeme, "$");
        return t;
    }
    if (isdigit(c) || (c == '.' && isdigit((unsigned char)lx->src[lx->pos + 1]))) {
        size_t n = 0;
        int is_float = 0;
        while (isdigit(cur(lx))) take(lx, &t, &n);
        if (cur(lx) == '.') {
            is_float = 1;
            take(lx, &t, &n);
            while (isdigit(cur(lx))) take(lx, &t, &n);
        }
        t.lexeme[n] = '\0';
        if (is_float) {
            t.type = TOK_FLOAT;
            t.float_value = strtod(t.lexeme, NULL);
        } else {
            t.type = TOK_INTEGER;
            t.int_value = strtoll(t.lexeme, NULL, 10);
            t.float_value = (double)t.int_value;
        }
        return t;
    }
    switch (c) {
        case '+': t.type = TOK_PLUS; break;
        case '-': t.type = TOK_MINUS; break;
        case '*': t.type = TOK_MULTIPLY; break;
        case '/': t.type = TOK_DIVIDE; break;
        case '&': t.type = TOK_BIT_AND; break;
        case '|': t.type = TOK_BIT_OR; break;
        case '^': t.type = TOK_BIT_XOR; break;
        case '~': t.type = TOK_BIT_NOT; break;
        case '(': t.type = TOK_LEFT_PAREN; break;
        case ')': t.type = TOK_RIGHT_PAREN; break;
        default: t.type = TOK_INVALID; break;
    }
    t.lexeme[0] = (char)c;
    t.lexeme[1] = '\0';
    adv(lx);
    return t;
}

Token lexer_next(Lexer *lx) {
    if (lx->has_peek) { lx->has_peek = 0; return lx->peeked; }
    return scan(lx);
}

Token lexer_peek(Lexer *lx) {
    if (!lx->has_peek) { lx->peeked = scan(lx); lx->has_peek = 1; }
    return lx->peeked;
}

size_t lexer_tokenize(const char *src, Token *out, size_t cap) {
    Lexer lx;
    size_t n = 0;
    lexer_init(&lx, src);
    while (n < cap) {
        out[n] = lexer_next(&lx);
        n++;
        if (out[n - 1].type == TOK_END_OF_INPUT) break;
    }
    return n;
}
