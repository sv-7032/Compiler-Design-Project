#ifndef MINI_COMPILER_H
#define MINI_COMPILER_H
#include "grammar.h"
#include "syntax_table.h"
#include "lexer.h"
#include "ir.h"
int compiler_parse(const Grammar *g, const SLRTable *table, const Token *tokens, int ntokens, IR *ir, Operand *result, int verbose);
int compiler_token_terminal(const Grammar *g, TokenType type);
void compiler_print_tokens(const Token *tokens, int n);
#endif
