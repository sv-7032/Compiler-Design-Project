/*
 * lr_items.h  --  LR(0) items, item sets, CLOSURE, GOTO and the canonical
 *                 collection of LR(0) states.
 *
 * ALGORITHMS (short version, for the viva)
 * ----------------------------------------
 * LR(0) item   A -> alpha . beta   is stored as (production number, dot position).
 *              dot = 0 means nothing of the rhs has been seen yet,
 *              dot = rhs_len means the item is "complete" (ready to reduce).
 *
 * CLOSURE(I)   Start with I.  Repeat until nothing changes:
 *                for every item  A -> alpha . B beta  in I  (B a non-terminal)
 *                  for every production  B -> gamma
 *                    add the item  B -> . gamma.
 *              Meaning: "if we expect a B next, we may also be at the start of
 *              any rule for B".
 *
 * GOTO(I, X)   Take every item  A -> alpha . X beta  in I, move the dot over X
 *              giving  A -> alpha X . beta,  and return CLOSURE of that set.
 *              Meaning: "the state we are in after recognising symbol X".
 *
 * CANONICAL COLLECTION
 *              State 0 = CLOSURE({ S' -> . S }).
 *              Process states in numerical order (a queue).  For each state and
 *              for each grammar symbol X (in symbol-id order) compute GOTO(I, X).
 *              If the result is non-empty and equal to an existing state, REUSE
 *              that state (deduplication); otherwise give it the next number.
 *              Because states are created in a fixed order, numbering is
 *              deterministic: the same grammar always gives the same states.
 *
 * Item sets are kept SORTED (by production, then dot), which makes duplicate
 * detection and set comparison a simple element-by-element walk.
 */
#ifndef LR_ITEMS_H
#define LR_ITEMS_H

#include "grammar.h"

typedef struct {
    int prod;                 /* production number (0 = augmented production) */
    int dot;                  /* 0 .. rhs_len                                 */
} LRItem;

typedef struct {
    LRItem *items;            /* sorted, no duplicates */
    int     count;
    int     cap;
} ItemSet;

typedef struct {
    ItemSet set;              /* the (closed) item set of this state            */
    int    *next;             /* next[X] = state reached on symbol X, or -1     */
} LRState;                    /* next[] has g->num_symbols entries              */

typedef struct {
    const Grammar *g;         /* must be augmented                              */
    LRState *states;
    int num_states;
    int cap;
} LRCollection;

/* ---- single items ---------------------------------------------------------- */
int  item_compare(const LRItem *a, const LRItem *b);        /* <0, 0, >0       */
int  item_equal(const LRItem *a, const LRItem *b);
int  item_is_complete(const Grammar *g, const LRItem *it);  /* dot at the end  */
int  item_next_symbol(const Grammar *g, const LRItem *it);  /* symbol after dot, -1 if complete */
int  item_is_kernel(const LRItem *it);                      /* dot>0 or S'->.S */

/* ---- item sets ------------------------------------------------------------- */
void    itemset_init(ItemSet *s);
void    itemset_free(ItemSet *s);
int     itemset_add(ItemSet *s, LRItem it);                 /* 1 if added, 0 if already present */
int     itemset_contains(const ItemSet *s, LRItem it);
int     itemset_equal(const ItemSet *a, const ItemSet *b);  /* 1 if same set   */
void    itemset_closure(const Grammar *g, ItemSet *s);      /* in place        */
ItemSet itemset_goto(const Grammar *g, const ItemSet *s, int sym);  /* caller frees */

/* ---- canonical collection -------------------------------------------------- */
void lr_collection_init(LRCollection *c, const Grammar *g);
int  lr_collection_build(LRCollection *c);                  /* returns #states, -1 on error */
int  lr_collection_find(const LRCollection *c, const ItemSet *s);  /* state number or -1  */
void lr_collection_free(LRCollection *c);

/* ---- printing -------------------------------------------------------------- */
void lr_print_item(const Grammar *g, const LRItem *it);     /* "E -> E . + T"   */
void lr_print_itemset(const Grammar *g, const ItemSet *s);  /* kernel + closure */
void lr_print_collection(const LRCollection *c);            /* items + transitions per state */
void lr_print_transitions(const LRCollection *c);           /* flat list: I3 --PLUS--> I7 */

#endif /* LR_ITEMS_H */
