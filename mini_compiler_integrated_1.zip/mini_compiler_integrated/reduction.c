#include <stdlib.h>
#include <string.h>
#include "reduction.h"

static char *dup_str(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (p) memcpy(p, s, n);
    return p;
}

void reduction_init(ReductionHistory *h) { h->recs = NULL; h->count = 0; h->cap = 0; }

void reduction_free(ReductionHistory *h) {
    for (int i = 0; i < h->count; i++) {
        free(h->recs[i].production);   free(h->recs[i].stack_before);
        free(h->recs[i].stack_after);  free(h->recs[i].remaining_input);
        free(h->recs[i].action);
    }
    free(h->recs);
    reduction_init(h);
}

int reduction_add(ReductionHistory *h, int prod_no, const char *production,
                  const char *before, const char *after,
                  const char *input, const char *action) {
    if (h->count == h->cap) {
        int nc = h->cap ? h->cap * 2 : 16;
        ReductionRecord *nr = realloc(h->recs, (size_t)nc * sizeof *nr);
        if (!nr) return 0;
        h->recs = nr; h->cap = nc;
    }
    ReductionRecord *r = &h->recs[h->count];
    r->seq = h->count + 1;
    r->prod_no = prod_no;
    r->production = dup_str(production);
    r->stack_before = dup_str(before);
    r->stack_after = dup_str(after);
    r->remaining_input = dup_str(input);
    r->action = dup_str(action);
    h->count++;
    return 1;
}

void reduction_print(const ReductionHistory *h, FILE *out) {
    fprintf(out, "\nReduction history (%d reductions)\n", h->count);
    fprintf(out, "------------------------------------------------------------\n");
    for (int i = 0; i < h->count; i++) {
        const ReductionRecord *r = &h->recs[i];
        fprintf(out, "#%d  prod %d: %s   [%s]\n", r->seq, r->prod_no, r->production, r->action);
        fprintf(out, "     before: %s\n     after : %s\n     input : %s\n",
                r->stack_before, r->stack_after, r->remaining_input);
    }
}
