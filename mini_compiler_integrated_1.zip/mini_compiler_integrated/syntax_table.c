/* syntax_table.c -- see syntax_table.h for the algorithms */
#include "syntax_table.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void *xcalloc(size_t n, size_t sz)
{
    void *p = calloc(n, sz);
    if (!p) { fprintf(stderr, "syntax_table: out of memory\n"); exit(1); }
    return p;
}

/* ================================================================ FIRST/FOLLOW */

/* dst |= src; returns 1 if dst changed */
static int merge(SymSet *dst, SymSet src)
{
    SymSet n = *dst | src;
    if (n == *dst) return 0;
    *dst = n;
    return 1;
}

void first_follow_compute(const Grammar *g, FirstFollow *ff)
{
    int changed;
    memset(ff, 0, sizeof *ff);

    /* FIRST(terminal) = { terminal } */
    for (int s = 0; s < g->num_symbols; s++)
        if (g->symbols[s].is_terminal) ff->first[s] = SYMSET_BIT(s);

    /* nullable + FIRST for non-terminals:
       for  A -> X1 X2 ... Xn :  FIRST(A) gets FIRST(X1); if X1 is nullable also
       FIRST(X2); and so on.  A is nullable if every Xi is (or n == 0). */
    do {
        changed = 0;
        for (int p = 0; p < g->num_prods; p++) {
            const Production *pr = &g->prods[p];
            if (pr->lhs < 0) continue;                     /* unused slot 0 */
            SymSet add = 0;
            int all_nullable = 1;
            for (int i = 0; i < pr->rhs_len; i++) {
                int X = pr->rhs[i];
                add |= ff->first[X];
                if (!ff->nullable[X]) { all_nullable = 0; break; }
            }
            if (merge(&ff->first[pr->lhs], add)) changed = 1;
            if (all_nullable && !ff->nullable[pr->lhs]) { ff->nullable[pr->lhs] = 1; changed = 1; }
        }
    } while (changed);

    /* FOLLOW:  FOLLOW(S') = { $ }.
       For  A -> alpha B beta :  FOLLOW(B) gets FIRST(beta);
       if beta is nullable (or empty) FOLLOW(B) also gets FOLLOW(A). */
    int root = g->augmented ? g->aug_start : g->start_symbol;
    if (root >= 0) ff->follow[root] = SYMSET_BIT(SYM_END);

    do {
        changed = 0;
        for (int p = 0; p < g->num_prods; p++) {
            const Production *pr = &g->prods[p];
            if (pr->lhs < 0) continue;
            for (int i = 0; i < pr->rhs_len; i++) {
                int B = pr->rhs[i];
                if (g->symbols[B].is_terminal) continue;
                SymSet add = 0;
                int rest_nullable = 1;
                for (int j = i + 1; j < pr->rhs_len; j++) {
                    int Y = pr->rhs[j];
                    add |= ff->first[Y];
                    if (!ff->nullable[Y]) { rest_nullable = 0; break; }
                }
                if (rest_nullable) add |= ff->follow[pr->lhs];
                if (merge(&ff->follow[B], add)) changed = 1;
            }
        }
    } while (changed);
}

static void print_symset(const Grammar *g, SymSet s)
{
    printf("{");
    int first = 1;
    for (int x = 0; x < g->num_symbols; x++) {
        if (!SYMSET_HAS(s, x)) continue;
        printf("%s%s", first ? " " : ", ", g->symbols[x].name);
        first = 0;
    }
    printf(" }");
}

void first_follow_print(const Grammar *g, const FirstFollow *ff)
{
    printf("FIRST sets:\n");
    for (int s = 1; s < g->num_symbols; s++) {
        if (g->symbols[s].is_terminal) continue;
        printf("  FIRST(%s) = ", g->symbols[s].name);
        print_symset(g, ff->first[s]);
        if (ff->nullable[s]) printf("   [nullable]");
        printf("\n");
    }
    printf("FOLLOW sets:\n");
    for (int s = 1; s < g->num_symbols; s++) {
        if (g->symbols[s].is_terminal) continue;
        printf("  FOLLOW(%s) = ", g->symbols[s].name);
        print_symset(g, ff->follow[s]);
        printf("\n");
    }
}

/* ================================================================= generation */

int slr_init(SLRTable *t, Grammar *g)
{
    memset(t, 0, sizeof *t);
    if (!g) return -1;
    if (grammar_augment(g) != 0) return -1;

    t->grammar = g;
    t->num_symbols = g->num_symbols;
    first_follow_compute(g, &t->ff);
    lr_collection_init(&t->lr, g);
    return 0;
}

int slr_build_states(SLRTable *t)
{
    if (!t->grammar) return -1;
    if (t->states_built) return t->num_states;
    int n = lr_collection_build(&t->lr);
    if (n < 0) return -1;
    t->num_states = n;
    t->states_built = 1;
    return n;
}

static void add_conflict(SLRTable *t, int state, int term, Action existing, Action conflicting)
{
    if (t->num_conflicts == t->conflict_cap) {
        int ncap = t->conflict_cap ? t->conflict_cap * 2 : 8;
        Conflict *nc = realloc(t->conflicts, (size_t)ncap * sizeof(Conflict));
        if (!nc) { fprintf(stderr, "syntax_table: out of memory\n"); exit(1); }
        t->conflicts = nc;
        t->conflict_cap = ncap;
    }
    Conflict c;
    c.state = state;
    c.terminal = term;
    c.existing = existing;
    c.conflicting = conflicting;
    if ((existing.type == ACTION_SHIFT && conflicting.type == ACTION_REDUCE) ||
        (existing.type == ACTION_REDUCE && conflicting.type == ACTION_SHIFT))
        c.type = CONFLICT_SHIFT_REDUCE;
    else if (existing.type == ACTION_REDUCE && conflicting.type == ACTION_REDUCE)
        c.type = CONFLICT_REDUCE_REDUCE;
    else
        c.type = CONFLICT_OTHER;
    t->conflicts[t->num_conflicts++] = c;
}

/* Put action `a` into ACTION[state][term] WITHOUT ever overwriting a different one. */
static void set_action(SLRTable *t, int state, int term, Action a)
{
    size_t idx = (size_t)state * (size_t)t->num_symbols + (size_t)term;
    Action *cell = &t->action[idx];

    if (cell->type == ACTION_ERROR) {
        *cell = a;
    } else if (cell->type == a.type && cell->value == a.value) {
        /* the same action arriving from a second item: not a conflict */
    } else {
        add_conflict(t, state, term, *cell, a);
        /* A cell holding a shift may already have rejected a reduce r1; if a
           different reduce r2 arrives it also clashes with r1.  Report that too. */
        if (a.type == ACTION_REDUCE && cell->type != ACTION_REDUCE &&
            t->first_reduce[idx] >= 0 && t->first_reduce[idx] != a.value) {
            Action prev = { ACTION_REDUCE, t->first_reduce[idx] };
            add_conflict(t, state, term, prev, a);
        }
    }
    if (a.type == ACTION_REDUCE && t->first_reduce[idx] < 0)
        t->first_reduce[idx] = a.value;
}

int slr_build_tables(SLRTable *t)
{
    if (!t->states_built) return -1;
    const Grammar *g = t->grammar;
    int ns = t->num_states, nsym = t->num_symbols;
    size_t cells = (size_t)ns * (size_t)nsym;

    /* (re)allocate */
    free(t->action); free(t->go); free(t->conflicts); free(t->first_reduce);
    t->conflicts = NULL; t->num_conflicts = 0; t->conflict_cap = 0;
    t->action = xcalloc(cells, sizeof(Action));              /* all ACTION_ERROR */
    t->go = xcalloc(cells, sizeof(int));
    t->first_reduce = xcalloc(cells, sizeof(int));
    for (size_t i = 0; i < cells; i++) { t->go[i] = -1; t->first_reduce[i] = -1; }

    for (int s = 0; s < ns; s++) {
        const LRState *st = &t->lr.states[s];

        /* pass 1: shifts and accept */
        for (int i = 0; i < st->set.count; i++) {
            const LRItem *it = &st->set.items[i];
            if (!item_is_complete(g, it)) {
                int X = item_next_symbol(g, it);
                if (g->symbols[X].is_terminal) {
                    Action a = { ACTION_SHIFT, st->next[X] };
                    set_action(t, s, X, a);
                }
            } else if (it->prod == 0) {                       /* S' -> S .  */
                Action a = { ACTION_ACCEPT, 0 };
                set_action(t, s, SYM_END, a);
            }
        }

        /* pass 2: reductions on FOLLOW(A) */
        for (int i = 0; i < st->set.count; i++) {
            const LRItem *it = &st->set.items[i];
            if (!item_is_complete(g, it) || it->prod == 0) continue;
            int A = g->prods[it->prod].lhs;
            for (int term = 0; term < nsym; term++) {
                if (!g->symbols[term].is_terminal || !SYMSET_HAS(t->ff.follow[A], term)) continue;
                Action a = { ACTION_REDUCE, it->prod };
                set_action(t, s, term, a);
            }
        }

        /* GOTO table: transitions on non-terminals */
        for (int X = 1; X < nsym; X++)
            if (!g->symbols[X].is_terminal && st->next[X] >= 0)
                t->go[(size_t)s * (size_t)nsym + (size_t)X] = st->next[X];
    }

    free(t->first_reduce);
    t->first_reduce = NULL;
    t->tables_built = 1;
    return t->num_conflicts;
}

int slr_generate(SLRTable *t, Grammar *g)
{
    if (slr_init(t, g) != 0) return -1;
    if (slr_build_states(t) < 0) return -1;
    if (slr_build_tables(t) < 0) return -1;
    return 0;
}

void slr_free(SLRTable *t)
{
    lr_collection_free(&t->lr);
    free(t->action);
    free(t->go);
    free(t->conflicts);
    free(t->first_reduce);
    memset(t, 0, sizeof *t);
}

/* ===================================================================== queries */

Action slr_get_action(const SLRTable *t, int state, int terminal)
{
    Action err = { ACTION_ERROR, 0 };
    if (!t->tables_built) return err;
    if (state < 0 || state >= t->num_states) return err;
    if (terminal < 0 || terminal >= t->num_symbols) return err;
    if (!t->grammar->symbols[terminal].is_terminal) return err;
    return t->action[(size_t)state * (size_t)t->num_symbols + (size_t)terminal];
}

int slr_get_goto(const SLRTable *t, int state, int nonterminal)
{
    if (!t->tables_built) return -1;
    if (state < 0 || state >= t->num_states) return -1;
    if (nonterminal < 0 || nonterminal >= t->num_symbols) return -1;
    if (t->grammar->symbols[nonterminal].is_terminal) return -1;
    return t->go[(size_t)state * (size_t)t->num_symbols + (size_t)nonterminal];
}

int slr_num_states(const SLRTable *t) { return t->num_states; }

int slr_prod_lhs(const SLRTable *t, int prod)
{
    if (prod < 0 || prod >= t->grammar->num_prods) return -1;
    return t->grammar->prods[prod].lhs;
}

int slr_prod_length(const SLRTable *t, int prod)
{
    if (prod < 0 || prod >= t->grammar->num_prods) return -1;
    return t->grammar->prods[prod].rhs_len;
}

int slr_is_slr1(const SLRTable *t) { return t->tables_built && t->num_conflicts == 0; }
int slr_conflict_count(const SLRTable *t) { return t->num_conflicts; }

const Conflict *slr_get_conflict(const SLRTable *t, int index)
{
    if (index < 0 || index >= t->num_conflicts) return NULL;
    return &t->conflicts[index];
}

/* ===================================================================== printing */

void slr_print_grammar(const SLRTable *t)         { grammar_print(t->grammar); }
void slr_print_first_follow(const SLRTable *t)    { first_follow_print(t->grammar, &t->ff); }
void slr_print_states(const SLRTable *t)          { lr_print_collection(&t->lr); }
void slr_print_transitions(const SLRTable *t)     { lr_print_transitions(&t->lr); }

static int is_conflict_cell(const SLRTable *t, int state, int term)
{
    for (int i = 0; i < t->num_conflicts; i++)
        if (t->conflicts[i].state == state && t->conflicts[i].terminal == term) return 1;
    return 0;
}

static void action_cell(const SLRTable *t, int state, int term, char *buf, size_t n)
{
    Action a = slr_get_action(t, state, term);
    switch (a.type) {
        case ACTION_SHIFT:  snprintf(buf, n, "s%d", a.value); break;
        case ACTION_REDUCE: snprintf(buf, n, "r%d", a.value); break;
        case ACTION_ACCEPT: snprintf(buf, n, "acc"); break;
        default:            buf[0] = '\0'; break;
    }
    if (is_conflict_cell(t, state, term) && strlen(buf) + 2 < n) strcat(buf, "*");
}

static int col_width(const char *name)
{
    int w = (int)strlen(name);
    return (w < 5 ? 5 : w) + 2;
}

void slr_print_action_table(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    printf("ACTION table  (sN = shift to state N, rN = reduce by production N, acc = accept,\n"
           "               blank = error, * = conflicting cell)\n");
    printf("%-7s", "State");
    for (int s = 0; s < g->num_symbols; s++)
        if (g->symbols[s].is_terminal) printf("%*s", col_width(g->symbols[s].name), g->symbols[s].name);
    printf("\n");
    for (int st = 0; st < t->num_states; st++) {
        printf("%-7d", st);
        for (int s = 0; s < g->num_symbols; s++) {
            if (!g->symbols[s].is_terminal) continue;
            char cell[32];
            action_cell(t, st, s, cell, sizeof cell);
            printf("%*s", col_width(g->symbols[s].name), cell);
        }
        printf("\n");
    }
}

void slr_print_goto_table(const SLRTable *t)
{
    const Grammar *g = t->grammar;
    printf("GOTO table  (blank = no transition)\n");
    printf("%-7s", "State");
    for (int s = 1; s < g->num_symbols; s++)
        if (!g->symbols[s].is_terminal && s != g->aug_start)
            printf("%*s", col_width(g->symbols[s].name), g->symbols[s].name);
    printf("\n");
    for (int st = 0; st < t->num_states; st++) {
        printf("%-7d", st);
        for (int s = 1; s < g->num_symbols; s++) {
            if (g->symbols[s].is_terminal || s == g->aug_start) continue;
            int d = slr_get_goto(t, st, s);
            char cell[16] = "";
            if (d >= 0) snprintf(cell, sizeof cell, "%d", d);
            printf("%*s", col_width(g->symbols[s].name), cell);
        }
        printf("\n");
    }
}

static void print_action_long(const SLRTable *t, int state, int term, Action a)
{
    const Grammar *g = t->grammar;
    switch (a.type) {
        case ACTION_SHIFT:
            printf("SHIFT %d   (transition: state %d --%s--> state %d)",
                   a.value, state, g->symbols[term].name, a.value);
            break;
        case ACTION_REDUCE:
            printf("REDUCE %d   (", a.value);
            grammar_print_production(g, a.value);
            printf(")");
            break;
        case ACTION_ACCEPT: printf("ACCEPT"); break;
        default:            printf("ERROR");  break;
    }
}

void slr_print_conflicts(const SLRTable *t)
{
    if (t->num_conflicts == 0) {
        printf("No conflicts: the grammar is SLR(1).\n");
        return;
    }
    printf("%d conflict(s) detected: the grammar is NOT SLR(1).\n", t->num_conflicts);
    for (int i = 0; i < t->num_conflicts; i++) {
        const Conflict *c = &t->conflicts[i];
        const char *kind = c->type == CONFLICT_SHIFT_REDUCE  ? "Shift/Reduce"
                         : c->type == CONFLICT_REDUCE_REDUCE ? "Reduce/Reduce" : "Other";
        printf("\nConflict detected:\n");
        printf("  Type:               %s\n", kind);
        printf("  State:              %d\n", c->state);
        printf("  Lookahead:          %s\n", t->grammar->symbols[c->terminal].name);
        printf("  Existing action:    ");
        print_action_long(t, c->state, c->terminal, c->existing);
        printf("\n  Conflicting action: ");
        print_action_long(t, c->state, c->terminal, c->conflicting);
        printf("\n");
    }
}
