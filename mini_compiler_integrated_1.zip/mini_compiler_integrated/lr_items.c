/* lr_items.c -- see lr_items.h for the algorithms */
#include "lr_items.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void *xrealloc(void *p, size_t n)
{
    void *q = realloc(p, n);
    if (!q) { fprintf(stderr, "lr_items: out of memory\n"); exit(1); }
    return q;
}

/* ------------------------------------------------------------------ items */

int item_compare(const LRItem *a, const LRItem *b)
{
    if (a->prod != b->prod) return a->prod < b->prod ? -1 : 1;
    if (a->dot  != b->dot)  return a->dot  < b->dot  ? -1 : 1;
    return 0;
}

int item_equal(const LRItem *a, const LRItem *b) { return item_compare(a, b) == 0; }

int item_is_complete(const Grammar *g, const LRItem *it)
{
    return it->dot >= g->prods[it->prod].rhs_len;
}

int item_next_symbol(const Grammar *g, const LRItem *it)
{
    return item_is_complete(g, it) ? -1 : g->prods[it->prod].rhs[it->dot];
}

int item_is_kernel(const LRItem *it) { return it->dot > 0 || it->prod == 0; }

/* -------------------------------------------------------------- item sets */

void itemset_init(ItemSet *s) { s->items = NULL; s->count = 0; s->cap = 0; }

void itemset_free(ItemSet *s) { free(s->items); itemset_init(s); }

/* Insert keeping the array sorted; reject duplicates. */
int itemset_add(ItemSet *s, LRItem it)
{
    int pos = 0;
    while (pos < s->count) {
        int c = item_compare(&s->items[pos], &it);
        if (c == 0) return 0;          /* already there */
        if (c > 0) break;              /* insertion point found */
        pos++;
    }
    if (s->count == s->cap) {
        s->cap = s->cap ? s->cap * 2 : 16;
        s->items = xrealloc(s->items, (size_t)s->cap * sizeof(LRItem));
    }
    memmove(&s->items[pos + 1], &s->items[pos], (size_t)(s->count - pos) * sizeof(LRItem));
    s->items[pos] = it;
    s->count++;
    return 1;
}

int itemset_contains(const ItemSet *s, LRItem it)
{
    for (int i = 0; i < s->count; i++)
        if (item_equal(&s->items[i], &it)) return 1;
    return 0;
}

/* Both sets are sorted and duplicate-free, so equality is element-wise. */
int itemset_equal(const ItemSet *a, const ItemSet *b)
{
    if (a->count != b->count) return 0;
    for (int i = 0; i < a->count; i++)
        if (!item_equal(&a->items[i], &b->items[i])) return 0;
    return 1;
}

void itemset_closure(const Grammar *g, ItemSet *s)
{
    int changed;
    do {
        changed = 0;
        for (int i = 0; i < s->count; i++) {
            int X = item_next_symbol(g, &s->items[i]);     /* symbol after the dot */
            if (X < 0 || g->symbols[X].is_terminal) continue;
            for (int p = 0; p < g->num_prods; p++) {       /* every  X -> gamma    */
                if (g->prods[p].lhs != X) continue;
                LRItem n = { p, 0 };
                if (itemset_add(s, n)) changed = 1;        /* may shift items; harmless, we loop again */
            }
        }
    } while (changed);
}

ItemSet itemset_goto(const Grammar *g, const ItemSet *s, int sym)
{
    ItemSet out;
    itemset_init(&out);
    for (int i = 0; i < s->count; i++) {
        if (item_next_symbol(g, &s->items[i]) == sym) {
            LRItem moved = { s->items[i].prod, s->items[i].dot + 1 };   /* move the dot over sym */
            itemset_add(&out, moved);
        }
    }
    if (out.count > 0) itemset_closure(g, &out);
    return out;
}

/* ------------------------------------------------------ canonical collection */

void lr_collection_init(LRCollection *c, const Grammar *g)
{
    c->g = g;
    c->states = NULL;
    c->num_states = 0;
    c->cap = 0;
}

int lr_collection_find(const LRCollection *c, const ItemSet *s)
{
    for (int i = 0; i < c->num_states; i++)
        if (itemset_equal(&c->states[i].set, s)) return i;
    return -1;
}

/* Takes ownership of *set.  Returns the new state number. */
static int add_state(LRCollection *c, ItemSet *set)
{
    if (c->num_states == c->cap) {
        c->cap = c->cap ? c->cap * 2 : 16;
        c->states = xrealloc(c->states, (size_t)c->cap * sizeof(LRState));
    }
    int id = c->num_states++;
    c->states[id].set = *set;
    itemset_init(set);
    c->states[id].next = xrealloc(NULL, (size_t)c->g->num_symbols * sizeof(int));
    for (int x = 0; x < c->g->num_symbols; x++) c->states[id].next[x] = -1;
    return id;
}

int lr_collection_build(LRCollection *c)
{
    const Grammar *g = c->g;
    if (!g->augmented) return -1;

    /* State 0 = CLOSURE({ S' -> . S }) */
    ItemSet start;
    itemset_init(&start);
    LRItem first = { 0, 0 };
    itemset_add(&start, first);
    itemset_closure(g, &start);
    add_state(c, &start);

    /* num_states grows while we loop: this is the work queue */
    for (int s = 0; s < c->num_states; s++) {
        for (int X = 1; X < g->num_symbols; X++) {        /* X = 0 is '$', never shifted */
            ItemSet nxt = itemset_goto(g, &c->states[s].set, X);
            if (nxt.count == 0) { itemset_free(&nxt); continue; }

            int t = lr_collection_find(c, &nxt);
            if (t < 0) t = add_state(c, &nxt);            /* new state */
            else       itemset_free(&nxt);                /* duplicate: reuse existing state */

            c->states[s].next[X] = t;                     /* re-index: states[] may have moved */
        }
    }
    return c->num_states;
}

void lr_collection_free(LRCollection *c)
{
    for (int i = 0; i < c->num_states; i++) {
        itemset_free(&c->states[i].set);
        free(c->states[i].next);
    }
    free(c->states);
    lr_collection_init(c, c->g);
}

/* ---------------------------------------------------------------- printing */

void lr_print_item(const Grammar *g, const LRItem *it)
{
    const Production *p = &g->prods[it->prod];
    printf("%s ->", g->symbols[p->lhs].name);
    for (int i = 0; i <= p->rhs_len; i++) {
        if (i == it->dot) printf(" .");
        if (i < p->rhs_len) printf(" %s", g->symbols[p->rhs[i]].name);
    }
}

void lr_print_itemset(const Grammar *g, const ItemSet *s)
{
    printf("  Kernel:\n");
    for (int i = 0; i < s->count; i++)
        if (item_is_kernel(&s->items[i])) { printf("    "); lr_print_item(g, &s->items[i]); printf("\n"); }

    int any = 0;
    for (int i = 0; i < s->count; i++) if (!item_is_kernel(&s->items[i])) any = 1;
    if (any) {
        printf("  Closure:\n");
        for (int i = 0; i < s->count; i++)
            if (!item_is_kernel(&s->items[i])) { printf("    "); lr_print_item(g, &s->items[i]); printf("\n"); }
    }
}

void lr_print_collection(const LRCollection *c)
{
    const Grammar *g = c->g;
    printf("Canonical collection of LR(0) item sets: %d states\n", c->num_states);
    for (int s = 0; s < c->num_states; s++) {
        printf("\nState %d:\n", s);
        lr_print_itemset(g, &c->states[s].set);
        int any = 0;
        for (int X = 0; X < g->num_symbols; X++) if (c->states[s].next[X] >= 0) any = 1;
        if (any) {
            printf("  Transitions:\n");
            for (int X = 0; X < g->num_symbols; X++)
                if (c->states[s].next[X] >= 0)
                    printf("    on %-12s -> State %d\n", g->symbols[X].name, c->states[s].next[X]);
        }
    }
}

void lr_print_transitions(const LRCollection *c)
{
    const Grammar *g = c->g;
    printf("State transitions (GOTO function on the LR(0) automaton):\n");
    for (int s = 0; s < c->num_states; s++)
        for (int X = 0; X < g->num_symbols; X++)
            if (c->states[s].next[X] >= 0)
                printf("  I%-3d --%s--> I%d\n", s, g->symbols[X].name, c->states[s].next[X]);
}
