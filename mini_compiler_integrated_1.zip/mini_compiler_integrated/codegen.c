#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codegen.h"

static const char *MN[] = {"LOADI", "FLOADI", "LOAD", "STORE", "MOV", "ADD", "SUB", "MUL", "DIV", "AND", "OR", "XOR",
                           "NOT", "NEG", "FADD", "FSUB", "FMUL", "FDIV", "FNEG", "ITOF", "HALT"};
static const Op OPM[] = {OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_AND, OP_OR, OP_XOR, OP_NOT, OP_NEG,
                         OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_NEG, OP_ITOF};

static Target *T;
static int occ[NREG], *last, cur;

static void put(MOp op, int rd, int s1, int s2, int mem, Operand imm) {
    MInstr m = {op, rd, s1, s2, mem, imm};
    if (T->n == T->cap) {
        T->cap = T->cap ? T->cap * 2 : 16;
        T->code = realloc(T->code, T->cap * sizeof(MInstr));
    }
    T->code[T->n++] = m;
}

static int find(int t) {
    for (int r = 0; r < NREG; r++) if (occ[r] == t) return r;
    return -1;
}

static int getreg(int lock) {
    int best = -1;
    for (int r = 0; r < NREG; r++) if (!occ[r]) return r;
    for (int r = 0; r < NREG; r++)
        if (!((lock >> r) & 1) && (best < 0 || last[occ[r]] > last[occ[best]])) best = r;
    put(M_STORE, 0, best, 0, occ[best], (Operand){0});
    occ[best] = 0;
    return best;
}

static int operand(Operand o, int lock) {
    int r = o.k == K_TEMP ? find(o.t) : -1;
    if (r >= 0) return r;
    r = getreg(lock);
    if (o.k == K_CONST) { put(o.d == T_INT ? M_LOADI : M_FLOADI, r, 0, 0, 0, o); occ[r] = -1; }
    else if (o.k == K_VAR) { put(M_LOAD, r, 0, 0, -o.t - 1, (Operand){0}); occ[r] = -1; }
    else { put(M_LOAD, r, 0, 0, o.t, (Operand){0}); occ[r] = o.t; }
    return r;
}

static void rel(int r, int i) {
    if (r >= 0 && (occ[r] == -1 || (occ[r] > 0 && last[occ[r]] <= i))) occ[r] = 0;
}

static MOp pick(const TAC *c) {
    int f = c->type == T_FLOAT;
    switch (c->op) {
    case OP_ADD: return f ? M_FADD : M_ADD;
    case OP_SUB: return f ? M_FSUB : M_SUB;
    case OP_MUL: return f ? M_FMUL : M_MUL;
    case OP_DIV: return f ? M_FDIV : M_DIV;
    case OP_AND: return M_AND;
    case OP_OR: return M_OR;
    case OP_XOR: return M_XOR;
    case OP_NOT: return M_NOT;
    case OP_NEG: return f ? M_FNEG : M_NEG;
    case OP_ITOF: return M_ITOF;
    default: return M_MOV;
    }
}

static void gen(const IR *ir, int i) {
    const TAC *c = &ir->code[i];
    Operand z = {0};
    int ra = -1, rb = -1, rd;
    cur = i;
    if (c->form == F_ASSIGN && c->a.k != K_TEMP) {
        rd = getreg(0);
        if (c->a.k == K_CONST) put(c->type == T_FLOAT ? M_FLOADI : M_LOADI, rd, 0, 0, 0, c->a);
        else put(M_LOAD, rd, 0, 0, -c->a.t - 1, z);
    } else {
        int lock;
        ra = operand(c->a, 0);
        if (ra < 0 || ra >= NREG) return;
        if (c->form == F_BINARY) rb = operand(c->b, 1 << ra);
        rel(ra, i);
        rel(rb, i);
        lock = (occ[ra] ? 1 << ra : 0) | (rb >= 0 && occ[rb] ? 1 << rb : 0);
        rd = !occ[ra] ? ra : (rb >= 0 && !occ[rb]) ? rb : getreg(lock);
        if (c->op == OP_ASSIGN) { if (rd != ra) put(M_MOV, rd, ra, 0, 0, z); }
        else put(pick(c), rd, ra, rb < 0 ? 0 : rb, 0, z);
    }
    occ[rd] = c->res;
    if (i == ir->n - 1) put(M_STORE, 0, rd, 0, 0, z);
    else if (last[c->res] <= i) occ[rd] = 0;
}

void cg_generate(const IR *ir, Target *t) {
    *t = (Target){0};
    t->ntemp = ir->ntemp;
    if (ir->n) t->rtype = ir->code[ir->n - 1].type;
    T = t;
    last = malloc((ir->ntemp + 1) * sizeof(int));
    for (int i = 0; i <= ir->ntemp; i++) last[i] = -1;
    for (int i = 0; i < NREG; i++) occ[i] = 0;
    for (int i = 0; i < ir->n; i++) {
        const TAC *c = &ir->code[i];
        if (c->a.k == K_TEMP) last[c->a.t] = i;
        if (c->form == F_BINARY && c->b.k == K_TEMP) last[c->b.t] = i;
    }
    for (int i = 0; i < ir->n; i++) gen(ir, i);
    put(M_HALT, 0, 0, 0, 0, (Operand){0});
    free(last);
}

void cg_print(const Target *t) {
    char s[96], addr[32], num[48];
    printf("\n--- Target Code ---\n");
    for (int i = 0; i < t->n; i++) {
        const MInstr *m = &t->code[i];
        if (m->mem > 0) sprintf(addr, "[T%d]", m->mem);
        else if (m->mem == 0) strcpy(addr, "[RESULT]");
        else sprintf(addr, "[%s]", ir_var_name(-m->mem - 1));
        switch (m->op) {
        case M_LOADI: sprintf(s, "R%d, #%lld", m->rd, m->imm.i); break;
        case M_FLOADI: ir_fmt_double(num, m->imm.f); sprintf(s, "R%d, #%s", m->rd, num); break;
        case M_LOAD: sprintf(s, "R%d, %s", m->rd, addr); break;
        case M_STORE: sprintf(s, "%s, R%d", addr, m->rs1); break;
        case M_MOV: case M_NOT: case M_NEG: case M_FNEG: case M_ITOF: sprintf(s, "R%d, R%d", m->rd, m->rs1); break;
        case M_HALT: s[0] = 0; break;
        default: sprintf(s, "R%d, R%d, R%d", m->rd, m->rs1, m->rs2);
        }
        printf("  %2d: %-7s %s\n", i, MN[m->op], s);
    }
}

Operand cg_run(const Target *t) {
    Operand R[NREG] = {{0}}, *M = calloc(t->ntemp + 1, sizeof *M), o = {0};
    for (int i = 0; i < t->n; i++) {
        const MInstr *m = &t->code[i];
        switch (m->op) {
        case M_LOADI: case M_FLOADI: R[m->rd] = m->imm; break;
        case M_LOAD: R[m->rd] = m->mem < 0 ? ir_var_get(-m->mem - 1) : M[m->mem]; break;
        case M_STORE: M[m->mem] = R[m->rs1]; break;
        case M_MOV: R[m->rd] = R[m->rs1]; break;
        case M_HALT: o = M[0]; free(M); return o;
        default:
            ir_apply(OPM[m->op - M_ADD], m->op >= M_FADD ? T_FLOAT : T_INT, R[m->rs1], R[m->rs2], &R[m->rd]);
        }
    }
    free(M);
    return o;
}

void cg_free(Target *t) { free(t->code); *t = (Target){0}; }
