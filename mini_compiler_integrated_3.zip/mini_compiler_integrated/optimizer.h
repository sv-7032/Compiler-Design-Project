#ifndef OPTIMIZER_H
#define OPTIMIZER_H
#include "ir.h"

typedef struct { int folded, propagated, simplified, removed, rounds, before_n, after_n, fixed; } OptStats;

/* One transformation, recorded by a pass at the moment it rewrites an instruction. */
typedef struct { int line; char before[96], after[96], rule[48], why[400]; } OptChange;
typedef struct { OptChange *v; int n, cap; } OptLog;

void opt_log_free(OptLog *l);

/* Each pass returns the number of transformations; log may be NULL (no logging). */
int opt_fold(IR *ir, OptLog *log);
int opt_propagate(IR *ir, OptLog *log);
int opt_simplify(IR *ir, OptLog *log);
int opt_dead(IR *ir, OptLog *log);

OptStats opt_run(IR *ir, int verbose);     /* verbose = print every pass: before, changes, after */
void opt_print(const IR *ir, const OptStats *s);

#endif
