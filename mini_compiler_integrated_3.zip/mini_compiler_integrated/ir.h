#ifndef IR_H
#define IR_H

typedef enum { T_INT, T_FLOAT } DType;
typedef enum { OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_AND, OP_OR, OP_XOR, OP_NOT, OP_NEG, OP_POS, OP_ITOF, OP_ASSIGN } Op;
typedef enum { K_NONE, K_CONST, K_TEMP, K_VAR } OKind;
typedef enum { F_ASSIGN, F_UNARY, F_BINARY } Form;

typedef struct { OKind k; DType d; long long i; double f; int t; } Operand;
typedef struct { Op op; Form form; Operand a, b; int res; DType type; } TAC;
typedef struct { TAC *code; int n, cap, ntemp; } IR;

void ir_init(IR *ir);
void ir_free(IR *ir);
void ir_copy(IR *dst, const IR *src);
void ir_delete(IR *ir, int idx);

Operand ir_int(long long v);
Operand ir_float(double v);
Operand ir_var(const char *name, DType d);
void ir_bind(Operand var, Operand value);
const char *ir_var_name(int id);
Operand ir_var_get(int id);
DType ir_promote(DType a, DType b);

Operand ir_binary(IR *ir, Op op, Operand l, Operand r, DType result);
Operand ir_unary(IR *ir, Op op, Operand a, DType result);
void ir_finish(IR *ir, Operand top);
Operand ir_result(const IR *ir);

int ir_apply(Op op, DType ty, Operand a, Operand b, Operand *out);
Operand ir_eval(const IR *ir);

void ir_fmt(char *buf, Operand o);
void ir_fmt_double(char *buf, double v);
void ir_fmt_tac(const TAC *c, char *buf);   /* one instruction, e.g. "t1 = 5 * 2" (buf >= 160 bytes) */
void ir_print(const IR *ir, const char *title);

#endif
