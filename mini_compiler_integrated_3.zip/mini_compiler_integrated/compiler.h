#ifndef MINI_COMPILER_H
#define MINI_COMPILER_H
#include "grammar.h"
#include "syntax_table.h"
#include "lexer.h"
#include "ir.h"
#include "reduction.h"

/* Outcome of one table-driven parse (all fields are filled in by the parser itself). */
typedef struct {
    int accepted;           /* 1 = ACCEPT reached                                  */
    int steps, shifts, reduces;
    int err_pos, err_state; /* token index / state where the error action was hit  */
    char err_token[64];
    char expected[256];     /* terminals with a non-error ACTION in err_state       */
    Operand result;         /* semantic value of the start symbol                   */
} ParseSummary;

/* Parses tokens with the generated ACTION/GOTO table. The caller supplies a fresh IR and a fresh
 * (initialised) ReductionHistory for every expression. verbose = print the step-by-step trace. */
int  compiler_parse(const Grammar *g, const SLRTable *table, const Token *tokens, int ntokens,
                    IR *ir, ReductionHistory *hist, ParseSummary *sum, int verbose);
int  compiler_token_terminal(const Grammar *g, TokenType type);
void compiler_print_tokens(const Token *tokens, int n);
void compiler_print_derivation(const Grammar *g, const ReductionHistory *hist);

#endif
