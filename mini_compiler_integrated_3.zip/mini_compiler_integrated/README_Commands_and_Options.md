# Mini Compiler: Make Commands and Command-Line Options

Quick reference for building, testing and running the project, and for finding where each option is handled in `main.c`.

## Quick start

```sh
make                              # build ./mini_compiler
./mini_compiler "3 + 5 * 2"       # run on one expression
make test                         # run all tests and demos
```

Run these from the folder that contains the `Makefile`. You need `gcc` and `make` installed. On Windows, use `build.bat` instead, or `mingw32-make` if you have MinGW. `build.bat` has not been run.

## Make commands

| Command | What it does |
| --- | --- |
| `make` | Builds `./mini_compiler` |
| `make test` | Builds, then runs `test_slr`, `test_opt`, the quiet demo and the conflict demo |
| `make test_slr` | Only builds the table-generator tests (run them with `./test_slr`) |
| `make test_opt` | Only builds the optimizer tests (run them with `./test_opt`) |
| `make clean` | Deletes the object files and the built programs |

If you edit a `.h` file, run `make clean && make`. The Makefile does not track header dependencies.

## Options for `./mini_compiler`

Put your expression in quotes. With no expression it uses `3 + 5 * 2`.

| Option | Effect |
| --- | --- |
| *(none)* | Prints all 11 sections |
| `--quiet` | Hides sections 1–7 and prints only sections 8–11 |
| `--table` | Does nothing now, because tables are shown by default (kept for compatibility) |
| `--no-table` | Hides sections 2–5 (grammar, item sets, tables, conflicts) |
| `--opt-brief` | The optimizer prints only the final TAC and a summary |
| `--no-opt` | Skips the optimizer, so the code generator gets the original TAC |
| `--demo` | Runs 9 valid and 3 invalid expressions through the whole pipeline |
| `--conflict-demo` | Runs the table generator on two non-SLR(1) grammars and prints the conflict reports |

Options can be combined:

```sh
./mini_compiler --no-table --opt-brief "3 + 5 * 2"
```

Test programs: `./test_slr -v` prints every check, and `./test_opt` runs the optimizer tests. `test_opt` accepts `-v` but currently ignores it.

## Where the options live in the code

Everything is in `main.c`. Line numbers are from the delivered version and will shift if you edit the file.

- **Line 9:** the `Opts` struct holds the flags (`quiet, tables, optdetail, noopt`).
- **Line 118:** `main()` sets their defaults (`Opts o = {0, 1, 1, 0}`).
- **Lines 120–126:** the argument loop, with one `else if (!strcmp(argv[i], "--something"))` per option.
- **Where each flag takes effect**, inside `run_one` and `main`:
  - `--quiet` is at line 54 (`v = !o->quiet`).
  - `--no-table` is at lines 59–60.
  - `--no-opt` is at line 84.
  - `--opt-brief` is at line 85.
  - `--demo` is the test list in `main`.
  - `--conflict-demo` calls the function at line 96.

## When each option was added

- `--quiet`, `--table` and `--demo` were in the original project; they appear in its README and Makefile.
- `--no-table` and `--conflict-demo` came in the first revision, the syntax-analyzer rework.
- `--opt-brief` and `--no-opt` came in the latest revision.

## How to add an option

1. Add a field to `Opts` (line 9) and give it a default on line 118.
2. Add one `else if (!strcmp(argv[i], "--yourflag")) o.yourfield = ...;` line in the loop at lines 120–126.
3. Read `o->yourfield` where you want the behavior to change, usually in `run_one`.

The project's main `README.md` and `AUDIT_REPORT.md` also list these options. If you add one, update the README option table too.
