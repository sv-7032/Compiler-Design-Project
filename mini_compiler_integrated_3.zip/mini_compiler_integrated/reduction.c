#include <stdlib.h>
#include <string.h>
#include "reduction.h"

static char *dup_str(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (p) memcpy(p, s, n);
    return p;
}

void reduction_init(ReductionHistory *h) { h->recs = NULL; h->count = 0; h->cap = 0; }

void reduction_free(ReductionHistory *h) {
    for (int i = 0; i < h->count; i++) {
        free(h->recs[i].production);   free(h->recs[i].stack_before);
        free(h->recs[i].stack_after);  free(h->recs[i].remaining_input);
        free(h->recs[i].action);       free(h->recs[i].emitted);
    }
    free(h->recs);
    reduction_init(h);
}

int reduction_add(ReductionHistory *h, int prod_no, const char *production,
                  const char *before, const char *after,
                  const char *input, const char *action) {
    if (h->count == h->cap) {
        int nc = h->cap ? h->cap * 2 : 16;
        ReductionRecord *nr = realloc(h->recs, (size_t)nc * sizeof *nr);
        if (!nr) return 0;
        h->recs = nr; h->cap = nc;
    }
    ReductionRecord *r = &h->recs[h->count];
    r->seq = h->count + 1;
    r->prod_no = prod_no;
    r->production = dup_str(production);
    r->stack_before = dup_str(before);
    r->stack_after = dup_str(after);
    r->remaining_input = dup_str(input);
    r->action = dup_str(action);
    r->emitted = dup_str("");
    h->count++;
    return 1;
}

int reduction_set_emitted(ReductionHistory *h, const char *tac) {
    if (!h->count) return 0;
    free(h->recs[h->count - 1].emitted);
    h->recs[h->count - 1].emitted = dup_str(tac);
    return 1;
}

void reduction_print(const ReductionHistory *h, FILE *out) {
    fprintf(out, "%d reductions applied, in the order the parser performed them:\n\n", h->count);
    for (int i = 0; i < h->count; i++) {
        const ReductionRecord *r = &h->recs[i];
        fprintf(out, "#%-2d [%s] %s\n", r->seq, r->action, r->production);
        fprintf(out, "     stack : %s   =>   %s\n", r->stack_before, r->stack_after);
        fprintf(out, "     input : %s\n", r->remaining_input);
        if (r->emitted[0]) fprintf(out, "     emits : %s\n", r->emitted);
    }
    fprintf(out, "\nReduction sequence (production numbers):");
    for (int i = 0; i < h->count; i++) fprintf(out, " %d", h->recs[i].prod_no);
    fprintf(out, "\n");
}

void reduction_print_emitters(const ReductionHistory *h, FILE *out) {
    for (int i = 0; i < h->count; i++) {
        const ReductionRecord *r = &h->recs[i];
        if (r->emitted[0]) fprintf(out, "  reduction #%-2d  %-26s -> %s\n", r->seq, r->production, r->emitted);
    }
}
