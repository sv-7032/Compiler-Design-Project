#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "optimizer.h"

#define MAXIT 10
#define R(x, rule, why) (r = (x), ok = 1, rl = (rule), wy = (why))

static int isc(Operand o, int v) { return o.k == K_CONST && (o.d == T_INT ? o.i == v : o.f == v); }
/* Bitwise identities that hand back an operand (x|0 => x ...) are only valid when that operand is already an int:
 * a bitwise op truncates float operands to int, so returning a float operand unchanged would change the value's type. */
static int same(Operand a, Operand b) { return a.k == b.k && (a.k == K_TEMP || a.k == K_VAR) && a.t == b.t; }

static void to_assign(TAC *c, Operand r) {
    c->form = F_ASSIGN; c->op = OP_ASSIGN; c->a = r; c->b = (Operand){0};
}

static void log_add(OptLog *l, int line, const char *before, const char *after, const char *rule, const char *why) {
    OptChange *c;
    if (!l) return;
    if (l->n == l->cap) {
        OptChange *nv = realloc(l->v, (l->cap ? l->cap * 2 : 8) * sizeof *nv);
        if (!nv) { fprintf(stderr, "optimizer: out of memory\n"); exit(1); }
        l->v = nv; l->cap = l->cap ? l->cap * 2 : 8;
    }
    c = &l->v[l->n++];
    c->line = line;
    snprintf(c->before, sizeof c->before, "%s", before);
    snprintf(c->after, sizeof c->after, "%s", after);
    snprintf(c->rule, sizeof c->rule, "%s", rule);
    snprintf(c->why, sizeof c->why, "%s", why);
}

void opt_log_free(OptLog *l) { free(l->v); *l = (OptLog){0}; }

int opt_fold(IR *ir, OptLog *log) {
    int n = 0;
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand o;
        char b[160], a[160], x[48], y[48], w[400];
        if (c->form == F_ASSIGN || c->a.k != K_CONST) continue;
        if (c->form == F_BINARY && c->b.k != K_CONST) continue;
        if (log) { ir_fmt_tac(c, b); ir_fmt(x, c->a); ir_fmt(y, c->b); }
        if (ir_apply(c->op, c->type, c->a, c->b, &o)) {
            int bin = c->form == F_BINARY;
            to_assign(c, o); n++;
            if (log) {
                ir_fmt_tac(c, a);
                if (bin) snprintf(w, sizeof w, "operands %s and %s are both constants, so the operation is evaluated now with the same arithmetic the target machine uses (32-bit wraparound for int, IEEE double for float)", x, y);
                else snprintf(w, sizeof w, "the operand %s is a constant, so the unary operation / conversion is evaluated now", x);
                log_add(log, i + 1, b, a, bin ? "fold binary operation on two constants" : "fold unary operation on a constant", w);
            }
        }
    }
    return n;
}

int opt_propagate(IR *ir, OptLog *log) {
    int n = 0, m = ir->ntemp + 1;
    Operand *v = calloc(m, sizeof *v);
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand *p[2] = {&c->a, &c->b};
        for (int j = 0; j < (c->form == F_BINARY ? 2 : 1); j++)
            if (p[j]->k == K_TEMP && v[p[j]->t].k != K_NONE) {
                Operand src = v[p[j]->t];
                char b[160], a[160], tn[48], sv[48], w[400];
                if (log) { ir_fmt_tac(c, b); ir_fmt(tn, *p[j]); ir_fmt(sv, src); }
                *p[j] = src; n++;
                if (log) {
                    ir_fmt_tac(c, a);
                    if (src.k == K_CONST) snprintf(w, sizeof w, "%s was assigned the constant %s and every temporary is assigned exactly once, so %s still holds %s at this use", tn, sv, tn, sv);
                    else snprintf(w, sizeof w, "%s is only a copy of %s (assigned once, never changed), so this use can read %s directly", tn, sv, sv);
                    log_add(log, i + 1, b, a, src.k == K_CONST ? "constant propagation" : "copy propagation", w);
                }
            }
        for (int u = 1; u < m; u++) if (v[u].k == K_TEMP && v[u].t == c->res) v[u] = (Operand){0};
        v[c->res] = (Operand){0};
        if (c->form == F_ASSIGN && c->a.k != K_NONE && !(c->a.k == K_TEMP && c->a.t == c->res)) v[c->res] = c->a;
    }
    free(v);
    return n;
}

int opt_simplify(IR *ir, OptLog *log) {
    int n = 0;
    for (int i = 0; i < ir->n; i++) {
        TAC *c = &ir->code[i];
        Operand a = c->a, b = c->b, r = {0};
        int ok = 0, fl = c->type == T_FLOAT;
        const char *rl = "", *wy = "";
        char bt[160], at[160];
        if (c->form != F_BINARY) continue;
        if (log) ir_fmt_tac(c, bt);
        switch (c->op) {
        case OP_ADD:
            if (!fl) {
                if (isc(b, 0)) R(a, "x + 0  =>  x", "adding integer 0 never changes a value");
                else if (isc(a, 0)) R(b, "0 + x  =>  x", "adding integer 0 never changes a value");
            }
            break;
        case OP_SUB:
            if (isc(b, 0) && (!fl || !signbit(b.f))) R(a, "x - 0  =>  x", "subtracting 0 never changes a value");
            else if (!fl && same(a, b)) R(ir_int(0), "x - x  =>  0", "an integer minus itself is always 0");
            break;
        case OP_MUL:
            if (isc(b, 1)) R(a, "x * 1  =>  x", "multiplying by 1 never changes a value");
            else if (isc(a, 1)) R(b, "1 * x  =>  x", "multiplying by 1 never changes a value");
            else if (!fl && (isc(a, 0) || isc(b, 0))) R(ir_int(0), "x * 0  =>  0", "an integer times 0 is 0 (not applied to float: NaN, infinity and -0.0 would differ)");
            break;
        case OP_DIV:
            if (isc(b, 1)) R(a, "x / 1  =>  x", "dividing by 1 never changes a value");
            break;
        case OP_AND:
            if (fl) break;
            if (isc(a, 0) || isc(b, 0)) R(ir_int(0), "x & 0  =>  0", "ANDing with 0 clears every bit");
            else if (isc(b, -1) && a.d == T_INT) R(a, "x & -1  =>  x", "-1 has every bit set, so ANDing keeps every bit of x");
            else if (isc(a, -1) && b.d == T_INT) R(b, "-1 & x  =>  x", "-1 has every bit set, so ANDing keeps every bit of x");
            else if (same(a, b) && a.d == T_INT) R(a, "x & x  =>  x", "a value ANDed with itself is unchanged");
            break;
        case OP_OR:
            if (fl) break;
            if (isc(a, -1) || isc(b, -1)) R(ir_int(-1), "x | -1  =>  -1", "ORing with -1 sets every bit");
            else if (isc(b, 0) && a.d == T_INT) R(a, "x | 0  =>  x", "ORing with 0 changes no bit");
            else if (isc(a, 0) && b.d == T_INT) R(b, "0 | x  =>  x", "ORing with 0 changes no bit");
            else if (same(a, b) && a.d == T_INT) R(a, "x | x  =>  x", "a value ORed with itself is unchanged");
            break;
        case OP_XOR:
            if (fl) break;
            if (isc(b, 0) && a.d == T_INT) R(a, "x ^ 0  =>  x", "XOR with 0 changes no bit");
            else if (isc(a, 0) && b.d == T_INT) R(b, "0 ^ x  =>  x", "XOR with 0 changes no bit");
            else if (same(a, b)) R(ir_int(0), "x ^ x  =>  0", "a value XORed with itself is 0");
            break;
        default: break;
        }
        if (ok) {
            to_assign(c, r); n++;
            if (log) { ir_fmt_tac(c, at); log_add(log, i + 1, bt, at, rl, wy); }
        }
    }
    return n;
}

int opt_dead(IR *ir, OptLog *log) {
    int n = 0;
    char *live = calloc(ir->ntemp + 1, 1);
    if (ir->n) live[ir->code[ir->n - 1].res] = 1;
    for (int i = ir->n - 1; i >= 0; i--) {
        TAC *c = &ir->code[i];
        if (!live[c->res]) {
            if (log) {
                char b[160], w[200];
                ir_fmt_tac(c, b);
                snprintf(w, sizeof w, "t%d is not read by any later instruction and is not the final result; the instruction has no side effect, so deleting it cannot change the result", c->res);
                log_add(log, i + 1, b, "(removed)", "dead temporary elimination", w);
            }
            ir_delete(ir, i); n++; continue;
        }
        live[c->res] = 0;
        if (c->a.k == K_TEMP) live[c->a.t] = 1;
        if (c->form == F_BINARY && c->b.k == K_TEMP) live[c->b.t] = 1;
    }
    free(live);
    return n;
}

static const struct { const char *name, *idle; } PASS[4] = {
    {"Constant Folding", "no instruction has only constant operands"},
    {"Constant & Copy Propagation", "no temporary currently holds a known constant or copy"},
    {"Algebraic Simplification", "no identity pattern such as x+0, x*1, x&x found"},
    {"Dead Temporary Elimination", "every temporary is used or is the final result"}};

static void show(const char *label, const IR *ir) {
    char line[160];
    printf("   %s:\n", label);
    if (!ir->n) printf("      (empty)\n");
    for (int i = 0; i < ir->n; i++) { ir_fmt_tac(&ir->code[i], line); printf("     %2d: %s\n", i + 1, line); }
}

static void report(int p, int k, const IR *before, const IR *after, OptLog *log) {
    printf("Pass %d  %s: ", p + 1, PASS[p].name);
    if (!k) { printf("no transformations (%s)\n", PASS[p].idle); return; }
    printf("%d transformation%s\n", k, k == 1 ? "" : "s");
    show("Before", before);
    for (int i = 1; i < log->n; i++) {                    /* stable insertion sort by line number */
        OptChange t = log->v[i]; int j = i - 1;
        while (j >= 0 && log->v[j].line > t.line) { log->v[j + 1] = log->v[j]; j--; }
        log->v[j + 1] = t;
    }
    printf("   Changes:\n");
    for (int i = 0; i < log->n; i++) {
        const OptChange *c = &log->v[i];
        printf("     line %d: %s   =>   %s\n", c->line, c->before, c->after);
        printf("             rule: %s\n             why : %s\n", c->rule, c->why);
    }
    show("After", after);
}

OptStats opt_run(IR *ir, int verbose) {
    int (*pass[4])(IR *, OptLog *) = {opt_fold, opt_propagate, opt_simplify, opt_dead};
    OptStats s = {0};
    int *cnt[4] = {&s.folded, &s.propagated, &s.simplified, &s.removed};
    s.before_n = ir->n;
    if (verbose) {
        printf("Pass order in every round: 1 folding -> 2 propagation -> 3 simplification -> 4 dead-temporary elimination.\n"
               "Rounds repeat until one full round changes nothing (limit %d).\n", MAXIT);
        show("Input TAC", ir);
    }
    for (int r = 1; r <= MAXIT; r++) {
        int ch = 0;
        s.rounds = r;
        if (verbose) printf("\n-- Round %d --\n", r);
        for (int p = 0; p < 4; p++) {
            OptLog log = {0};
            IR snap = {0};
            int k;
            if (verbose) ir_copy(&snap, ir);
            k = pass[p](ir, verbose ? &log : NULL);
            *cnt[p] += k;
            ch += k;
            if (verbose) { report(p, k, &snap, ir, &log); ir_free(&snap); opt_log_free(&log); }
        }
        if (!ch) {
            s.fixed = 1;
            if (verbose) printf("Round %d changed nothing: the code has reached a fixed point, so the optimizer stops.\n", r);
            break;
        }
    }
    if (verbose && !s.fixed) printf("Stopped after %d rounds (limit); more changes may still be possible.\n", MAXIT);
    s.after_n = ir->n;
    return s;
}

void opt_print(const IR *ir, const OptStats *s) {
    ir_print(ir, "Optimized TAC (this is what the target-code generator receives)");
    printf("  [folded=%d propagated=%d simplified=%d removed=%d | %d -> %d instructions | %d round%s%s]\n",
           s->folded, s->propagated, s->simplified, s->removed, s->before_n, s->after_n,
           s->rounds, s->rounds == 1 ? "" : "s", s->fixed ? ", the last one changed nothing" : ", limit reached");
}
