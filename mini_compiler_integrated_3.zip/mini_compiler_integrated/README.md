# Mini Compiler (C99) — Shift-Reduce Syntax Analyzer with Intermediate Code Generation

**Project title:** *Design and Implementation of a Shift-Reduce Syntax Analyzer with Stack-Based Parsing, Reduction Tracking, Conflict Detection, and Intermediate Code Generation.*

The syntax analyzer is the primary contribution: an SLR(1) parsing table is **generated algorithmically from the grammar**, conflicts are detected during table construction, and a table-driven shift-reduce parser with an explicit stack and a reduction history parses each expression. Three-address code (TAC) generation shows how parsing feeds the rest of the compiler. **Code optimization and target-code generation are supporting phases**; they are fully functional but deliberately secondary in the output.

## Documentation map

| Document | Purpose |
| --- | --- |
| **`README.md`** (this file) | Master overview: scope, architecture, flow, build/run, output explanation, limitations. |
| `docs/Source_Code_Reference.md` | Every `.c` and `.h` file explained, shared structures, dependency tables and diagrams. |
| `docs/Aditya_Study_Guide.md` | Lexer, tokens, grammar design — walkthroughs, concepts, viva Q&A. |
| `docs/Mahendra_Study_Guide.md` | LR(0) items, FIRST/FOLLOW, SLR(1) tables, conflict detection — walkthroughs, viva Q&A. |
| `docs/Arnav_Study_Guide.md` | Shift-reduce parser, reduction tracking, semantic actions — walkthroughs, viva Q&A. |
| `docs/Sarvesh_Study_Guide.md` | TAC, optimizer, target code — walkthroughs, viva Q&A. |
| `docs/Optimization_Walkthrough.md` | Every optimization actually implemented, with real before/after output, tests, limits. |
| `docs/Beginners_Complete_Learning_Guide.md` | C/header/linking fundamentals, one expression end to end, data structures, algorithms, FAQ. |
| `docs/Modification_and_Testing_Report.md` | What changed, bugs found, every test that was run with its real result. |
| `AUDIT_REPORT.md` | Earlier audit notes plus a summary of the revisions. |

## 1. Objectives and scope

* Generate ACTION/GOTO tables from the grammar (nothing hard-coded) and **detect shift/reduce and reduce/reduce conflicts as the table is filled**.
* Parse with an explicit stack of (state, symbol, semantic value); every decision comes from the table; show every step.
* Track and display every reduction; rebuild the rightmost derivation from the recorded reductions.
* Generate TAC from the reductions; optimize it; generate code for a small register machine; cross-check all three results.

## 2. Supported language

Integer and floating-point constants; binary `+ - * /`, `& | ^`; unary `+ - ~`; parentheses.
Precedence (high → low): parentheses · unary `+ - ~` · `* /` · `+ -` · `&` · `^` · `|`. Binary operators are left-associative. Integers are 32-bit (wraparound); mixed int/float arithmetic promotes to float; `/` on ints truncates.

```
Terminals   : $ PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT_CONST FLOAT_CONST
Non-terminals: Expr Xor And Sum Term Unary Factor Expr'
Start symbol : Expr
Productions (0 = augmented):
  [ 0] Expr' -> Expr
  [ 1] Expr -> Expr PIPE Xor
  [ 2] Expr -> Xor
  [ 3] Xor -> Xor CARET And
  [ 4] Xor -> And
  [ 5] And -> And AMP Sum
  [ 6] And -> Sum
  [ 7] Sum -> Sum PLUS Term
  [ 8] Sum -> Sum MINUS Term
  [ 9] Sum -> Term
  [10] Term -> Term STAR Unary
  [11] Term -> Term SLASH Unary
  [12] Term -> Unary
  [13] Unary -> PLUS Unary
  [14] Unary -> MINUS Unary
  [15] Unary -> TILDE Unary
  [16] Unary -> Factor
  [17] Factor -> LPAREN Expr RPAREN
  [18] Factor -> INT_CONST
  [19] Factor -> FLOAT_CONST
```

## 3. Architecture

```
 text ─► lexer ─► Token[] ─► shift-reduce parser (compiler.c) ◄── ACTION/GOTO ◄── LR(0) item sets ◄── Grammar
                               │  stack: (state, symbol, value)        (syntax_table.c)   (lr_items.c)   (grammar.c)
                               ├─► reduction history (reduction.c)
                               └─► semantic actions ─► TAC (ir.c) ─► optimizer.c ─► TAC' ─► codegen.c ─► machine code
```

| Module | Files | Role |
| --- | --- | --- |
| Lexer | `lexer.c/.h` | characters → tokens |
| Grammar | `grammar.c/.h` | grammar storage, augmentation, **the expression grammar** |
| LR items | `lr_items.c/.h` | closure, goto, canonical collection (the LR(0) DFA) |
| **SLR(1) table + conflicts** | `syntax_table.c/.h` | FIRST/FOLLOW, ACTION/GOTO, conflict detection |
| **Shift-reduce parser** | `compiler.c/.h` | stack-based parsing loop, semantic actions, derivation |
| **Reduction tracker** | `reduction.c/.h` | history of reductions |
| Intermediate code | `ir.c/.h` | TAC, operand arithmetic |
| Optimizer (supporting) | `optimizer.c/.h` | four passes with per-change reporting |
| Target code (supporting) | `codegen.c/.h` | 4-register machine code + simulator |
| Driver | `main.c` | options, 11-section output, demos |
| Tests | `test_slr.c`, `test_opt.c` | table generator (97 checks), optimizer (36 checks incl. 6000 random expressions) |

### Dependency map (from the actual `#include` lines and calls)

| File | Includes | Calls into |
| --- | --- | --- |
| `main.c` | compiler.h, optimizer.h, codegen.h | lexer, grammar, syntax_table, compiler, reduction, ir, optimizer, codegen |
| `compiler.c` | compiler.h (→ grammar, syntax_table, lexer, ir, reduction) | lexer (`token_*`), grammar (`grammar_find_symbol`), syntax_table (`slr_get_action/goto`), reduction, ir (`ir_binary` …) |
| `syntax_table.c` | syntax_table.h (→ grammar, lr_items) | grammar (`grammar_augment`), lr_items (`lr_collection_*`) |
| `lr_items.c` | lr_items.h (→ grammar) | – |
| `optimizer.c` | optimizer.h (→ ir) | ir (`ir_apply`, `ir_copy`, `ir_delete`, `ir_fmt_tac` …) |
| `codegen.c` | codegen.h (→ ir) | ir (`ir_apply`, `ir_var_*`) |
| `lexer.c`, `grammar.c`, `reduction.c`, `ir.c` | own header only | leaves |

Full tables and diagrams: `docs/Source_Code_Reference.md` §3.

## 4. Execution flow

**At program start (once):** `grammar_load_compiler` → `slr_generate` (augment, FIRST/FOLLOW, 33 LR(0) states, ACTION/GOTO, conflict detection). If any conflict exists the program prints the report and stops.

**For each expression (`run_one`):** `lexer_tokenize` → `compiler_parse` (trace + reductions + semantic actions) → result → `ir_finish` → `opt_run` → `cg_generate` → verification (`ir_eval` on original and optimized TAC, `cg_run` on the machine code).

## 5. Build and run

```sh
make                 # builds ./mini_compiler           (Windows: build.bat)
make test            # test_slr (97 checks) + test_opt (36 checks) + demo + conflict demo
./mini_compiler "3 + 5 * 2"
```

| Option | Effect |
| --- | --- |
| *(none)* | all 11 sections |
| `--no-table` | hide sections 2–5 (grammar, item sets, tables, conflicts) |
| `--quiet` | print only sections 8–11 |
| `--opt-brief` | optimizer prints only the final TAC and summary |
| `--no-opt` | skip optimization; the code generator receives the original TAC (shows register allocation and spilling) |
| `--demo` | 9 valid + 3 invalid expressions through the whole pipeline (tables printed once) |
| `--conflict-demo` | run the table generator on two non-SLR(1) grammars and print the conflict reports |
| `--table` | accepted for compatibility (tables are shown by default) |

Exit status: 0 = success, 1 = syntax error or a failed check, 2 = usage error.

## 6. Explanation of the terminal output

| # | Section | What to look for |
| --- | --- | --- |
| 1 | Input and token stream | `INTEGER(3) PLUS …` with positions; ends with `END_OF_INPUT` (`$`) |
| 2 | Grammar and production rules | numbered productions (the numbers in `rN` actions), FIRST/FOLLOW |
| 3 | LR(0) item sets | each state: kernel items, closure items, transitions |
| 4 | ACTION and GOTO tables | `sN` shift, `rN` reduce, `acc`, blank = error; `*` marks a conflicting cell |
| 5 | Conflict detection | counts (S/R, R/R) and "CONFLICT-FREE" verdict; the offending state/lookahead/actions when not |
| 6 | Shift-reduce trace | step, state, **stack**, **remaining input**, **action**, description (`GOTO[s,A]=n` for reductions) |
| 7 | Reduction history | each reduction: production, stack before ⇒ after, TAC emitted; production sequence; rightmost derivation |
| 8 | Final syntax result | ACCEPTED/REJECTED, step counts; for errors: token, state, expected tokens |
| 9 | TAC generation | which reduction emitted each instruction, then the TAC |
| 10 | Optimization | every pass of every round: before, each change with rule and reason, after |
| 11 | Target code | machine code and the `Check:` line (original TAC = optimized TAC = machine) |

Sections 1–8 are the focus; 9–11 are intentionally compact. Real sample of the heart of the output (trace for `3 + 5 * 2`):

```
Step  State  Parsing stack (state symbol state ...)         Remaining input                Action Description
-------------------------------------------------------------------------------------------------------------------------------------
1     0      0                                              3 + 5 * 2 $                    s5     SHIFT INT_CONST, push state 5
2     5      0 INT_CONST 5                                  + 5 * 2 $                      r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[0,Factor]=13
3     13     0 Factor 13                                    + 5 * 2 $                      r16    REDUCE Unary -> Factor : pop 1, GOTO[0,Unary]=12
4     12     0 Unary 12                                     + 5 * 2 $                      r12    REDUCE Term -> Unary : pop 1, GOTO[0,Term]=11
5     11     0 Term 11                                      + 5 * 2 $                      r9     REDUCE Sum -> Term : pop 1, GOTO[0,Sum]=10
6     10     0 Sum 10                                       + 5 * 2 $                      s21    SHIFT PLUS, push state 21
7     21     0 Sum 10 PLUS 21                               5 * 2 $                        s5     SHIFT INT_CONST, push state 5
8     5      0 Sum 10 PLUS 21 INT_CONST 5                   * 2 $                          r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[21,Factor]=13
9     13     0 Sum 10 PLUS 21 Factor 13                     * 2 $                          r16    REDUCE Unary -> Factor : pop 1, GOTO[21,Unary]=12
10    12     0 Sum 10 PLUS 21 Unary 12                      * 2 $                          r12    REDUCE Term -> Unary : pop 1, GOTO[21,Term]=29
11    29     0 Sum 10 PLUS 21 Term 29                       * 2 $                          s23    SHIFT STAR, push state 23
12    23     0 Sum 10 PLUS 21 Term 29 STAR 23               2 $                            s5     SHIFT INT_CONST, push state 5
13    5      0 Sum 10 PLUS 21 Term 29 STAR 23 INT_CONST 5   $                              r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[23,Factor]=13
14    13     0 Sum 10 PLUS 21 Term 29 STAR 23 Factor 13     $                              r16    REDUCE Unary -> Factor : pop 1, GOTO[23,Unary]=31
15    31     0 Sum 10 PLUS 21 Term 29 STAR 23 Unary 31      $                              r10    REDUCE Term -> Term STAR Unary : pop 3, GOTO[21,Term]=29
16    29     0 Sum 10 PLUS 21 Term 29                       $                              r7     REDUCE Sum -> Sum PLUS Term : pop 3, GOTO[0,Sum]=10
17    10     0 Sum 10                                       $                              r6     REDUCE And -> Sum : pop 1, GOTO[0,And]=9
18    9      0 And 9                                        $                              r4     REDUCE Xor -> And : pop 1, GOTO[0,Xor]=8
19    8      0 Xor 8                                        $                              r2     REDUCE Expr -> Xor : pop 1, GOTO[0,Expr]=7
20    7      0 Expr 7                                       $                              acc    ACCEPT: input is a valid sentence of the grammar
```

## 7. Optimization techniques actually implemented

| Technique | Status |
| --- | --- |
| Constant folding | implemented (`opt_fold`) |
| Constant propagation **and copy propagation** | implemented (`opt_propagate`) |
| Algebraic simplification (19 identity rules) | implemented (`opt_simplify`) |
| Dead (temporary) code elimination | implemented (`opt_dead`) |
| Code motion, strength reduction, common-subexpression elimination, peephole | **not implemented** (the language has no loops/branches/variables) |

Pass order: fold → propagate → simplify → dead, repeated until a round changes nothing (limit 10). Details and real examples: `docs/Optimization_Walkthrough.md`.

## 8. Known limitations and unsupported features

* No identifiers/variables, no `%`, shifts, comparisons, exponent notation, hex literals or comments.
* One syntax error ends the parse (no error recovery).
* Every expression folds to a single constant, so the code generator normally sees one instruction; use `--no-opt` to exercise it.
* Division by zero is not folded and is not given a defined value: the interpreter yields 0, the machine leaves a register unchanged, so the final `Check:` reports FAIL for e.g. `8 / 0`. Dead division by zero can be removed by the optimizer (`(8/0)*0` → `0`).
* Integers wrap at 32 bits; bitwise operators on float operands truncate the operand to int.
* Limits: 64 grammar symbols, 128 productions, 10 symbols per right-hand side, 2047 tokens per expression, 63-character lexemes.
* The Makefile does not track header dependencies: after changing a header run `make clean && make`.
* If the grammar's production order changes, the semantic-action `switch` in `compiler.c` (keyed on production numbers) must be updated.
* `codegen.c` uses file-level static state (not re-entrant).
