# Study Guide — Shiv

## Lexical Analyzer, Token Management \& Grammar Design

Everything below is taken from the real code. Where output is shown, it was produced by running `./mini\_compiler`; where something is only a teaching example, it is labelled **(illustrative)**.

\---

## A. Assigned files

|File|What you own|Functions / structures to know|
|-|-|-|
|`lexer.h`|The whole interface.|`TokenType` (13 terminal tokens + `TOK\_INVALID` = −1 + `TOK\_TERMINAL\_COUNT`), `Token`, `Lexer`, `MAX\_LEXEME` (64), prototypes.|
|`lexer.c`|The whole file.|`scan`, `lexer\_tokenize`, `lexer\_next`, `lexer\_peek`, `lexer\_init`, `token\_name`, `token\_symbol`, `token\_format`, helpers `cur`, `adv`, `take`, tables `NAMES\[]`, `SYMBOLS\[]`.|
|`grammar.c` (part)|`grammar\_load\_compiler` — **the grammar itself**: the terminal list and the 19 productions, and the comment block explaining precedence.|the two static tables `terminals\[]` and `rules\[]\[2]`.|
|`grammar.h` (part)|The conventions documented at the top (symbol 0 = `$`, production 0 = `S' -> S`, production numbers = REDUCE numbers).|`Symbol`, `Production`, `Grammar`.|
|`compiler.c` (small part)|The **bridge** from token types to grammar terminals.|`lexer\_symbol\_names\[]`, `compiler\_token\_terminal`, `compiler\_print\_tokens`.|

**Overlap — who is responsible for what**

* `grammar.c`: you own the **language definition** (`grammar\_load\_compiler`). Mahendra owns the **machinery** that stores and augments grammars (`grammar\_init`, `grammar\_add\_\*`, `grammar\_augment`) because the table generator depends on it. Know both at a high level.
* `compiler.c`: Arnav owns the parsing loop. You own `lexer\_symbol\_names\[]` / `compiler\_token\_terminal` (the mapping) and how tokens are displayed.
* The **semantic action numbers** in `compiler.c`'s `switch (pno)` are tied to *your* production order. If you reorder productions, Arnav's switch breaks.

\---

## B. Code walkthrough

### B.1 The data types (`lexer.h`)

```c
typedef enum { TOK\_INVALID = -1, TOK\_INTEGER = 0, TOK\_FLOAT, TOK\_PLUS, TOK\_MINUS, TOK\_MULTIPLY,
               TOK\_DIVIDE, TOK\_BIT\_AND, TOK\_BIT\_OR, TOK\_BIT\_XOR, TOK\_BIT\_NOT,
               TOK\_LEFT\_PAREN, TOK\_RIGHT\_PAREN, TOK\_END\_OF\_INPUT, TOK\_TERMINAL\_COUNT } TokenType;

typedef struct { TokenType type; long long int\_value; double float\_value;
                 char lexeme\[MAX\_LEXEME]; size\_t offset; int line; int column; } Token;
```

* **type** – the *token type* (the class). **lexeme** – the exact text (`"3.5"`). **int\_value / float\_value** – the *attribute* (the numeric value) so later phases need not re-parse text. **offset, line, column** – position, used for the token table in section 1.
* `TOK\_TERMINAL\_COUNT` is deliberately the last enumerator: its numeric value (13) equals the number of real token types, so it sizes the arrays `NAMES\[]` and `SYMBOLS\[]` and is the bounds check in `token\_name`. `TOK\_INVALID = -1` lies outside that range, which is why `token\_name` checks `t >= 0`.

### B.2 `lexer\_tokenize` — the only entry point other modules use

```c
size\_t lexer\_tokenize(const char \*src, Token \*out, size\_t cap) {
    Lexer lx; size\_t n = 0;
    lexer\_init(\&lx, src);
    while (n < cap) { out\[n] = lexer\_next(\&lx); n++; if (out\[n-1].type == TOK\_END\_OF\_INPUT) break; }
    return n;
}
```

It fills the caller's array until it has produced `TOK\_END\_OF\_INPUT` (always the **last** token, lexeme `"$"`), or until `cap` is reached. `main.c` passes `cap = 2048` and refuses input where `n == cap` (no room for `$`).

### B.3 `scan` — the scanner

1. **Skip whitespace** (`isspace`, so spaces, tabs, newlines; `adv` updates `line`/`column`).
2. Record `offset`, `line`, `column` of the first character of the token.
3. **End of string** (`cur == 0`) → `TOK\_END\_OF\_INPUT`, lexeme `"$"`.
4. **Number**: starts with a digit, *or* with `.` followed by a digit.

   * read digits (`take` copies each char into `t.lexeme`, bounded by `MAX\_LEXEME-1`);
   * if the next char is `.`, set `is\_float`, take it and the digits after it;
   * `strtod` (float) or `strtoll` (integer; `float\_value` is also set to the same number).
5. **Single-character tokens** by `switch (c)`: `+ - \* / \& | ^ \~ ( )`.
6. **Anything else** → `TOK\_INVALID` with the character as its lexeme (the scan *continues*; it is the **parser** that reports the error, with the expected tokens).

The number recognizer is this small DFA (illustrative drawing of what the code does):

```
        digit             digit               digit
 start ──────► \[INT] ◄──────┐   '.'     ┌──► \[FLOAT] ◄──┐
   │              └─────────┘ ─────────►─┘      └────────┘
   │ '.' then digit                                       
   └──────────────────────────► \[FLOAT]   (".5" is legal; "3." is legal; "1e5" is NOT: 'e' ends the number)
```

### B.4 Real output

Tokens for a mixed expression (section 1 of the program output):

```
Input: 3.5 + .5 \* -2

#    Token                    Position
1    FLOAT(3.5)               1:1
2    PLUS                     1:5
3    FLOAT(.5)                1:7
4    MULTIPLY                 1:10
5    MINUS                    1:12
6    INTEGER(2)               1:13
7    END\_OF\_INPUT             1:14
```

Note: `-2` is **two** tokens, `MINUS` then `INTEGER(2)` — the lexer never makes a negative literal.

An illegal character is *not* a lexical failure that stops the lexer; it becomes a token the parser rejects:

```
Input: 3 @ 4
Result: REJECTED - syntax error at token #2 '@' (illegal character) (parser state 5)
Expected one of: $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN
Parser actions before the error: 2 steps (1 shifts, 0 reductions)

\[9]-\[11] Skipped: no successful parse, so no intermediate code is generated.
```

and `1e5` (no exponent syntax):

```
Input: 1e5
Result: REJECTED - syntax error at token #2 'e' (illegal character) (parser state 5)
Expected one of: $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN
Parser actions before the error: 2 steps (1 shifts, 0 reductions)

\[9]-\[11] Skipped: no successful parse, so no intermediate code is generated.
```

### B.5 The bridge to the parser (`compiler.c`)

```c
static const char \*lexer\_symbol\_names\[TOK\_TERMINAL\_COUNT] = {
    "INT\_CONST","FLOAT\_CONST","PLUS","MINUS","STAR","SLASH","AMP","PIPE","CARET","TILDE","LPAREN","RPAREN","$" };
int compiler\_token\_terminal(const Grammar \*g, TokenType type) {
    if (type < 0 || type >= TOK\_TERMINAL\_COUNT) return -1;
    return grammar\_find\_symbol(g, lexer\_symbol\_names\[type]);
}
```

The lexer calls multiplication `TOK\_MULTIPLY`; the grammar calls it `STAR`. This array (indexed by the enum value) translates the lexer's names into the grammar's names, and `grammar\_find\_symbol` turns the name into the integer symbol id the ACTION table is indexed with. **If you add a token to the enum without adding an entry here, tokens shift by one and the parser silently misreads input.**

### B.6 The grammar (`grammar\_load\_compiler`)

```
Terminals   : $ PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT\_CONST FLOAT\_CONST
Non-terminals: Expr Xor And Sum Term Unary Factor Expr'
Start symbol : Expr
Productions (0 = augmented):
  \[ 0] Expr' -> Expr
  \[ 1] Expr -> Expr PIPE Xor
  \[ 2] Expr -> Xor
  \[ 3] Xor -> Xor CARET And
  \[ 4] Xor -> And
  \[ 5] And -> And AMP Sum
  \[ 6] And -> Sum
  \[ 7] Sum -> Sum PLUS Term
  \[ 8] Sum -> Sum MINUS Term
  \[ 9] Sum -> Term
  \[10] Term -> Term STAR Unary
  \[11] Term -> Term SLASH Unary
  \[12] Term -> Unary
  \[13] Unary -> PLUS Unary
  \[14] Unary -> MINUS Unary
  \[15] Unary -> TILDE Unary
  \[16] Unary -> Factor
  \[17] Factor -> LPAREN Expr RPAREN
  \[18] Factor -> INT\_CONST
  \[19] Factor -> FLOAT\_CONST
```

* **Terminals** (declared first, in this order): `PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT\_CONST FLOAT\_CONST` (plus the built-in `$`).
* **Non-terminals** are created automatically the first time a rule mentions them: `Expr, Xor, And, Sum, Term, Unary, Factor` (and `Expr'` when augmented).
* **Production numbers 1–19** are the order of the `rules\[]\[2]` array. These numbers are printed as `r7`, `r18` … in the trace, and the semantic `switch` in `compiler.c` uses them.

**How precedence and associativity are encoded.** One non-terminal per precedence level, lowest at the top:

|Level (low → high)|Non-terminal|Operators|Associativity|
|-|-|-|-|
|1|`Expr`|`\|`|left|
|2|`Xor`|`^`|left|
|3|`And`|`\&`|left|
|4|`Sum`|`+ -`|left|
|5|`Term`|`\* /`|left|
|6|`Unary`|prefix `+ - \~`|right (right recursion: `Unary → MINUS Unary`)|
|7|`Factor`|`( Expr )`, numbers|–|

A rule like `Sum → Sum PLUS Term` is **left-recursive**: the left operand can itself be a `Sum`, so `10 - 4 - 3` groups as `(10 - 4) - 3`. Real TAC from the program:

```
TAC emitted by semantic actions attached to reductions:
  reduction #8   Sum -> Sum MINUS Term      -> t1 = 10 - 4
  reduction #12  Sum -> Sum MINUS Term      -> t2 = t1 - 3

--- Generated TAC ---
  t1 = 10 - 4                    \[int]
  t2 = t1 - 3                    \[int]
```

(`t2 = t1 - 3` uses the result of `10 - 4`; the answer is 3, not 9.) Because the right operand of `Sum` is a `Term` (one level up), `3 + 5 \* 2` is `3 + (5 \* 2)`.

\---

## C. Concepts you must understand

* **Lexical analysis**: groups characters into tokens; ignores whitespace; detects characters that belong to no token. Output is a token sequence, not a tree.
* **Token / lexeme / pattern / attribute**: token type `INTEGER`; lexeme `"42"`; pattern *digit+*; attribute `int\_value = 42`.
* **Regular expressions for this lexer** (illustrative notation): `INTEGER = \[0-9]+`; `FLOAT = \[0-9]+ "." \[0-9]\* | "." \[0-9]+`; operators are single literal characters; whitespace is skipped. The code implements these directly with loops instead of generating an automaton.
* **Lexical vs syntax analysis.** Lexer: *"what are the words?"* (regular, no nesting). Parser: *"are the words arranged legally?"* (context-free, needs a stack for nesting parentheses). Evidence in this project: `3 4` is lexically fine (two INTEGER tokens) but rejected by the parser; `3 @ 4` has an illegal character the lexer cannot classify, yet it is the parser that prints the error with the expected tokens.
* **CFG terms**: terminal, non-terminal, production `A → α`, start symbol, derivation, parse tree, ambiguity, left/right recursion.
* **Precedence \& associativity** and how grammar layering enforces them (table above).
* **Why the grammar is unambiguous**: each level only refers to the next-higher level on its right-hand operand, so there is exactly one way to parse any string. This is *proved in practice* by the table generator reporting 0 conflicts.
* **Unary operators**: `Unary → PLUS Unary | MINUS Unary | TILDE Unary | Factor`; they bind tighter than `\*`: `-3 \* +4` = `(-3) \* (+4)`.
* **Augmented grammar** (`Expr' → Expr`): added by `grammar\_augment` so the parser has a single accept item.

\---

## D. Important functions and data structures

|Item|What / why|Inputs → outputs|Used by|If broken|
|-|-|-|-|-|
|`Token`|One lexical unit with type, text, numeric value, position.|filled by `scan`|`compiler.c`, `main.c`|Without `int\_value`/`float\_value` the parser would have to re-parse text; wrong values → wrong TAC constants.|
|`scan`|Recognize one token.|`Lexer\*` (source + position) → `Token`|`lexer\_next`, `lexer\_peek`|A bug here changes the token stream: `3.5` split into `3` `.` `5` gives a parse error.|
|`lexer\_tokenize`|Produce the whole array including `$`.|string, array, cap → count|`main.c`, `test\_opt.c`|Missing `$` ⇒ parser never sees end of input (reads past the array).|
|`adv`|Advance one char, maintain line/column.|`Lexer\*`|`scan`, `take`|Wrong columns only (cosmetic).|
|`take`|Append current char to lexeme, then `adv`. Bounded to 63 chars.|`Lexer\*`, `Token\*`, length|`scan`|Overflow of `lexeme\[64]` if the bound were removed (very long numbers).|
|`token\_format`|`INTEGER(3)` display text.|`Token\*` → string|`compiler\_print\_tokens`|Display only.|
|`lexer\_symbol\_names\[]` + `compiler\_token\_terminal`|Token type → grammar symbol id.|`TokenType` → int|`compiler\_parse`|Wrong mapping ⇒ parser feeds the wrong terminal to ACTION.|
|`grammar\_load\_compiler`|Defines the language.|none → fills `Grammar`|`main.c`, tests|A typo in a terminal name (`"PLUSS"`) becomes a *non-terminal* with no production; `grammar\_augment` catches this ("non-terminal has no productions").|
|`lexer\_peek`|One-token lookahead.|–|**not used** by the pipeline (kept as part of the lexer API).|–|

Example of a function in action — `scan` on `"3.5+.5"`: `3` digit → read `3`; `.` → float, read `.5`; lexeme `"3.5"`, `strtod` → 3.5 → `FLOAT(3.5)`. Next `+` → `PLUS`. Next `.5`: `.` followed by a digit enters the number branch → `FLOAT(.5)`, value 0.5. Then `cur == 0` → `END\_OF\_INPUT`.

\---

## E. Viva preparation

**Fundamental**

1. *Difference between token, lexeme and pattern?* Token = category (`FLOAT`); lexeme = actual characters (`3.5`); pattern = the rule describing valid lexemes (`\[0-9]+\\.\[0-9]\*|\\.\[0-9]+`). In code: `Token.type`, `Token.lexeme`, and the logic in `scan`.
2. *Why separate lexer and parser?* Different power and simplicity: lexing needs no stack; keeping it separate keeps the grammar free of character-level detail (whitespace, digits). Also speed and error reporting.
3. *Is a lexer a finite automaton?* Yes conceptually (regular languages). Ours is hand-coded; there is no automaton table. Be honest: **the project's DFA is in the parser (LR(0) automaton), not the lexer.**

**Implementation**

4. *Why is `-3` not a single token?* Because then `3-2` would lex as `INTEGER(3) INTEGER(-2)` → syntax error. The lexer emits `MINUS` and the grammar's `Unary → MINUS Unary` handles the sign. The token table above shows `-2` as two tokens.
5. *What does the lexer do with `@`?* Returns `TOK\_INVALID` with lexeme `@` and continues; the parser then reports "illegal character" and the terminals it could have accepted in that state.
6. *How does it know `.5` is a number but `.` alone is not?* The test `c == '.' \&\& isdigit(next)`; a bare `.` falls to the `switch` default → `TOK\_INVALID`.
7. *What if the input is `1e5`?* Scientific notation is unsupported: tokens `INTEGER(1)`, `INVALID(e)`, `INTEGER(5)`; rejected at `e` (output above).
8. *What happens for numbers longer than 63 characters?* `take` stops copying at `MAX\_LEXEME-1`, but `adv` still consumes digits; the stored lexeme is truncated while the value is converted from the truncated text — an edge case, not a crash.
9. *What happens with `99999999999`?* `strtoll` reads it, then `ir\_int` wraps it to 32 bits (`(int32\_t)v`), so the compiler works in 32-bit `int`.
10. *Why does `lexer\_tokenize` take a `cap`?* To avoid overflowing the caller's array; `main` uses 2048.
11. *Why is `TOK\_TERMINAL\_COUNT` last in the enum?* It doubles as the count; arrays are sized with it.
12. *Why do token names (`TOK\_MULTIPLY`) differ from grammar names (`STAR`)?* The lexer names things for humans reading input; the grammar names things by symbol. `lexer\_symbol\_names\[]` is the translation. A mismatch would make `grammar\_find\_symbol` return −1 (parser: lexical-error path).

**Grammar design**

13. *Show that `3 + 5 \* 2` = 13 comes from the grammar, not luck.* `Sum → Sum PLUS Term`; the `5 \* 2` is a `Term` (derived through `Term → Term STAR Unary`) so it must be reduced before `Sum PLUS Term`. See the reduction order in the trace (reduction #10 is `Term → Term STAR Unary`, #11 is `Sum → Sum PLUS Term`).
14. *Why left recursion?* To make operators left-associative: `10 - 4 - 3` must be 3. Right recursion would give `10 - (4 - 3)` = 9.
15. *Why is `Unary` right-recursive?* Prefix operators nest to the right: `\~\~5` = `\~(\~5)`.
16. *Where do `\&`, `^`, `|` sit relative to `+`?* Below it (lower precedence) as in C: `5 \& 3 | 2` = `(5 \& 3) | 2` = 3 (demo test 3).
17. *Is the grammar ambiguous? How do you know?* No. Layering gives one parse per string; confirmed by 0 conflicts from the SLR(1) generator (section 5 of the output).
18. *Why two terminals `INT\_CONST` and `FLOAT\_CONST`?* The semantic action needs to know the numeric type to emit int vs float TAC and conversions.
19. *What is the augmented production for?* Gives a unique accepting item `Expr' → Expr .`; the parser accepts when that is complete and the lookahead is `$`.
20. *How would you add `%` (modulo)?* Lexer: new `TOK\_MODULO` before `TOK\_END\_OF\_INPUT`, a case in `scan`, entries in `NAMES\[]`, `SYMBOLS\[]`, `lexer\_symbol\_names\[]`. Grammar: terminal `PERCENT`; rule `Term → Term PERCENT Unary`. Parser: a new semantic-action case (production numbers shift!). IR: new `Op`, `ir\_apply` case. Codegen: new opcode. Table is regenerated automatically.
21. *How would you add `\*\*` (power, right-associative)?* A new level between `Term` and `Unary` with a **right-recursive** rule `Power → Unary POW Power | Unary` — right recursion gives right associativity.
22. *What if two rules start with the same terminal?* Not a problem for LR (unlike LL); conflicts appear only if the table has two actions in one cell.

**Edge cases / limits**

23. Empty input: tokens = just `$`; the parser's state 0 has no action on `$` → "syntax error", expected `PLUS, MINUS, TILDE, LPAREN, INT\_CONST, FLOAT\_CONST`.
24. No identifiers, hex literals, comments, exponent, or string literals. The IR has a variable table (`ir\_var`) but the grammar never produces variables.
25. Column counting assumes one byte per character.

**Understanding vs memorizing**

26. *Trace the lexer on `(1+2)`.* `(`→LEFT\_PAREN col1; `1`→INTEGER; `+`→PLUS; `2`→INTEGER; `)`→RIGHT\_PAREN; end→`$`. 6 tokens.
27. *Change the grammar so `+` and `\*` have equal precedence. What breaks?* Put both in one level (`Sum → Sum PLUS Unary | Sum STAR Unary | Unary`). The grammar stays conflict-free (still unambiguous) but `3 + 5 \* 2` becomes `(3+5)\*2 = 16`. Production numbers change ⇒ **the semantic switch must be updated**, otherwise wrong TAC.

\---

## F. Beyond your section

|Level|Topics|
|-|-|
|**Know thoroughly**|tokens/lexemes; the grammar and its precedence encoding; what the parser needs from the lexer (`$`, token ↔ terminal mapping); how a syntax error differs from a lexical error.|
|**Understand at high level**|LR(0) items and the ACTION/GOTO idea (Mahendra); the parse stack, reductions and semantic actions (Arnav); what TAC is and that the optimizer folds constants (Sarvesh).|
|**Be familiar with (not line-by-line)**|`grammar\_add\_rule`/`grammar\_augment` (grammar.c); `compiler\_parse` (compiler.c); `main.c`'s `run\_one`.|
|**Interfaces**|You → Mahendra: `Grammar` struct + production numbering. You → Arnav: `Token\[]` ending in `$`, `lexer\_symbol\_names\[]`, production numbers.|

Run these yourself to see your module's effect: `./mini\_compiler --no-table "3.5 + .5 \* -2"`, `./mini\_compiler "3 @ 4"`, `./mini\_compiler "1e5"`.

