# Study Guide — Mahendra
## SLR(1) Syntax Table Generation & Conflict Detection

All tables and reports below are real program output (`./mini_compiler`, `./mini_compiler --conflict-demo`). Items marked **(illustrative)** are teaching examples.

---

## A. Assigned files

| File | Responsibility | Know these |
| --- | --- | --- |
| `syntax_table.h` / `syntax_table.c` | **Entire file pair.** FIRST/FOLLOW, ACTION/GOTO construction, conflict detection, table queries and printers. | `SymSet`, `FirstFollow`, `Action`, `Conflict`, `SLRTable`; `first_follow_compute`, `slr_init`, `slr_build_states`, `slr_build_tables`, `slr_generate`, `set_action`, `add_conflict`, `slr_get_action`, `slr_get_goto`, `slr_is_slr1`, printers. |
| `lr_items.h` / `lr_items.c` | **Entire file pair.** LR(0) items, closure, goto, canonical collection. | `LRItem`, `ItemSet`, `LRState`, `LRCollection`; `itemset_closure`, `itemset_goto`, `lr_collection_build`, `lr_collection_find`. |
| `grammar.h` / `grammar.c` (machinery) | The storage format your code reads, and augmentation. | `Grammar`, `Production`, `grammar_augment`, `grammar_find_symbol`. (Aditya owns `grammar_load_compiler`, the language content.) |
| `test_slr.c` | Your test suite (97 checks). | `test_closure_goto_dedup`, `test_first_follow(_epsilon)`, `test_tables`, `test_determinism`, `test_parses`, `test_conflict_grammars`. |
| `main.c` (part) | `frontend_build`, `print_table_report`, `conflict_demo`, and the "refuse a conflicting grammar" check in `main`. | – |

**Overlap.** The *parser* only **queries** your table (`slr_get_action`, `slr_get_goto`). You do not need to explain the parsing loop line by line, but you must explain what each ACTION/GOTO entry means to it. Production **numbers** are shared: your `REDUCE n` carries the number Aditya's grammar assigned; Arnav's semantic actions are keyed on it.

---

## B. Code walkthrough

### B.1 What gets built, and when

`main.c → frontend_build()` runs **once per program run**, before any expression is looked at:

```
grammar_load_compiler(&g)   // Aditya: fills Grammar (19 productions)
slr_generate(&t, &g) =
    slr_init(&t,&g)         // grammar_augment (adds Expr'), first_follow_compute
    slr_build_states(&t)    // lr_collection_build  → 33 LR(0) states
    slr_build_tables(&t)    // ACTION/GOTO fill + conflict detection
```
Parsing an expression later only *reads* `t.action[]` and `t.go[]`.

### B.2 Grammar representation (what your code reads)

`Grammar.symbols[]` (name, is_terminal) with **one id space**: terminals and non-terminals share ids; symbol 0 is `$`. `Grammar.prods[p] = {lhs, rhs_len, rhs[]}`; production 0 is `Expr' → Expr` (filled by `grammar_augment`). Real grammar:

```
Terminals   : $ PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT_CONST FLOAT_CONST
Non-terminals: Expr Xor And Sum Term Unary Factor Expr'
Start symbol : Expr
Productions (0 = augmented):
  [ 0] Expr' -> Expr
  [ 1] Expr -> Expr PIPE Xor
  [ 2] Expr -> Xor
  [ 3] Xor -> Xor CARET And
  [ 4] Xor -> And
  [ 5] And -> And AMP Sum
  [ 6] And -> Sum
  [ 7] Sum -> Sum PLUS Term
  [ 8] Sum -> Sum MINUS Term
  [ 9] Sum -> Term
  [10] Term -> Term STAR Unary
  [11] Term -> Term SLASH Unary
  [12] Term -> Unary
  [13] Unary -> PLUS Unary
  [14] Unary -> MINUS Unary
  [15] Unary -> TILDE Unary
  [16] Unary -> Factor
  [17] Factor -> LPAREN Expr RPAREN
  [18] Factor -> INT_CONST
  [19] Factor -> FLOAT_CONST
```

### B.3 FIRST / FOLLOW (`first_follow_compute`)

Three arrays in `FirstFollow`: `first[sym]`, `follow[sym]` (each a 64-bit mask, bit *i* = symbol *i*), `nullable[sym]`.

1. `first[terminal] = {terminal}`.
2. Repeat until nothing changes (`changed` flag): for each production `A → X1 X2 …`: add `first[X1]` to `first[A]`; if `X1` is nullable also `first[X2]`, and so on; `A` is nullable if all are. (This grammar has no ε-productions, so nothing is nullable; `test_first_follow_epsilon` tests the ε case on another grammar.)
3. `follow[Expr'] = {$}` (root). Repeat until stable: for each `A → α B β` with B a non-terminal, add `first[β]` (the symbols after B, skipping nullable ones) to `follow[B]`; if everything after B is nullable (or B is last), add `follow[A]`.

Why bit masks: union is `|`, "changed?" is `new != old`, membership is a shift-and-test. That is also why `MAX_SYMBOLS` ≤ 64 (checked at compile time by `typedef char syntax_table_needs_max_symbols_le_64[(MAX_SYMBOLS <= 64) ? 1 : -1];` — a negative array size is a compile error).

Real result:
```
FIRST sets:
  FIRST(Expr) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Xor) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(And) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Sum) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Term) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Unary) = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Factor) = { LPAREN, INT_CONST, FLOAT_CONST }
  FIRST(Expr') = { PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST }
FOLLOW sets:
  FOLLOW(Expr) = { $, PIPE, RPAREN }
  FOLLOW(Xor) = { $, PIPE, CARET, RPAREN }
  FOLLOW(And) = { $, AMP, PIPE, CARET, RPAREN }
  FOLLOW(Sum) = { $, PLUS, MINUS, AMP, PIPE, CARET, RPAREN }
  FOLLOW(Term) = { $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN }
  FOLLOW(Unary) = { $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN }
  FOLLOW(Factor) = { $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN }
  FOLLOW(Expr') = { $ }
```
Hand-check one: `FOLLOW(Term)` contains `STAR` and `SLASH` because of `Term → Term STAR Unary`; it contains everything in `FOLLOW(Sum)` because of `Sum → Term` (Term is last).

### B.4 LR(0) items, closure, goto (`lr_items.c`)

* **Item** `A → α . β` is stored as `{prod, dot}`. `dot = 0` nothing recognized yet; `dot = rhs_len` complete (ready to reduce). `item_next_symbol` = symbol after the dot (−1 if complete).
* **Kernel** items: `dot > 0` or the start item. **Closure** items: added by closure, `dot = 0`.
* `itemset_add` keeps the array sorted by (prod, dot) and rejects duplicates → two sets are equal iff element-wise equal (`itemset_equal`).

`itemset_closure(g, &s)`:
```c
do { changed = 0;
     for each item i in s:  X = item_next_symbol(i)
        if X is a non-terminal:  for each production p with lhs == X:  if itemset_add(s, {p,0}) changed = 1;
} while (changed);
```
`itemset_goto(g, &s, X)`: for each item whose next symbol is X, add the item with the dot moved over X; then closure. (Empty result ⇒ no transition.)

**Example (real).** State 0 = closure of `Expr' → . Expr`:
```
State 0:
  Kernel:
    Expr' -> . Expr
  Closure:
    Expr -> . Expr PIPE Xor
    Expr -> . Xor
    Xor -> . Xor CARET And
    Xor -> . And
    And -> . And AMP Sum
    And -> . Sum
    Sum -> . Sum PLUS Term
    Sum -> . Sum MINUS Term
    Sum -> . Term
    Term -> . Term STAR Unary
    Term -> . Term SLASH Unary
    Term -> . Unary
    Unary -> . PLUS Unary
    Unary -> . MINUS Unary
    Unary -> . TILDE Unary
    Unary -> . Factor
    Factor -> . LPAREN Expr RPAREN
    Factor -> . INT_CONST
    Factor -> . FLOAT_CONST
  Transitions:
    on PLUS         -> State 1
    on MINUS        -> State 2
    on TILDE        -> State 3
    on LPAREN       -> State 4
    on INT_CONST    -> State 5
    on FLOAT_CONST  -> State 6
    on Expr         -> State 7
    on Xor          -> State 8
    on And          -> State 9
    on Sum          -> State 10
    on Term         -> State 11
    on Unary        -> State 12
    on Factor       -> State 13
```
The closure pulled in the productions of `Expr` (because the dot is before `Expr`), then of `Xor`, `And`, … down to `Factor`. Transition on `INT_CONST` leads to state 5 — **kernel only** `Factor → INT_CONST .` (a complete item, so state 5 is a *reduce* state):
```
State 5:
  Kernel:
    Factor -> INT_CONST .
```

`lr_collection_build` — the **canonical collection**:
```
state 0 = closure({Expr' -> . Expr})
for s = 0, 1, 2, ... (num_states grows while looping: the loop *is* the work queue):
    for each symbol X from 1 .. num_symbols-1:          // '$' (0) is never shifted
        nxt = itemset_goto(states[s].set, X)
        if nxt empty: skip
        t = lr_collection_find(nxt)                      // identical set already a state?
        if t < 0: t = add_state(nxt)  else: free nxt     // dedup
        states[s].next[X] = t
```
Result: **33 states**. Numbering is deterministic (symbols in id order). The LR(0) automaton is a **DFA** whose alphabet is the grammar symbols and whose states are item sets.

### B.5 ACTION/GOTO construction (`slr_build_tables`)

For each state *s* (`set_action` is called for every write):

| Item in the set | Entry written |
| --- | --- |
| `A → α . a β` (a terminal) | `ACTION[s][a] = SHIFT next[a]` |
| `Expr' → Expr .` | `ACTION[s][$] = ACCEPT` |
| `A → α .` (A ≠ `Expr'`) | `ACTION[s][t] = REDUCE (this production)` for **every `t ∈ FOLLOW(A)`** |
| non-terminal transition `s --B--> j` | `GOTO[s][B] = j` |

Shifts/accept are written in **pass 1**, reductions in **pass 2**, so when a shift and a reduce collide, the shift is already in the cell ("existing") and the reduce is the "conflicting" action.

Real tables (blank = error):
```
ACTION table  (sN = shift to state N, rN = reduce by production N, acc = accept,
               blank = error, * = conflicting cell)
State        $   PLUS  MINUS   STAR  SLASH    AMP   PIPE  CARET  TILDE  LPAREN  RPAREN  INT_CONST  FLOAT_CONST
0                  s1     s2                                        s3      s4                 s5           s6
1                  s1     s2                                        s3      s4                 s5           s6
2                  s1     s2                                        s3      s4                 s5           s6
3                  s1     s2                                        s3      s4                 s5           s6
4                  s1     s2                                        s3      s4                 s5           s6
5          r18    r18    r18    r18    r18    r18    r18    r18                    r18                        
6          r19    r19    r19    r19    r19    r19    r19    r19                    r19                        
7          acc                                       s18                                                      
8           r2                                        r2    s19                     r2                        
9           r4                                s20     r4     r4                     r4                        
10          r6    s21    s22                   r6     r6     r6                     r6                        
11          r9     r9     r9    s23    s24     r9     r9     r9                     r9                        
12         r12    r12    r12    r12    r12    r12    r12    r12                    r12                        
13         r16    r16    r16    r16    r16    r16    r16    r16                    r16                        
14         r13    r13    r13    r13    r13    r13    r13    r13                    r13                        
15         r14    r14    r14    r14    r14    r14    r14    r14                    r14                        
16         r15    r15    r15    r15    r15    r15    r15    r15                    r15                        
17                                                   s18                           s25                        
18                 s1     s2                                        s3      s4                 s5           s6
19                 s1     s2                                        s3      s4                 s5           s6
20                 s1     s2                                        s3      s4                 s5           s6
21                 s1     s2                                        s3      s4                 s5           s6
22                 s1     s2                                        s3      s4                 s5           s6
23                 s1     s2                                        s3      s4                 s5           s6
24                 s1     s2                                        s3      s4                 s5           s6
25         r17    r17    r17    r17    r17    r17    r17    r17                    r17                        
26          r1                                        r1    s19                     r1                        
27          r3                                s20     r3     r3                     r3                        
28          r5    s21    s22                   r5     r5     r5                     r5                        
29          r7     r7     r7    s23    s24     r7     r7     r7                     r7                        
30          r8     r8     r8    s23    s24     r8     r8     r8                     r8                        
31         r10    r10    r10    r10    r10    r10    r10    r10                    r10                        
32         r11    r11    r11    r11    r11    r11    r11    r11                    r11                        

```
```
GOTO table  (blank = no transition)
State     Expr    Xor    And    Sum   Term  Unary  Factor
0            7      8      9     10     11     12      13
1                                              14      13
2                                              15      13
3                                              16      13
4           17      8      9     10     11     12      13
5                                                        
6                                                        
7                                                        
8                                                        
9                                                        
10                                                       
11                                                       
12                                                       
13                                                       
14                                                       
15                                                       
16                                                       
17                                                       
18                 26      9     10     11     12      13
19                        27     10     11     12      13
20                               28     11     12      13
21                                      29     12      13
22                                      30     12      13
23                                             31      13
24                                             32      13
25                                                       
26                                                       
27                                                       
28                                                       
29                                                       
30                                                       
31                                                       
32                                                       
```
Reading the table: state 29 = `Sum → Sum PLUS Term .` + `Term → Term . STAR Unary` + `Term → Term . SLASH Unary`:
```
State 29:
  Kernel:
    Sum -> Sum PLUS Term .
    Term -> Term . STAR Unary
    Term -> Term . SLASH Unary
  Transitions:
    on STAR         -> State 23
    on SLASH        -> State 24
```
Row 29 of ACTION: `s23` on `STAR`, `s24` on `SLASH`, `r7` on `$ PLUS MINUS AMP PIPE CARET RPAREN`. That one row *is* operator precedence: with `*` next the parser shifts (finish the `Term` first); with `+` or `)` next it reduces the sum. The reduce columns are exactly `FOLLOW(Sum)`.

### B.6 Conflict detection (`set_action`, `add_conflict`)

```c
static void set_action(SLRTable *t, int state, int term, Action a) {
    Action *cell = &t->action[state*num_symbols + term];
    if (cell->type == ACTION_ERROR)                    *cell = a;           // empty: store
    else if (cell->type == a.type && cell->value == a.value) { }            // same action again: fine
    else { add_conflict(t, state, term, *cell, a);                          // different: KEEP the first, record the clash
           if (a is REDUCE && cell is not REDUCE && first_reduce[idx] >= 0 && first_reduce[idx] != a.value)
               add_conflict(... prev reduce, a);                            // shift-cell that already rejected r1 now sees r2
    }
    if (a.type == ACTION_REDUCE && first_reduce[idx] < 0) first_reduce[idx] = a.value;
}
```
`add_conflict` classifies: shift vs reduce ⇒ `CONFLICT_SHIFT_REDUCE`; reduce vs reduce ⇒ `CONFLICT_REDUCE_REDUCE`; anything else (e.g. accept vs reduce) ⇒ `CONFLICT_OTHER`. Nothing is overwritten, so the table stays deterministic; `slr_is_slr1` = tables built **and** zero conflicts.

**Detection is part of table construction** — there is no separate analysis pass; each cell write is checked as it happens.

For the compiler grammar:
```
No conflicts: the grammar is SLR(1).

Shift/reduce conflicts: 0 | Reduce/reduce conflicts: 0 | Other: 0
Parsing table is CONFLICT-FREE (the grammar is SLR(1)).
```
`main` refuses to parse if the grammar had conflicts. To show a conflict report, `--conflict-demo` runs the same generator on two other grammars (real output):
```

--- Ambiguous grammar:  E -> E PLUS E | ID ---
Terminals   : $ PLUS ID
Non-terminals: E E'
Start symbol : E
Productions (0 = augmented):
  [ 0] E' -> E
  [ 1] E -> E PLUS E
  [ 2] E -> ID

ACTION table  (sN = shift to state N, rN = reduce by production N, acc = accept,
               blank = error, * = conflicting cell)
State        $   PLUS     ID
0                         s1
1           r2     r2       
2          acc     s3       
3                         s1
4           r1    s3*       

1 conflict(s) detected: the grammar is NOT SLR(1).

Conflict detected:
  Type:               Shift/Reduce
  State:              4
  Lookahead:          PLUS
  Existing action:    SHIFT 3   (transition: state 4 --PLUS--> state 3)
  Conflicting action: REDUCE 1   (E -> E PLUS E)

--- Reduce/reduce grammar:  S -> A | B ; A -> ID ; B -> ID ---
Terminals   : $ ID
Non-terminals: S A B S'
Start symbol : S
Productions (0 = augmented):
  [ 0] S' -> S
  [ 1] S -> A
  [ 2] S -> B
  [ 3] A -> ID
  [ 4] B -> ID

ACTION table  (sN = shift to state N, rN = reduce by production N, acc = accept,
               blank = error, * = conflicting cell)
State        $     ID
0                  s1
1          r3*       
2          acc       
3           r1       
4           r2       

1 conflict(s) detected: the grammar is NOT SLR(1).

Conflict detected:
  Type:               Reduce/Reduce
  State:              1
  Lookahead:          $
  Existing action:    REDUCE 3   (A -> ID)
  Conflicting action: REDUCE 4   (B -> ID)

CONFLICT DEMO: conflicts reported for both grammars
```
Interpretation of the first: in state 4 (items `E → E PLUS E .` and `E → E . PLUS E`) with lookahead `PLUS`, the table already has `SHIFT 3`; the reduce `E → E PLUS E` also wants that cell because `PLUS ∈ FOLLOW(E)`. The grammar is ambiguous (is `a+b+c` `(a+b)+c` or `a+(b+c)`?). The second is a reduce/reduce conflict: after `ID`, `A → ID .` and `B → ID .` both reduce on `$`. `test_slr.c` also checks a grammar that is LR(1) but **not** SLR(1) (`S → L EQ R | R ; L → STAR R | ID ; R → L`): a S/R conflict on `EQ` in state 4, showing that SLR's FOLLOW-based lookahead is coarser than LR(1)'s.

---

## C. Concepts you must understand

* **Context-free grammar**, derivation, **handle** (the right-hand side to reduce next), **viable prefix**.
* **LR(0) item** and the **dot**: how much of a production has been seen. **Kernel vs closure items.**
* **CLOSURE**: "if I expect B next, I may be at the start of any B-rule." **GOTO(I, X)**: the state after seeing X. **Canonical collection** = all reachable item sets = the states of the DFA.
* **FIRST / FOLLOW** and **nullable**.
* **SLR(1)**: LR(0) automaton + FOLLOW sets as reduce lookahead (one token of lookahead). Compare: LR(0) (reduce regardless of lookahead), LALR(1)/LR(1) (more precise lookaheads, bigger or different tables).
* **ACTION** (terminals → shift/reduce/accept/error) and **GOTO** (non-terminals → state).
* **Shift/reduce and reduce/reduce conflicts**; ambiguity as a typical cause; why precedence layering (Aditya's grammar) removes S/R conflicts.
* **Parser generator** idea: the grammar is *data*; the table is *computed*; the driver is generic.

---

## D. Important functions and data structures

| Item | What / why | In → out | Used by | If removed or wrong |
| --- | --- | --- | --- | --- |
| `LRItem {prod,dot}` | Compact item: a production number and a dot position. | – | `lr_items.c`, `syntax_table.c` | Wrong dot ⇒ wrong shifts/reduces. |
| `ItemSet` (sorted array) | A state's items. Sorted ⇒ cheap equality. | – | closure/goto/find | Unsorted ⇒ duplicates not recognised, **state explosion / non-termination**. |
| `LRState.next[X]` | Transition on X (−1 none). | – | table builder | Missing transition ⇒ missing shifts/GOTO. |
| `itemset_closure` | Add predicted items. | set (in place) | goto, build | Missing closure ⇒ states lack items; parser fails on valid input. |
| `itemset_goto` | Advance dot over X, close. | set, X → new set | `lr_collection_build` | – |
| `lr_collection_find` | Dedup identical sets. | set → state or −1 | build | Without it every goto creates a new state → infinite loop on recursive grammars. |
| `FirstFollow` | FIRST/FOLLOW/nullable sets. | grammar → sets | reduce placement | Wrong FOLLOW ⇒ missing reduces (valid input rejected) or spurious conflicts. |
| `SLRTable.action[]`, `.go[]` | The parsing table (flat arrays `[state*num_symbols + symbol]`). | – | `slr_get_action/goto` | – |
| `set_action` / `add_conflict` | Single write point; conflict recorder. | cell, action | `slr_build_tables` | Overwriting silently would hide conflicts and make the parser depend on rule order. |
| `slr_get_action`, `slr_get_goto` | **The interface to the parser**; range-checked (blank/invalid ⇒ ERROR / −1). | state, symbol | `compiler.c` | – |
| `slr_is_slr1` | Gate for parsing. | table → 0/1 | `main.c` | – |

Small example of `slr_get_action` use (illustrative of what `compiler_parse` does): `slr_get_action(&t, 5, grammar_find_symbol(&g,"PLUS"))` → `{ACTION_REDUCE, 18}` (state 5 reduces `Factor → INT_CONST` on `+`).

---

## E. Viva preparation

**Fundamentals**

1. *What is an LR(0) item?* A production with a dot marking how much of the right side has been matched. `Sum → Sum . PLUS Term` means we have seen a `Sum` and expect `PLUS`.
2. *Define CLOSURE and GOTO.* (see B.4). Closure adds `B → . γ` for every B after a dot; GOTO moves the dot over X and closes.
3. *Why augment the grammar?* To give exactly one accepting item `Expr' → Expr .`; accept happens when that item is complete on `$`.
4. *SLR(1) vs LR(0)?* LR(0) reduces whenever an item is complete, regardless of lookahead; SLR(1) reduces only on `FOLLOW(A)`. That alone removes most S/R conflicts for this grammar.
5. *When is a grammar SLR(1)?* When the SLR table has no cell with two different actions.

**Implementation**

6. *Where is conflict detection in the code?* In `set_action`, called for every table write during `slr_build_tables`. It is not a separate pass.
7. *Why do you keep the first action instead of overwriting?* Determinism and honesty: the table is a pure function of the grammar, and the clash is recorded rather than silently resolved by "last rule wins".
8. *Why are shifts written before reductions?* So "existing" is normally the shift and "conflicting" the reduce, giving consistent conflict reports (and shift-preference behaviour if someone chose to ignore conflicts — we do not; `main` refuses).
9. *Why does `lr_collection_build` start X at 1?* Symbol 0 is `$`, never shifted; accept is placed on `$` separately.
10. *Why keep item sets sorted?* `itemset_equal` becomes a linear element-wise comparison and `itemset_add` detects duplicates while inserting.
11. *How many states? Where?* 33. Section 3 prints each; `slr_num_states` returns it.
12. *Why 64-bit masks for FIRST/FOLLOW?* Fast set union/compare; limits the grammar to 64 symbols; enforced by a compile-time check.
13. *Is the table built at runtime?* Yes, every run (`slr_generate`), not hardcoded. `test_slr` verifies it.
14. *What does `*` in the printed ACTION table mean?* A cell where a conflict was recorded (see `--conflict-demo`).
15. *What does the parser do on a blank cell?* Reports a syntax error and lists the terminals with non-blank cells in that state ("Expected one of…").
16. *Show how row 29 encodes precedence.* (B.5.)

**Design alternatives**

17. *What if reductions were placed on all terminals (LR(0) style)?* In state 29, `r7` would also be written on `STAR`, colliding with `s23` ⇒ a S/R conflict; `3 + 5 * 2` could not be parsed correctly.
18. *Could you use LALR(1)?* Yes in principle (parser generators like yacc do); it needs lookahead propagation. Not needed because this grammar is SLR(1).
19. *How would you resolve S/R conflicts with precedence declarations instead of grammar layering?* Add precedence/associativity per terminal and decide shift vs reduce in `set_action`; our design deliberately encodes precedence in the grammar so no declarations are needed.
20. *What data structure would you use for a much larger grammar?* Hash-based state lookup instead of linear `lr_collection_find`; sparse tables instead of the dense `states × symbols` array.

**Edge cases / limits**

21. Max 64 symbols, 128 productions, 10 symbols per rhs. Dense tables (33 × 13 here).
22. ε-productions are supported by FIRST/FOLLOW (tested in `test_first_follow_epsilon`); the compiler grammar has none.
23. `slr_generate` returns 0 even when conflicts exist — callers **must** check `slr_is_slr1`.

**Interaction**

24. *How does your module talk to the parser?* Only through `slr_get_action`, `slr_get_goto`, `slr_prod_lhs`, `slr_prod_length`. The parser never touches your arrays.
25. *What happens if the grammar order changes?* Production numbers change; REDUCE numbers in the table change automatically; Arnav's semantic switch must be updated.
26. *If `slr_build_tables` had a bug that dropped a shift?* Valid inputs would be rejected at that state with a "Expected one of" list missing that terminal — the trace pinpoints the state.

**Understanding vs memorizing**

27. *Explain why `(1+2)*3` parses without conflict.* After `)`, state 25 reduces `Factor → ( Expr )` on `* + ) …` (all in FOLLOW(Factor)); the later `*` is shifted in state 11 (`Term → Term . STAR Unary`) — each cell has exactly one action.
28. *Construct a tiny ambiguous grammar and predict the conflict.* `E → E PLUS E | ID`: S/R on `PLUS` in the state after `E PLUS E`. Run `--conflict-demo` to confirm.

---

## F. Beyond your section

| Level | Topics |
| --- | --- |
| **Know thoroughly** | everything above; what each action means to the driver; how precedence appears in the table. |
| **Understand at high level** | tokens/lexer (Aditya); the parse-stack mechanics and reduction history (Arnav); TAC/optimizer/codegen purpose (Sarvesh). |
| **Be familiar with** | `compiler_parse` main loop (to explain how it consumes your table); `main.c` section 2–5 printing. |
| **Interfaces** | Aditya → you: `Grammar` and production order. You → Arnav: `slr_get_action/goto`, REDUCE numbers. You → `main`: conflict count and `slr_is_slr1`. |

Commands: `./test_slr -v` (everything), `./mini_compiler --conflict-demo`, `./mini_compiler --quiet "3 + 5 * 2"` (to see the table used).
