# Study Guide — Arnav
## Shift-Reduce Parser, Reduction Tracking & Semantic Processing

All traces below are real output of `./mini_compiler` for the expression `3 + 5 * 2` (unless stated). **(illustrative)** marks teaching examples.

---

## A. Assigned files

| File | Responsibility | Know these |
| --- | --- | --- |
| `compiler.c` | **The parsing loop and the semantic actions.** | `compiler_parse`, `ParseEntry`, `ParseStack`, `PARSER_STACK_MAX`, `format_stack`, `format_input`, `format_production`, `expected_terminals`, `compiler_print_derivation`, the `switch (pno)` of semantic actions. |
| `compiler.h` | The parser's public interface. | `ParseSummary`, `compiler_parse` prototype. |
| `reduction.h` / `reduction.c` | **Entire pair.** Reduction history. | `ReductionRecord`, `ReductionHistory`, `reduction_init/_add/_set_emitted/_print/_print_emitters/_free`. |
| `main.c` (part) | Sections 6–8 and the call to `compiler_parse` in `run_one`; error branch. | – |

**Overlap.**
* *With Mahendra:* you **consume** his table through `slr_get_action` / `slr_get_goto` and the numbers `a.value` (shift state or production). You must understand what an entry means; he must explain how it was built.
* *With Sarvesh:* the semantic action `switch` is yours (**when** an action runs, **which values** it receives, **what** is pushed back); the functions it calls (`ir_binary`, `ir_unary`, `ir_promote`, `ir_int`, `ir_float`) are his (**what TAC they build**, int/float conversion).
* *With Aditya:* production numbers in your `switch` come from his grammar order; the `Token[]` array comes from his lexer.

---

## B. Code walkthrough

### B.1 Data structures

```c
typedef struct { int state; int symbol; Operand value; } ParseEntry;   // one stack cell
typedef struct { ParseEntry entries[PARSER_STACK_MAX]; int n; } ParseStack;   // 4096 cells
```
* **state** — the LR automaton state after this symbol. *Parsing decisions use only the state on top of the stack.*
* **symbol** — the grammar symbol that was pushed (−1 for the bottom cell). In a pure LR parser the state already determines the symbol; we store it for the **display** (`0 Sum 10 PLUS 21 …`) and for the derivation.
* **value** — the **semantic value**: an `Operand` (a constant, or a temporary like `t1`). This is how semantic processing rides on the parse stack.

```c
typedef struct { int accepted, steps, shifts, reduces, err_pos, err_state;
                 char err_token[64], expected[256]; Operand result; } ParseSummary;
```
Filled by the parser (never by `main`): outcome, counts, and for errors the position, state, offending token and the expected terminals.

### B.2 `compiler_parse` — the algorithm

```
stack = [ {state 0} ]
loop:
    token  = tokens[pos];   term = compiler_token_terminal(g, token.type)   // lexer type -> grammar symbol id
    state  = top(stack).state
    a      = slr_get_action(table, state, term)                              // ALL decisions come from the table
    SHIFT s     : push {s, term, value-of-token};  pos++
    REDUCE p    : len = rhs_len(p); A = lhs(p)
                  vals = values of the top `len` cells
                  gs = slr_get_goto(table, state_below_those_cells, A)
                  out = semantic_action(p, vals)          // may emit TAC
                  pop len cells; push {gs, A, out}
                  record the reduction (history)
    ACCEPT      : result = top(stack).value; stop (accepted)
    ERROR       : record token/state/expected; stop (rejected)
```
Real trace (columns: step, state on top, stack, remaining input, action, description):
```
Step  State  Parsing stack (state symbol state ...)         Remaining input                Action Description
-------------------------------------------------------------------------------------------------------------------------------------
1     0      0                                              3 + 5 * 2 $                    s5     SHIFT INT_CONST, push state 5
2     5      0 INT_CONST 5                                  + 5 * 2 $                      r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[0,Factor]=13
3     13     0 Factor 13                                    + 5 * 2 $                      r16    REDUCE Unary -> Factor : pop 1, GOTO[0,Unary]=12
4     12     0 Unary 12                                     + 5 * 2 $                      r12    REDUCE Term -> Unary : pop 1, GOTO[0,Term]=11
5     11     0 Term 11                                      + 5 * 2 $                      r9     REDUCE Sum -> Term : pop 1, GOTO[0,Sum]=10
6     10     0 Sum 10                                       + 5 * 2 $                      s21    SHIFT PLUS, push state 21
7     21     0 Sum 10 PLUS 21                               5 * 2 $                        s5     SHIFT INT_CONST, push state 5
8     5      0 Sum 10 PLUS 21 INT_CONST 5                   * 2 $                          r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[21,Factor]=13
9     13     0 Sum 10 PLUS 21 Factor 13                     * 2 $                          r16    REDUCE Unary -> Factor : pop 1, GOTO[21,Unary]=12
10    12     0 Sum 10 PLUS 21 Unary 12                      * 2 $                          r12    REDUCE Term -> Unary : pop 1, GOTO[21,Term]=29
11    29     0 Sum 10 PLUS 21 Term 29                       * 2 $                          s23    SHIFT STAR, push state 23
12    23     0 Sum 10 PLUS 21 Term 29 STAR 23               2 $                            s5     SHIFT INT_CONST, push state 5
13    5      0 Sum 10 PLUS 21 Term 29 STAR 23 INT_CONST 5   $                              r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[23,Factor]=13
14    13     0 Sum 10 PLUS 21 Term 29 STAR 23 Factor 13     $                              r16    REDUCE Unary -> Factor : pop 1, GOTO[23,Unary]=31
15    31     0 Sum 10 PLUS 21 Term 29 STAR 23 Unary 31      $                              r10    REDUCE Term -> Term STAR Unary : pop 3, GOTO[21,Term]=29
16    29     0 Sum 10 PLUS 21 Term 29                       $                              r7     REDUCE Sum -> Sum PLUS Term : pop 3, GOTO[0,Sum]=10
17    10     0 Sum 10                                       $                              r6     REDUCE And -> Sum : pop 1, GOTO[0,And]=9
18    9      0 And 9                                        $                              r4     REDUCE Xor -> And : pop 1, GOTO[0,Xor]=8
19    8      0 Xor 8                                        $                              r2     REDUCE Expr -> Xor : pop 1, GOTO[0,Expr]=7
20    7      0 Expr 7                                       $                              acc    ACCEPT: input is a valid sentence of the grammar
```

**Reading it.**
* Step 1: state 0, lookahead `3` (INT_CONST). `ACTION[0,INT_CONST] = s5` → shift: push state 5. The stack shows `0 INT_CONST 5`.
* Step 2: state 5 on lookahead `+`: `ACTION[5,PLUS] = r18` → reduce `Factor → INT_CONST`. Pop 1 cell (exposing state 0), look up `GOTO[0,Factor] = 13`, push `Factor 13`. Steps 3–5 do the same chain `Factor → Unary → Term → Sum` (the chain productions exist only to encode precedence).
* Step 6: state 10, lookahead `+`: `s21` — shift.
* Step 10→11: `Term 29` with lookahead `*`: `ACTION[29,STAR] = s23` — **shift instead of reducing `Sum → Sum PLUS Term`**: this is where `*` binds tighter than `+`. Had the lookahead been `$` (as at step 16), the same state reduces (`r7`).
* Step 15: `r10` pops **3** cells (`Term STAR Unary`): `GOTO[21,Term] = 29` (note: GOTO uses the state *under* the popped cells, state 21, not the state on top before popping).
* Step 20: state 7, lookahead `$`: `ACTION[7,$] = acc`.

Counts: 20 steps = 5 shifts + 14 reductions + 1 accept (`$` is never shifted: accept fires when it is the lookahead in state 7).

### B.3 Reduction tracking

After each reduce the parser calls
```c
reduction_add(hist, pno, prodtext, sb /*stack before*/, after /*stack after*/, ib /*remaining input*/, ab /*"r10"*/);
if (ir->n > before) reduction_set_emitted(hist, <text of the TAC just emitted>);
```
`ReductionHistory` is a growable array of `ReductionRecord`s (capacity doubles from 16); every string is a private `malloc` copy, so records stay valid after the parser's buffers change. **A record is created only when the parser really reduces, so the history cannot differ from what the parser did.** Real excerpt (reductions that emitted TAC):
```
#10 [r10] Term -> Term STAR Unary
     stack : 0 Sum 10 PLUS 21 Term 29 STAR 23 Unary 31   =>   0 Sum 10 PLUS 21 Term 29
     input : $ 
     emits : t1 = 5 * 2
#11 [r7] Sum -> Sum PLUS Term
     stack : 0 Sum 10 PLUS 21 Term 29   =>   0 Sum 10
     input : $ 
     emits : t2 = 3 + t1
```
and the first reductions (no TAC: pure chain productions):
```
#1  [r18] Factor -> INT_CONST
     stack : 0 INT_CONST 5   =>   0 Factor 13
     input : + 5 * 2 $ 
#2  [r16] Unary -> Factor
     stack : 0 Factor 13   =>   0 Unary 12
     input : + 5 * 2 $ 
#3  [r12] Term -> Unary
     stack : 0 Unary 12   =>   0 Term 11
     input : + 5 * 2 $
```
Complete sequence (production numbers) and the **rightmost derivation rebuilt from it**:
```
Reduction sequence (production numbers): 18 16 12 9 18 16 12 18 16 10 7 6 4 2

Rightmost derivation (the reductions above, read from last to first):
  Expr
  => Xor
  => And
  => Sum
  => Sum PLUS Term
  => Sum PLUS Term STAR Unary
  => Sum PLUS Term STAR Factor
  => Sum PLUS Term STAR INT_CONST
  => Sum PLUS Unary STAR INT_CONST
  => Sum PLUS Factor STAR INT_CONST
  => Sum PLUS INT_CONST STAR INT_CONST
  => Term PLUS INT_CONST STAR INT_CONST
  => Unary PLUS INT_CONST STAR INT_CONST
  => Factor PLUS INT_CONST STAR INT_CONST
  => INT_CONST PLUS INT_CONST STAR INT_CONST
```
`compiler_print_derivation` starts with the LHS of the *last* reduction (`Expr`), then walks the history backwards; for each reduction it finds the **rightmost non-terminal** in the current sentential form and replaces it with the production's right-hand side. A LR parser performs a *rightmost derivation in reverse*, so this must always succeed; if it did not, the program would print `(derivation check failed)` — it works as a self-check on the parser.

### B.4 Semantic processing (syntax-directed translation)

The value of a non-terminal is computed from the values of its right-hand-side symbols **when the reduction happens** (bottom-up, "synthesized attributes"). Code:

```c
Operand rhs[10] = {{0}}, out = {0};
for (int j = 0; j < len; j++) rhs[j] = st.entries[base + j].value;   // values of the popped cells, left to right
switch (pno) {
    case 7:  out = ir_binary(ir, OP_ADD, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;   // Sum -> Sum PLUS Term
    case 10: out = ir_binary(ir, OP_MUL, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d)); break;   // Term -> Term STAR Unary
    case 14: out = ir_unary (ir, OP_NEG, rhs[1], rhs[1].d); break;                                  // Unary -> MINUS Unary
    case 13: out = rhs[1]; break;                                                                   // Unary -> PLUS Unary   (no code)
    case 17: out = rhs[1]; break;                                                                   // Factor -> LPAREN Expr RPAREN (no code)
    case 18: out = rhs[0]; break;   /* leaf: the constant pushed at shift time */
    ...
}
```
Production numbers (from the printed grammar): `13` unary plus, `14` unary minus, `15` `~`, `16` `Unary → Factor`, `17` parenthesised expression, `18` `INT_CONST`, `19` `FLOAT_CONST`.

Four kinds of action:
1. **Leaf** (`18`, `19`): the value was created when the number token was shifted (`ir_int(tk->int_value)` / `ir_float(...)`), reduction just passes it up.
2. **Chain** (`2,4,6,9,12,16`): pass `rhs[0]` up unchanged.
3. **Binary/unary operator** (`1,3,5,7,8,10,11,14,15`): call `ir_binary`/`ir_unary` → **emit TAC**, return the temp.
4. **Grouping/sign** (`13`, `17`): return the inner value; no TAC.

Trace of the semantic values for `3 + 5 * 2` (illustrative of the data, matches the real TAC):

| Reduction | rhs values received | emitted | value pushed |
| --- | --- | --- | --- |
| #1–#4 (3 → Sum) | const 3 | – | const 3 |
| #5–#7 (5 → Term) | const 5 | – | const 5 |
| #10 `Term → Term STAR Unary` | rhs[0]=const 5, rhs[2]=const 2 | `t1 = 5 * 2` | temp t1 |
| #11 `Sum → Sum PLUS Term` | rhs[0]=const 3, rhs[2]=temp t1 | `t2 = 3 + t1` | temp t2 |

At ACCEPT the value on top (`t2`) is `ParseSummary.result`; `main` calls `ir_finish(&ir, result)`, which emits nothing extra because `t2` is already the last instruction's result.

Real TAC and the reductions that produced it (this connection is exactly "how grammar reductions lead to intermediate code"):
```
TAC emitted by semantic actions attached to reductions:
  reduction #10  Term -> Term STAR Unary    -> t1 = 5 * 2
  reduction #11  Sum -> Sum PLUS Term       -> t2 = 3 + t1

--- Generated TAC ---
  t1 = 5 * 2                     [int]
  t2 = 3 + t1                    [int]
```
A float example, showing the semantic action inserting a conversion (done inside `ir_binary` via `ir_promote`/`conv`):
```
TAC emitted by semantic actions attached to reductions:
  reduction #8   Sum -> Sum PLUS Term       -> t1 = 1 + 2
  reduction #17  Term -> Term STAR Unary    -> t2 = (float) t1 ; t3 = t2 * 2.5

--- Generated TAC ---
  t1 = 1 + 2                     [int]
  t2 = (float) t1                [float]
  t3 = t2 * 2.5                  [float]
```

### B.5 Error handling

* **Blank ACTION cell** ⇒ error: record `err_pos`, `err_state`, the token symbol, and `expected_terminals()` = every terminal with a non-blank cell in that state.
* **Illegal character** (token type −1 ⇒ `compiler_token_terminal` = −1): a lexical-error row, same bookkeeping.
* No recovery: the first error ends the parse (`main` prints sections 8 and skips TAC/optimization/codegen).

Real error trace for `3 + * 5`:
```
Step  State  Parsing stack (state symbol state ...)         Remaining input                Action Description
-------------------------------------------------------------------------------------------------------------------------------------
1     0      0                                              3 + * 5 $                      s5     SHIFT INT_CONST, push state 5
2     5      0 INT_CONST 5                                  + * 5 $                        r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[0,Factor]=13
3     13     0 Factor 13                                    + * 5 $                        r16    REDUCE Unary -> Factor : pop 1, GOTO[0,Unary]=12
4     12     0 Unary 12                                     + * 5 $                        r12    REDUCE Term -> Unary : pop 1, GOTO[0,Term]=11
5     11     0 Term 11                                      + * 5 $                        r9     REDUCE Sum -> Term : pop 1, GOTO[0,Sum]=10
6     10     0 Sum 10                                       + * 5 $                        s21    SHIFT PLUS, push state 21
7     21     0 Sum 10 PLUS 21                               * 5 $                          err    ERROR: ACTION[21,STAR] is blank
```
```
Input: 3 + * 5
Result: REJECTED - syntax error at token #3 '*' (parser state 21)
Expected one of: PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST
Parser actions before the error: 7 steps (2 shifts, 4 reductions)

[9]-[11] Skipped: no successful parse, so no intermediate code is generated.
```
After `3 +` (state 21) the parser needs the start of a `Term`; `*` is not allowed there, so `ACTION[21,STAR]` is blank. The "Expected one of" list is read directly from state 21's row.

### B.6 Why the parser is "table-driven, not hardcoded"

`compiler_parse` contains **no** grammar knowledge except the semantic-action `switch`. Change the table (by changing the grammar) and the *same loop* parses a different language. The parsing decision (`slr_get_action`) never looks at production names.

---

## C. Concepts you must understand

* **Shift-reduce (bottom-up) parsing**: build the parse tree from the leaves up; shift = move the next token onto the stack; reduce = replace a handle on top of the stack by its non-terminal.
* **LR parsing configuration**: *stack contents + remaining input*. The trace prints exactly that at each step.
* **Parser states vs grammar symbols**: states summarize "what has been recognised"; symbols are what was recognised.
* **ACTION & GOTO** (what each entry does to the stack, see B.2).
* **Handle** and **reduction**; the reduce pops `|rhs|` cells.
* **Rightmost derivation in reverse** = the sequence of reductions.
* **Accept / reject**.
* **Syntax-directed translation, synthesized attributes, S-attributed definition**, semantic actions at reduction time.
* **Reduction tracking** purpose: auditing/teaching — proves which productions were used.

---

## D. Important functions and data structures

| Item | What / why | Inputs → outputs | Used by | If wrong or removed |
| --- | --- | --- | --- | --- |
| `ParseStack`/`ParseEntry` | The LR stack with semantic values. | – | `compiler_parse` | Without values, no TAC; with wrong state, wrong GOTO ⇒ parse derails. |
| `compiler_parse` | Entire parser. | tokens + table + fresh IR/history → accept flag, `ParseSummary`, filled IR/history | `main.c`, `test_opt.c` | – |
| `compiler_token_terminal` | Token type → terminal id. | `TokenType` → int | `compiler_parse` | Wrong ⇒ parser reads the wrong column of ACTION. |
| `format_stack`, `format_input`, `format_production` | Text for trace/history. | – | trace, `reduction_add` | Cosmetic (but the history strings come from here). |
| `expected_terminals` | "Expected one of…". | state → text | error branch | Cosmetic. |
| `ReductionRecord`/`ReductionHistory` | Persistent reduction log. | – | `compiler.c` writes, `main.c` prints | – |
| `reduction_set_emitted` | Links a reduction to its TAC. | text → latest record | `compiler_parse` | Section 9's "which reduction emitted this" would be empty. |
| `compiler_print_derivation` | Self-checking derivation printout. | history → text | `main.c` | – |
| `ParseSummary` | Results of one parse. | – | `main.c` | – |

Why `Operand rhs[10]`: `MAX_RHS` is 10; the code also rejects productions with `len > 10`.

---

## E. Viva preparation

**Fundamentals**

1. *What is shift-reduce parsing?* A bottom-up method: tokens are pushed (shift); when the top of the stack matches the right side of a production and the table says so, it is replaced by the left side (reduce); repeat until the start symbol with `$` is accepted.
2. *What do ACTION and GOTO do in the parse?* ACTION[state, lookahead terminal] chooses shift/reduce/accept/error. After a reduce, GOTO[state_below, LHS] gives the state to push.
3. *Why does the stack hold states, and also symbols?* Only states matter for decisions; symbols are kept for display and the derivation (state ⇒ symbol is determined in LR parsers).
4. *How does the parser know when to accept?* `ACTION[7,$] = acc`, i.e. state 7 contains `Expr' → Expr .` and the lookahead is `$`.

**Implementation**

5. *Walk through step 15 of the trace.* State 31 on top, lookahead `$`, `ACTION[31,$] = r10`: pop 3 cells (`Term 29 STAR 23 Unary 31`), the stack top is now state 21, `GOTO[21,Term] = 29`, push `Term 29`; the semantic action `ir_binary(OP_MUL, 5, 2)` emitted `t1 = 5 * 2`.
6. *Why is `GOTO` looked up with the state below the popped cells?* Because after popping the handle the parser is back in the state where the handle began; the transition on the LHS non-terminal from *that* state is the next state.
7. *Where is the decision made?* `slr_get_action`. The parser has no `if (token == '+')` logic anywhere.
8. *What does `reduction_add` store and why copies?* Stack before/after, remaining input, production text, action label; copies because the parser reuses its stack and buffers.
9. *How do you know the reduction history is not fabricated?* It is written in the branch that pops/pushes the stack (`ACTION_REDUCE`). Count check: `reduces` in the summary equals `history.count`. Also the derivation rebuilt from the history is validated step by step.
10. *What is `step < 100000` for?* A guard against infinite loops.
11. *How is a semantic value attached to a symbol?* In `ParseEntry.value`: set at shift (`ir_int`/`ir_float` for numbers) or at reduce (`out`).
12. *Why do chain productions (`Sum → Term`) cause so many reductions?* They encode precedence levels; `3` needs 4 reductions to become a `Sum`. 14 reductions for 5 tokens.
13. *What is returned on error and what is printed?* `compiler_parse` returns 0, `ParseSummary` has token/state/expected; `main` prints section 8 REJECTED and skips later phases.
14. *Why do semantic actions run at reduce time, not shift time?* The operands of an operator are complete only when the whole production has been recognised.
15. *Why can parentheses not generate TAC?* They only affect parse structure (which reductions happen in which order); `case 17` returns the inner value.

**Design alternatives / extensions**

16. *Add a new operator `%` – what changes for you?* A new `case` in the switch for its production number (and renumbering of later cases if productions are inserted). The loop, history and trace need no change.
17. *Could semantic actions be separate from the parser?* Yes: build a parse tree during parsing (record productions) and walk it later; here the actions run on the fly to avoid building a tree.
18. *Would you add error recovery? How?* "Panic mode": on error pop states until one has a goto/shift on an error token, skip input until a synchronising token. Not implemented.
19. *Stack limit?* 4096 cells, but input is capped at 2048 tokens so the stack cannot overflow.

**Edge cases**

20. Empty input: lookahead `$` in state 0 ⇒ error, expected list = start-of-expression tokens. Single number `7`: 1 shift, 7 reductions (`Factor, Unary, Term, Sum, And, Xor, Expr`), accept; TAC = one assignment `t1 = 7` (emitted by `ir_finish`, because no operator reduction emitted anything) — nothing to optimize.
21. Unbalanced `(3 + 4`: the error is detected at `$` in state 17 (expecting `RPAREN` or operators).
22. Mixed int/float: `ir_promote` picks float; conversions happen inside `ir_binary`.

**Interaction**

23. *What does the parser need from the table module?* Only `slr_get_action` and `slr_get_goto`; plus the production length and LHS (read directly from `Grammar` in this code).
24. *What does the parser give the IR module?* A sequence of `ir_binary`/`ir_unary` calls with `Operand` values, in reduction order — which is the evaluation order.
25. *If the semantic action for `*` were wrong (say it emitted `OP_ADD`)?* Parsing and the reduction history would still look perfect (the syntax is right), but TAC and every later phase would compute the wrong value — and `3 + 5 * 2` would print 10 instead of 13. This is why `main` verifies the numeric result at the end.

**Understanding vs memorizing**

26. *Predict the number of reductions for `((7))`.* Tokens: `( ( 7 ) )` + `$`. Each `7` goes `Factor→Unary→Term→Sum→And→Xor→Expr`: after `7`: `Factor, Unary, Term, Sum, And, Xor, Expr` (7), then `Factor → ( Expr )` (1), then again the 6-step climb back to `Expr` (`Unary, Term, Sum, And, Xor, Expr` = 6) and `Factor → ( Expr )` (1), and then the final climb 6 → total 7 + 1 + 6 + 1 + 6 = 21. The real run (`./mini_compiler --quiet "((7))"`) prints `27 steps = 5 shifts + 21 reductions + 1 accept`, matching the prediction.

---

## F. Beyond your section

| Level | Topics |
| --- | --- |
| **Know thoroughly** | parse stack mechanics, every action type, GOTO use, reduction history, semantic actions and values, rejection path. |
| **Understand at high level** | how the table was built (items, FOLLOW) — Mahendra; what the lexer produces (Aditya); what TAC/optimizer/codegen do with your output (Sarvesh). |
| **Be familiar with** | `ir_binary`, `ir_unary`, `ir_promote`, `ir_finish` (what each emits); `main.c` `run_one`. |
| **Interfaces** | Aditya → you: `Token[]`, `lexer_symbol_names`. Mahendra → you: ACTION/GOTO queries. You → Sarvesh: the IR (`IR` with `TAC[]`) built by semantic actions, `ParseSummary.result`. |

Try: `./mini_compiler "3 + 5 * 2"` and follow the trace; `./mini_compiler "(3 + 4"`; `./mini_compiler "((7))"`.
