# Modification and Testing Report

All results below were produced by commands actually run while this report was generated (the generation script re-ran every command and pasted its output). Nothing here is claimed without being executed.

## 1. Project history

* **Original upload** (`mini_compiler_integrated.zip`): complete mini-compiler, output weighted toward TAC and optimization.
* **Revision 1** (first request): shift the emphasis to the syntax analyzer.
* **Revision 2** (this request): full documentation set, optimizer transformations made visible, additional tests. The uploaded `mini_compiler_integrated_2.zip` was byte-identical to the Revision 1 output, so work continued from it.

## 2. What was changed, and why

### Revision 1 — syntax-analyzer focus
| File | Change | Reason |
| --- | --- | --- |
| `main.c` | Rewritten driver: 11 ordered sections; table built once; `--demo`, `--no-table`, `--conflict-demo`; conflict summary counts; final-result section; exit codes. | Requirement: prominent parser, specified output order. |
| `compiler.c/.h` | `ParseSummary`; caller-owned `ReductionHistory`; trace shows stack/input/action and `GOTO[s,A]=n`; error reports token, state, expected tokens; rightmost-derivation self-check; reductions linked to the TAC they emit. | Stack-based parsing visibility; reduction tracking; reductions → TAC connection. |
| `reduction.c/.h` | `emitted` field, `reduction_set_emitted`, richer `reduction_print`, `reduction_print_emitters`. | Reduction tracking and TAC link. |
| `ir.c/.h` | `ir_fmt_tac` (one-instruction formatter; `ir_print` reuses it). | Needed to show emitted TAC. |
| `Makefile`, `README.md`, `AUDIT_REPORT.md` | `--conflict-demo` in `make test`; docs rewritten. | – |

### Revision 2 — this request
| File | Change | Reason |
| --- | --- | --- |
| `optimizer.c/.h` | Every pass records each transformation (`OptChange`: line, before, after, rule, why) in an `OptLog`; pass signatures now `int pass(IR*, OptLog*)` (`NULL` = no logging); `opt_run(verbose)` prints each pass of each round (before / changes / after, or "no transformations (reason)"); `OptStats` gained `before_n`, `after_n`, `fixed`; summary line states instructions before → after and that the last round changed nothing. **Behavioural fix** in `opt_simplify` (see §3). | Part 3: show exactly what changes, where and why. |
| `main.c` | `--opt-brief`, `--no-opt`; section 10 uses the detailed pipeline by default; check line labels unoptimized runs; `3 @ 4` added to the demo. | Visibility; ability to exercise codegen. |
| `compiler.c` | Illegal characters now produce a proper error row and an "expected one of" list (previously the list was empty); remaining-input display shows the illegal character. | Error-reporting accuracy. |
| `test_opt.c` (new) | Unit tests for each pass, regression test, randomized semantic test (original TAC / optimized TAC / machine on optimized TAC / machine on unoptimized TAC). | Part 6 requirement 12. |
| `Makefile` | `test_opt` target; `make test` runs it; `clean` removes it. | – |
| `README.md`, `docs/*.md` | New documentation set (master README, source reference, four study guides, optimization walkthrough, beginner guide, this report). | Parts 1, 2, 4, 5. |

## 3. Bugs and defects found

| # | Finding | Status |
| --- | --- | --- |
| 1 | **Type-unsafe simplification** — `opt_simplify` rewrote bitwise identities (`0 \| x`, `x ^ 0`, `x & -1`, `x & x`, `x \| x`) to `t = x` even when `x` was a float operand of an `int`-typed instruction. The interpreter hid it (it truncates again); the target machine returned a float where the original code gave an int. Found by the randomized test: **87 of 3000** int+float expressions disagreed. | **Fixed** (operand must be `int`); regression test `0 \| 2.5`; randomized test now 0 mismatches. |
| 2 | Illegal character produced an error with an empty "expected" list (introduced in Revision 1's error path, caught while documenting). | **Fixed** in Revision 2. |
| 3 | Reporting: optimizer showed counts only; `rounds` counted the confirming round without saying so. | **Fixed** (full per-pass reporting; summary says "the last one changed nothing"). |
| 4 | Division by zero has no defined value: interpreter → 0, machine → leaves register unchanged, so the final `Check:` reports FAIL for `8 / 0`; `(8 / 0) * 0` optimizes to `0` (dead division removed). | **Not fixed**; documented as a limitation (defining the behaviour would need a language-level decision: error vs. trap). |
| 5 | Makefile ignores header dependencies. | **Not fixed**; documented (`make clean && make`). |
| 6 | Unused API: `lexer_peek`, `ir_var`/`ir_bind`/`ir_result`, `OP_POS` never emitted, `K_VAR` unreachable from the grammar. | Informational; left in place (harmless). |

## 4. Features that were already correct (verified, not modified)

SLR(1) table generation (closure/goto/FIRST/FOLLOW/ACTION/GOTO — 97 existing checks pass), conflict detection and reporting, the lexer, the grammar and its precedence encoding, TAC generation and 32-bit/float arithmetic, folding/propagation/dead-code logic, register allocation and spilling in the code generator (verified by the new random tests on **unoptimized** TAC).

## 5. Incomplete or unsupported (not part of the project)

Variables/identifiers; additional operators; error recovery; code motion, strength reduction, CSE, peephole (explicitly **not implemented**); defined division-by-zero semantics.

## 6. Tests executed (real output)

### 6.1 Clean build with warnings enabled (`-std=c99 -Wall -Wextra -pedantic -O2`)
```
cc -std=c99 -Wall -Wextra -pedantic -O2 -c main.c -o main.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c compiler.c -o compiler.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c lexer.c -o lexer.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c grammar.c -o grammar.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c lr_items.c -o lr_items.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c syntax_table.c -o syntax_table.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c reduction.c -o reduction.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c ir.c -o ir.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c optimizer.c -o optimizer.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -c codegen.c -o codegen.o
cc -std=c99 -Wall -Wextra -pedantic -O2 -o mini_compiler main.o compiler.o lexer.o grammar.o lr_items.o syntax_table.o reduction.o ir.o optimizer.o codegen.o -lm
(no warning or error lines above: the build is clean)
```

### 6.2 `./test_slr` — table generator (existing suite)
```
No conflicts: the grammar is SLR(1).
--- Grammar 1: ambiguous   E -> E PLUS E | ID ---
1 conflict(s) detected: the grammar is NOT SLR(1).
--- Grammar 2: reduce/reduce   S -> A | B ; A -> ID ; B -> ID ---
1 conflict(s) detected: the grammar is NOT SLR(1).
--- Grammar 3: LR(1) but not SLR(1)   S -> L EQ R | R ; L -> STAR R | ID ; R -> L ---
1 conflict(s) detected: the grammar is NOT SLR(1).
--- Grammar 4: two reductions competing on two lookaheads ---
=== 97 checks passed, 0 failed ===
```

### 6.3 `./test_opt` — optimizer (new)
```
-- unit tests: each pass on its own --
-- randomized semantic check (fixed seed, 3000 expressions) --
  int only: 917 expressions run (2083 skipped), 0 mismatches
  int+float: 3000 expressions run (0 skipped), 0 mismatches

=== 36 checks passed, 0 failed ===
```

### 6.4 `./mini_compiler --quiet --demo` — whole pipeline (compact lines)
```
################ TEST 1: 3 + 5 * 2 ################
Result: ACCEPTED - valid expression
Check: original TAC = 13 | optimized TAC = 13 | target machine = 13 -> PASS
################ TEST 2: -(4 + 6) * 2 ################
Result: ACCEPTED - valid expression
Check: original TAC = -20 | optimized TAC = -20 | target machine = -20 -> PASS
################ TEST 3: 5 & 3 | 2 ################
Result: ACCEPTED - valid expression
Check: original TAC = 3 | optimized TAC = 3 | target machine = 3 -> PASS
################ TEST 4: 3.5 + 2 * 4 ################
Result: ACCEPTED - valid expression
Check: original TAC = 11.5 | optimized TAC = 11.5 | target machine = 11.5 -> PASS
################ TEST 5: ~~5 ################
Result: ACCEPTED - valid expression
Check: original TAC = 5 | optimized TAC = 5 | target machine = 5 -> PASS
################ TEST 6: 8 / 2 + 3 ################
Result: ACCEPTED - valid expression
Check: original TAC = 7 | optimized TAC = 7 | target machine = 7 -> PASS
################ TEST 7: -3 * +4 ################
Result: ACCEPTED - valid expression
Check: original TAC = -12 | optimized TAC = -12 | target machine = -12 -> PASS
################ TEST 8: (1 + 2) * (3 + 4) ################
Result: ACCEPTED - valid expression
Check: original TAC = 21 | optimized TAC = 21 | target machine = 21 -> PASS
################ TEST 9: 10 - 4 - 3 ################
Result: ACCEPTED - valid expression
Check: original TAC = 3 | optimized TAC = 3 | target machine = 3 -> PASS
################ TEST 10: 3 + * 5 ################
Result: REJECTED - syntax error at token #3 '*' (parser state 21)
################ TEST 11: (3 + 4 ################
Result: REJECTED - syntax error at token #5 '$' (parser state 17)
################ TEST 12: 3 @ 4 ################
Result: REJECTED - syntax error at token #2 '@' (illegal character) (parser state 5)
DEMO SUMMARY: ALL PASS (9 valid expressions parsed and verified, 3 invalid expressions rejected as expected)
```

### 6.5 Expected vs actual results for representative expressions
Expected values come from an **independent Python evaluator** (own parser with the same precedence, 32-bit int wraparound, truncating int division); actual values are the program's final `Check:` line (original TAC = optimized TAC = machine).

| Expression | Expected (independent evaluator) | Actual: original TAC / optimized TAC / machine | Result |
| --- | --- | --- | --- |
| `3 + 5 * 2` | 13 | 13 / 13 / 13 | match |
| `-(4 + 6) * 2` | -20 | -20 / -20 / -20 | match |
| `5 & 3 \| 2` | 3 | 3 / 3 / 3 | match |
| `3.5 + 2 * 4` | 11.5 | 11.5 / 11.5 / 11.5 | match |
| `~~5` | 5 | 5 / 5 / 5 | match |
| `8 / 2 + 3` | 7 | 7 / 7 / 7 | match |
| `-3 * +4` | -12 | -12 / -12 / -12 | match |
| `(1 + 2) * (3 + 4)` | 21 | 21 / 21 / 21 | match |
| `10 - 4 - 3` | 3 | 3 / 3 / 3 | match |
| `2 + 3 * 4 ^ 6` | 8 | 8 / 8 / 8 | match |
| `7 / 2` | 3 | 3 / 3 / 3 | match |
| `7 / 2.0` | 3.5 | 3.5 / 3.5 / 3.5 | match |
| `~5 + 1` | -5 | -5 / -5 / -5 | match |
| `1 \| 2 ^ 3 & 4` | 3 | 3 / 3 / 3 | match |
| `(2.5 + 1.5) * 2` | 8 | 8 / 8 / 8 | match |
| `2147483647 + 1` | -2147483648 | -2147483648 / -2147483648 / -2147483648 | match |
| `10 / 3 * 3` | 9 | 9 / 9 / 9 | match |
| `- - 5` | 5 | 5 / 5 / 5 | match |
| `+ - + 5` | -5 | -5 / -5 / -5 | match |
| `1.5 * 4 - .5` | 5.5 | 5.5 / 5.5 / 5.5 | match |
| `(1 + 2) * 2.5` | 7.5 | 7.5 / 7.5 / 7.5 | match |
| `7` | 7 | 7 / 7 / 7 | match |

All 22 expressions: expected = actual in every column.

### 6.6 Parsing-table generation and conflict detection
* `./mini_compiler` section 5 for the compiler grammar: `Parsing table is CONFLICT-FREE (the grammar is SLR(1)).`
* `./test_slr`: 4 conflict grammars (ambiguous, reduce/reduce, LR(1)-not-SLR(1), double reduce) — included in the 97 checks above.
* `./mini_compiler --conflict-demo` (last line): `CONFLICT DEMO: conflicts reported for both grammars`

### 6.7 Syntax errors and edge cases
| Input | Output (section 8 result / final check) |
| --- | --- |
| `(empty)` | REJECTED - syntax error at token #1 '$' (parser state 0) — expected: PLUS, MINUS, TILDE, LPAREN, INT_CONST, FLOAT_CONST |
| `3 @ 4` | REJECTED - syntax error at token #2 '@' (illegal character) (parser state 5) — expected: $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN |
| `(3 + 4` | REJECTED - syntax error at token #5 '$' (parser state 17) — expected: PIPE, RPAREN |
| `3 4` | REJECTED - syntax error at token #2 'int' (parser state 5) — expected: $, PLUS, MINUS, STAR, SLASH, AMP, PIPE, CARET, RPAREN |
| `8 / 0` | ACCEPTED - valid expression — Check: original TAC = 0 \| optimized TAC = 0 \| target machine = 8 -> FAIL (results disagree) (documented limitation) |
| `(8 / 0) * 0` | ACCEPTED - valid expression — Check: original TAC = 0 \| optimized TAC = 0 \| target machine = 0 -> PASS |
| `2147483647 + 1` | ACCEPTED - valid expression — Check: original TAC = -2147483648 \| optimized TAC = -2147483648 \| target machine = -2147483648 -> PASS |
| `7` | ACCEPTED - valid expression — Check: original TAC = 7 \| optimized TAC = 7 \| target machine = 7 -> PASS |

### 6.8 Memory/undefined-behaviour check (AddressSanitizer + UBSan)
All programs rebuilt with `-fsanitize=address,undefined -g` and run:
```
mini_compiler --demo                     exit=0  sanitizer messages on stderr: 0 bytes
mini_compiler --conflict-demo            exit=0  sanitizer messages on stderr: 0 bytes
mini_compiler --no-opt (spill case)      exit=0  sanitizer messages on stderr: 0 bytes
test_opt                                 exit=0  sanitizer messages on stderr: 0 bytes
test_slr                                 exit=0  sanitizer messages on stderr: 0 bytes
```

### 6.9 Not tested / not claimed
No Windows build was run (`build.bat` mirrors the Makefile's source list but was not executed here). No performance testing. Behaviour on grammars other than the shipped one is covered only by `test_slr.c` and `--conflict-demo`.
