# Source Code Reference — every `.c` and `.h` file

This is Part 1 of the documentation set. It describes what the code **actually does** (verified by reading and running it), not what a textbook compiler "should" do. For the C/header fundamentals (what `#include`, linking, `extern` mean) see `Beginners_Complete_Learning_Guide.md` §2. Study guides for each team member are in the same folder.

Line counts below are from the delivered sources. "Used by" and "calls" lists were extracted mechanically from the code (include lines and function-name matches), then checked by hand.

---

## 0. The pipeline in one picture

```
 text ──► lexer.c ──► Token[] ──► compiler.c ◄── ACTION/GOTO (syntax_table.c) ◄── LR(0) sets (lr_items.c) ◄── Grammar (grammar.c)
                                   │  (shift-reduce loop,                                  (built ONCE per run, before any input is parsed)
                                   │   semantic actions)
                                   ├─► reduction.c  (history of reductions)
                                   └─► ir.c  ──► IR (TAC list) ──► optimizer.c ──► IR (optimized) ──► codegen.c ──► Target (machine code)
```

* **Built once per run:** `grammar_load_compiler` → `slr_generate` (FIRST/FOLLOW, LR(0) item sets, ACTION/GOTO, conflict detection).
* **Per expression:** `lexer_tokenize` → `compiler_parse` (+ semantic actions) → `ir_finish` → `opt_run` → `cg_generate` → verification (`ir_eval`, `cg_run`).

---

## 1. Source files (`.c`)

### 1.1 `main.c` (≈150 lines) — driver and output organizer

**Purpose.** Program entry point. Parses command-line flags, builds the parser once, then for each expression runs every compiler phase and prints the 11 output sections.

**Key types.** `Frontend { Grammar g; SLRTable t; }` (the generated parser), `Opts { quiet, tables, optdetail, noopt }` (output switches).

**Functions.**

| Function | What it does |
| --- | --- |
| `main` | Reads flags (`--quiet`, `--table`, `--no-table`, `--demo`, `--conflict-demo`, `--opt-brief`, `--no-opt`, an expression). Builds the `Frontend`, **refuses to continue if the table has conflicts** (prints the conflict report and exits 1), then runs one expression or the `--demo` list. Returns 0 only if everything passed. |
| `frontend_build` | `grammar_load_compiler()` then `slr_generate()`. This is the *parser-generation* step. |
| `print_table_report` | Prints sections 2–5: grammar + FIRST/FOLLOW, LR(0) item sets, ACTION/GOTO tables with entry counts, and a conflict summary (counts S/R, R/R, other). Counts are computed by scanning the real table with `slr_get_action`/`slr_get_goto`/`slr_get_conflict`. |
| `run_one` | One expression end to end. Tokenizes, prints section 1, calls `compiler_parse`, prints trace/reduction history/result, then `ir_finish` → TAC section → `opt_run` → `cg_generate` → verification. Returns `1` accepted+verified, `0` accepted but a later phase disagreed, `-1` syntax error. |
| `conflict_demo` | Builds two deliberately non-SLR(1) grammars with the public grammar API and runs the **real** table generator on them, so conflict reports can be demonstrated. |
| `section`, `numeric` | Banner printer; `Operand` → `double` for comparing results. |

**Flow in `run_one`.** (1) `lexer_tokenize` → (2) `ir_init`, `reduction_init` (fresh per expression) → (3) `compiler_parse` → (4) if rejected: print error info, free, return −1 → (5) `ir_finish(&original, sum.result)`, `ir_copy` into `optimized` → (6) `opt_run` (unless `--no-opt`) → (7) `cg_generate(&optimized, …)` → (8) compare `ir_eval(original)`, `ir_eval(optimized)`, `cg_run(target)`.

**Depends on:** `compiler.h`, `optimizer.h`, `codegen.h` (which pull in everything else). **Called by:** the OS (it is `main`).

**Decisions / limitations.** Token buffer is `Token tokens[2048]` on the stack (≈250 KB); longer input is refused with a message. In `--demo`, sections 2–5 are printed once (first test) — the later tests reuse the same generated table. The final `Check:` line exists to catch disagreement between phases; for `8 / 0` it reports FAIL because the three evaluators handle division by zero differently (see Known Limitations in the README).

---

### 1.2 `compiler.c` (≈190 lines) — the shift-reduce parser + semantic actions

**Purpose.** The heart of the project: a table-driven LR parser with an explicit stack, reduction tracking, error reporting, and the semantic actions that emit TAC during reductions.

**Key types / globals (all file-private).**
* `ParseEntry { int state; int symbol; Operand value; }` — one stack cell: the DFA state, the grammar symbol that led to it (−1 for the bottom cell), and the **semantic value** (an `Operand`: constant or temp).
* `ParseStack { ParseEntry entries[4096]; int n; }`.
* `lexer_symbol_names[]` — maps lexer token types to grammar terminal names (`TOK_INTEGER`→`"INT_CONST"`, `TOK_MULTIPLY`→`"STAR"`, …). This array is the **bridge between lexer vocabulary and grammar vocabulary**.

**Functions.**

| Function | Role |
| --- | --- |
| `compiler_token_terminal(g, type)` | Token type → grammar symbol id via `grammar_find_symbol` on the name in `lexer_symbol_names`. Returns −1 for `TOK_INVALID`. |
| `compiler_print_tokens` | Section 1 token table (uses `token_format`). |
| `format_stack`, `format_input`, `format_production` | Turn the stack / remaining tokens / a production into text for the trace and reduction history. (Stack text is cut at 512 chars.) |
| `expected_terminals` | For an error state: every terminal whose ACTION cell is non-blank → "Expected one of: …". |
| `compiler_parse` | The parsing loop (below). |
| `compiler_print_derivation` | Rebuilds the **rightmost derivation** from the recorded reductions (last reduction first, always replacing the rightmost non-terminal); prints `(derivation check failed)` if the history were ever inconsistent. |

**`compiler_parse` step by step.**
1. Initialise an empty `ParseStack` with the start state `{0, -1}`; zero the `ParseSummary`.
2. Loop: take current token → terminal id (`compiler_token_terminal`). If −1 → *lexical error* row, stop.
3. `a = slr_get_action(table, topState, terminal)` — **every decision comes from the table**.
4. `ACTION_SHIFT`: print row, push `{a.value, terminal, value}` where the value is `ir_int/ir_float` for number tokens; advance.
5. `ACTION_REDUCE p`: look up `len = rhs_len`, compute `gs = slr_get_goto(table, state_below_the_popped_part, lhs)` (shown in the trace as `GOTO[s,A]=n`), gather the `len` semantic values `rhs[0..len-1]`, run the semantic action `switch (p)` (below), pop `len` entries, push `{gs, lhs, out}`, then `reduction_add` (stack before/after, remaining input) and, if `ir->n` grew, `reduction_set_emitted` with the new TAC text.
6. `ACTION_ACCEPT`: record the result operand (`st.entries[top].value`), set `accepted`.
7. `ACTION_ERROR` (blank cell): record token, state, expected terminals; stop.

**Semantic actions** (the `switch (pno)` — keyed on production numbers from `grammar_load_compiler`):
`1` Expr→Expr PIPE Xor ⇒ `ir_binary(OP_OR…)`; `3` XOR; `5` AND; `7`/`8` Sum PLUS/MINUS Term ⇒ `ir_binary(OP_ADD/OP_SUB, …, ir_promote(l.d, r.d))`; `10`/`11` MUL/DIV; `13` unary plus ⇒ passes `rhs[1]` up (no TAC); `14` unary minus ⇒ `ir_unary(OP_NEG…)`; `15` `~` ⇒ `OP_NOT`; `17` `( Expr )` ⇒ passes `rhs[1]` up (no TAC); chain productions (`2,4,6,9,12,16`) and leaves (`18,19`) just pass `rhs[0]` up. **If the grammar's production order changes, this switch must change with it.**

**Depends on:** `compiler.h` (→ grammar, syntax_table, lexer, ir, reduction). **Calls into:** lexer (`token_*`), grammar (`grammar_find_symbol`), syntax_table (`slr_get_action`, `slr_get_goto`), reduction (`reduction_add`, `reduction_set_emitted`), ir (`ir_int`, `ir_float`, `ir_binary`, `ir_unary`, `ir_promote`, `ir_fmt_tac`). **Called by:** `main.c`, `test_opt.c`.

**Limitations.** No error recovery (first error ends the parse). Stack depth 4096, but the 2048-token limit means it cannot overflow. A semantic value is stored for every stack cell even for operators (unused).

---

### 1.3 `lexer.c` (≈120 lines) — lexical analyzer

**Purpose.** Convert the input string into `Token`s. Hand-written scanner (no regex engine, no generated automaton).

**Functions.** `lexer_init` (zero the `Lexer`, line 1, column 1); `scan` (static, the real scanner); `lexer_next` / `lexer_peek` (one-token lookahead wrapper; `lexer_peek` is not used by the pipeline); `lexer_tokenize(src, out, cap)` (the only function other modules use: fills `out[]` until `TOK_END_OF_INPUT` or `cap`); `token_name` / `token_symbol` / `token_format` (printing helpers backed by `NAMES[]` and `SYMBOLS[]`); static helpers `cur`, `adv` (advance + line/column bookkeeping), `take` (copy one char into the lexeme, bounded by `MAX_LEXEME`).

**`scan` algorithm.** Skip whitespace → record offset/line/column → end of string ⇒ `TOK_END_OF_INPUT` (lexeme `"$"`). If a digit, or `.` followed by a digit: read digits; if a `.` follows, read it and the following digits (`is_float`); convert with `strtod`/`strtoll`. Otherwise a `switch` on the single character picks the operator/parenthesis token; anything else becomes `TOK_INVALID` (the character is kept as the lexeme).

**Behaviour worth knowing.** `.5` and `3.` are legal floats; there is no exponent notation (`1e5` → `INTEGER(1)` then an invalid `e`); a leading `-` is **never** part of a number (it is the unary-minus token, handled by the grammar); integers above 32 bits are read with `strtoll` but later wrapped to 32-bit by `ir_int`.

**Depends on:** `lexer.h`. **Called by:** `main.c`, `test_opt.c` (`lexer_tokenize`); `compiler.c` (`token_name`, `token_symbol`, `token_format`).

---

### 1.4 `grammar.c` (≈235 lines) — grammar representation and the compiler's grammar

**Purpose.** Store a context-free grammar in arrays, build it from text rules, augment it, print it, and define **the expression grammar** (`grammar_load_compiler`).

**Structures** (in `grammar.h`): `Symbol {name, is_terminal}`, `Production {lhs, rhs_len, rhs[]}`, `Grammar {symbols[64], prods[128], …}`. Terminals and non-terminals share **one id space**; symbol 0 is `$`; production 0 is reserved for `S' -> S`.

**Functions.** `grammar_init` (clears, creates `$`, reserves production 0); `grammar_add_terminal/_nonterminal/_find_symbol` (via private `add_symbol`); `grammar_add_production` (validates ids, appends); `grammar_add_rule("Sum","Sum PLUS Term")` (splits words with `split_words`, creates unseen words as non-terminals — which is why **terminals must be declared first**); `grammar_find_rule`; `grammar_augment` (checks every non-terminal has a production, creates `Expr'`, fills production 0); `grammar_print_production`, `grammar_print`; `grammar_load_compiler` (below).

**The grammar** (precedence is encoded by layering; left recursion gives left-associativity):
```
Terminals   : $ PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT_CONST FLOAT_CONST
Non-terminals: Expr Xor And Sum Term Unary Factor Expr'
Start symbol : Expr
Productions (0 = augmented):
  [ 0] Expr' -> Expr
  [ 1] Expr -> Expr PIPE Xor
  [ 2] Expr -> Xor
  [ 3] Xor -> Xor CARET And
  [ 4] Xor -> And
  [ 5] And -> And AMP Sum
  [ 6] And -> Sum
  [ 7] Sum -> Sum PLUS Term
  [ 8] Sum -> Sum MINUS Term
  [ 9] Sum -> Term
  [10] Term -> Term STAR Unary
  [11] Term -> Term SLASH Unary
  [12] Term -> Unary
  [13] Unary -> PLUS Unary
  [14] Unary -> MINUS Unary
  [15] Unary -> TILDE Unary
  [16] Unary -> Factor
  [17] Factor -> LPAREN Expr RPAREN
  [18] Factor -> INT_CONST
  [19] Factor -> FLOAT_CONST
```
**Depends on:** `grammar.h`. **Called by:** `main.c`, `syntax_table.c`, `test_slr.c`, `test_opt.c`, and indirectly everything that reads `Grammar`.

**Limits.** At most 64 symbols (FIRST/FOLLOW sets are 64-bit masks — enforced by a compile-time array-size trick in `syntax_table.h`), 128 productions, 10 symbols per right-hand side, names under 32 chars.

---

### 1.5 `lr_items.c` (≈235 lines) — LR(0) items, closure, goto, canonical collection

**Purpose.** Build the LR(0) automaton (the DFA of viable prefixes).

**Structures.** `LRItem {prod, dot}`; `ItemSet {items[], count, cap}` kept **sorted and duplicate-free**; `LRState {ItemSet set; int *next}` where `next[X]` is the transition on symbol X (−1 if none); `LRCollection {g, states[], num_states, cap}`.

**Functions.** Item helpers (`item_compare`, `item_equal`, `item_is_complete` = dot at end, `item_next_symbol` = symbol after the dot, `item_is_kernel`); set helpers (`itemset_add` sorted-insert, `itemset_contains`, `itemset_equal` element-wise); **`itemset_closure`** (repeat: for each item `A→α.Bβ` with B non-terminal, add `B→.γ` for every production of B; until no change); **`itemset_goto(I, X)`** (advance the dot over X for every item that expects X, then closure); **`lr_collection_build`** (state 0 = closure of `{Expr'→.Expr}`; a work queue that, for each state and each symbol X from 1, computes goto, **reuses an identical existing state** via `lr_collection_find` or creates a new one; fills `next[X]`); printers `lr_print_item`, `lr_print_itemset` (Kernel / Closure split), `lr_print_collection` (items + transitions per state), `lr_print_transitions`.

**Example (real output).**
```
State 0:
  Kernel:
    Expr' -> . Expr
  Closure:
    Expr -> . Expr PIPE Xor
    Expr -> . Xor
    Xor -> . Xor CARET And
    Xor -> . And
    And -> . And AMP Sum
    And -> . Sum
    Sum -> . Sum PLUS Term
    Sum -> . Sum MINUS Term
    Sum -> . Term
    Term -> . Term STAR Unary
    Term -> . Term SLASH Unary
    Term -> . Unary
    Unary -> . PLUS Unary
    Unary -> . MINUS Unary
    Unary -> . TILDE Unary
    Unary -> . Factor
    Factor -> . LPAREN Expr RPAREN
    Factor -> . INT_CONST
    Factor -> . FLOAT_CONST
  Transitions:
    on PLUS         -> State 1
    on MINUS        -> State 2
    on TILDE        -> State 3
    on LPAREN       -> State 4
    on INT_CONST    -> State 5
    on FLOAT_CONST  -> State 6
    on Expr         -> State 7
    on Xor          -> State 8
    on And          -> State 9
    on Sum          -> State 10
    on Term         -> State 11
    on Unary        -> State 12
    on Factor       -> State 13
```
**Depends on:** `lr_items.h` (→ `grammar.h`). **Called by:** `syntax_table.c` (build + print), `test_slr.c`.

**Notes.** State numbering is deterministic (symbol-id order), so state 5 is always `Factor → INT_CONST .`. The closure/dedup uses linear searches — fine for 33 states, not for large grammars.

---

### 1.6 `syntax_table.c` (≈420 lines) — FIRST/FOLLOW, SLR(1) table, conflict detection

**Purpose.** Turn the LR(0) automaton into the ACTION/GOTO parsing table, and detect conflicts **while filling it**.

**Structures** (in `syntax_table.h`): `SymSet` (`uint64_t` bitmask of symbols); `FirstFollow {first[], follow[], nullable[]}`; `Action {type, value}` with `ActionType {ERROR, SHIFT, REDUCE, ACCEPT}`; `Conflict {type, state, terminal, existing, conflicting}`; `SLRTable {grammar, ff, lr, num_states, num_symbols, action[], go[], conflicts[], …}` where `action[state*num_symbols + terminal]`.

**Functions.**
* `first_follow_compute` — fixed-point loops for nullable, FIRST, FOLLOW (details in the Mahendra guide).
* `slr_init` (augment grammar + FIRST/FOLLOW), `slr_build_states` (calls `lr_collection_build`), `slr_build_tables`, `slr_generate` (all three; returns 0 even if conflicts exist — check `slr_is_slr1`).
* `slr_build_tables`: for each state, **pass 1** shifts (`A→α.aβ` ⇒ `s(next[a])`) and accept (`Expr'→Expr.` on `$`); **pass 2** reductions (`A→α.` ⇒ `rN` on every terminal in FOLLOW(A)); then the GOTO row from non-terminal transitions.
* `set_action` — **the conflict detector.** Writing into an empty cell is fine; writing the *same* action again is fine; writing a *different* action keeps the first, calls `add_conflict`, and classifies it (S/R, R/R, other). It also remembers the first reduce in a cell (`first_reduce[]`) so a shift cell that later receives two different reduces reports the reduce/reduce clash too.
* Queries used by the parser: `slr_get_action`, `slr_get_goto` (both bounds-checked and return ERROR / −1 when out of range), `slr_prod_lhs`, `slr_prod_length`, `slr_is_slr1`, `slr_conflict_count`, `slr_get_conflict`.
* Printers: `slr_print_action_table` (marks conflicting cells with `*`), `slr_print_goto_table`, `slr_print_conflicts`, `slr_print_first_follow`, `slr_print_states`.

**Depends on:** `syntax_table.h` (→ `grammar.h`, `lr_items.h`). **Called by:** `main.c`, `compiler.c`, `test_slr.c`, `test_opt.c`.

**Real tables.** ACTION and GOTO for the compiler grammar are reproduced in `Mahendra_Study_Guide.md`.

---

### 1.7 `reduction.c` (≈70 lines) — reduction history

**Purpose.** Store a log of every reduction. Knows nothing about parsing: it only stores strings.

**Structure.** `ReductionRecord {seq, prod_no, production, stack_before, stack_after, remaining_input, action, emitted}` (strings are `malloc`'d copies); `ReductionHistory {recs, count, cap}` (a growable array, doubling from 16).

**Functions.** `reduction_init/_free`; `reduction_add` (append a record; `emitted` starts as `""`); `reduction_set_emitted` (attach the TAC text to the **most recent** record); `reduction_print` (section 7 body + the production-number sequence); `reduction_print_emitters` (the "which reduction emitted which TAC" list in section 9).

**Depends on:** `reduction.h`. **Called by:** `compiler.c` (writes), `main.c` (prints, frees), `test_opt.c`.

---

### 1.8 `ir.c` (≈170 lines) — three-address code (TAC) and operand arithmetic

**Purpose.** Define the intermediate representation and the **only arithmetic routine** (`ir_apply`) used by the interpreter, the optimizer's folding and the target machine — which is why all three agree.

**Structures** (in `ir.h`): `Operand {k (K_NONE/CONST/TEMP/VAR), d (T_INT/T_FLOAT), i, f, t}`; `TAC {op, form (F_ASSIGN/UNARY/BINARY), a, b, res, type}`; `IR {code[], n, cap, ntemp}`. Every instruction defines a **fresh temporary** (`res = ++ntemp`), so each temp is assigned exactly once.

**Functions.** Construction: `ir_init/_free/_copy/_delete`, `ir_int` (wraps to 32-bit), `ir_float`; emit: `ir_binary`, `ir_unary` (both insert an `OP_ITOF` or convert a constant when the result type is float — private `conv`; unary plus returns its operand and emits nothing), `ir_finish` (if the final value is not already the last temp, emit `tN = value`), `ir_result`; arithmetic: `ir_apply(op, type, a, b, &out)` (int: 32-bit wraparound, `INT_MIN / -1` handled, **returns 0 for division by zero**; float: IEEE double), `ir_eval` (interpreter: run the TAC top to bottom); printing: `ir_fmt`, `ir_fmt_double`, `ir_fmt_tac` (one instruction as text — added in this revision), `ir_print`. A small variable table (`ir_var`, `ir_bind`, `ir_var_name`, `ir_var_get`) exists for future identifiers; **the current grammar has no identifiers, so `K_VAR` operands never occur.**

**Depends on:** `ir.h`. **Called by:** `compiler.c`, `optimizer.c`, `codegen.c`, `main.c`, `test_opt.c`.

---

### 1.9 `optimizer.c` (≈190 lines) — optimization passes (supporting phase)

**Purpose.** Four passes over the TAC, repeated to a fixed point, each now able to **log every individual change**. Full detail: `Optimization_Walkthrough.md`.

**Structures** (in `optimizer.h`): `OptStats` (counts, rounds, instruction counts, `fixed`), `OptChange {line, before, after, rule, why}`, `OptLog` (growable array of changes).

**Functions.** `opt_fold`, `opt_propagate` (constant **and copy** propagation), `opt_simplify` (algebraic identities), `opt_dead` (backward liveness scan), each `int pass(IR*, OptLog*)` returning the number of transformations (`log` may be `NULL`); `opt_run(ir, verbose)` (round loop, max 10; with `verbose` it prints each pass's before / changes / after); `opt_print`; `opt_log_free`; private `report`, `show`, `log_add`, `to_assign`, `isc`, `same`.

**Depends on:** `optimizer.h` (→ `ir.h`). **Called by:** `main.c`, `test_opt.c`.

---

### 1.10 `codegen.c` (≈150 lines) — target code generator (supporting phase)

**Purpose.** Translate TAC into code for a simulated 4-register machine and simulate it.

**Structures** (in `codegen.h`): `MOp` (opcodes `LOADI, FLOADI, LOAD, STORE, MOV, ADD…XOR, NOT, NEG, FADD…FNEG, ITOF, HALT`), `MInstr {op, rd, rs1, rs2, mem, imm}`, `Target {code[], n, cap, ntemp, rtype}`. `NREG = 4`. File-level statics: `T` (current target), `occ[NREG]` (what each register holds: 0 free, −1 constant/variable, >0 temp id), `last[]` (last-use index of each temp), `cur`.

**Functions.** `cg_generate` (compute `last[]` by scanning the TAC, then `gen` per instruction, then `HALT`); `gen`/`operand`/`getreg`/`rel`/`find`/`put`/`pick` (register allocation: reuse a free register, else **spill** the register whose temp is used furthest in the future with `STORE [Tn]`, reload with `LOAD`); `cg_print`; `cg_run` (simulator — arithmetic through `ir_apply`); `cg_free`. The final instruction stores the result to `[RESULT]`.

**Input is the optimized TAC** (unless `--no-opt`). Because the optimizer folds every expression to one constant, normal output is just `LOADI / STORE / HALT`; use `--no-opt` to see real register allocation and spilling.

**Depends on:** `codegen.h` (→ `ir.h`). **Called by:** `main.c`, `test_opt.c`. **Note:** uses file-level mutable statics, so it is not re-entrant.

---

### 1.11 `test_slr.c` (≈445 lines) — table-generator tests

Standalone program (own `main`). 97 checks: closure/goto/dedup, FIRST/FOLLOW (including an ε-grammar), ACTION/GOTO contents, determinism, a minimal LR driver parsing sample inputs, and four conflict grammars (ambiguous, reduce/reduce, LR(1)-but-not-SLR(1), double-reduce). `./test_slr -v` dumps everything. Links with `grammar.o lr_items.o syntax_table.o` only — proof the table generator does not depend on the rest of the compiler.

### 1.12 `test_opt.c` (≈200 lines) — optimizer tests (added in this revision)

Standalone program. Unit tests for each pass in isolation (including log contents, hand-built TAC for `x-x`, `x&x`, copy propagation, dead code, and negative cases such as float `x*0`), a regression test for the bitwise/float bug, then a **fixed-seed randomized check**: 3000 integer-only and 3000 int+float random expressions are parsed, optimized and compiled; original-TAC value, optimized-TAC value, target-machine value (from optimized TAC) and target-machine value (from unoptimized TAC, which exercises spilling) must all agree in value **and type**.

---

## 2. Header files (`.h`)

All nine headers use include guards (`#ifndef X_H / #define X_H / … / #endif`) so a header included twice (directly and through another header) is processed once. Without them, a type such as `Grammar` would be defined twice ⇒ "redefinition of struct" errors. Headers contain **declarations and type definitions only**; no function bodies and no variable definitions (that is why there are no multiple-definition link errors).

| Header | Why it exists | Important contents | Included by |
| --- | --- | --- | --- |
| `lexer.h` | Interface between scanner and everything that consumes tokens. | `MAX_LEXEME`; `TokenType` (13 terminals + `TOK_INVALID`, `TOK_TERMINAL_COUNT` used to size arrays); `Token {type, int_value, float_value, lexeme, offset, line, column}`; `Lexer`; `lexer_*`, `token_*` prototypes. | `lexer.c`, `compiler.h` |
| `grammar.h` | **Interface contract** for the grammar data (the long header comment documents the conventions: symbol 0 = `$`, production 0 = augmented). | `MAX_SYMBOLS/PRODUCTIONS/RHS/NAME`, `SYM_END`; `Symbol`, `Production`, `Grammar`; `grammar_*` prototypes. | `grammar.c`, `lr_items.h`, `syntax_table.h`, `compiler.h`, `test_slr.c` |
| `lr_items.h` | LR(0) data types and algorithm summary. | `LRItem`, `ItemSet`, `LRState`, `LRCollection`; item/set/collection/print prototypes. | `lr_items.c`, `syntax_table.h`, `test_slr.c` |
| `syntax_table.h` | Public interface of the table generator — **the contract between Mahendra's module and Arnav's parser.** | `SymSet` + `SYMSET_BIT/HAS`; `FirstFollow`; `ActionType`, `Action`; `ConflictType`, `Conflict`; `SLRTable`; generation, query, conflict and print prototypes. Contains a compile-time check that `MAX_SYMBOLS <= 64`. | `syntax_table.c`, `compiler.h`, `test_slr.c` |
| `reduction.h` | Interface for the history store. | `ReductionRecord`, `ReductionHistory`, `reduction_*` prototypes. | `reduction.c`, `compiler.h` |
| `ir.h` | **The language the phases speak after parsing.** | `DType`, `Op`, `OKind`, `Form`; `Operand`, `TAC`, `IR`; all `ir_*` prototypes. | `ir.c`, `compiler.h`, `optimizer.h`, `codegen.h` |
| `optimizer.h` | Optimizer interface. | `OptStats`, `OptChange`, `OptLog`; the four pass prototypes; `opt_run`, `opt_print`, `opt_log_free`. | `optimizer.c`, `main.c`, `test_opt.c` |
| `codegen.h` | Target-code interface. | `NREG`, `MOp`, `MInstr`, `Target`; `cg_*` prototypes. | `codegen.c`, `main.c`, `test_opt.c` |
| `compiler.h` | The parser's public face; also a convenient "include everything the front end needs". | `ParseSummary`; `compiler_parse`, `compiler_token_terminal`, `compiler_print_tokens`, `compiler_print_derivation`. | `compiler.c`, `main.c`, `test_opt.c` |

**Effect of changing a header.** Adding a field to `TAC` or `Operand` (in `ir.h`) changes the size of every instruction: *every* file that includes it (directly or transitively: compiler, optimizer, codegen, main, tests) must be recompiled — the Makefile's `%.o: %.c` rule does **not** track header dependencies, so after editing a header run `make clean && make`. Changing the order of `TokenType` enumerators breaks the index-based arrays `NAMES[]`, `SYMBOLS[]` (lexer.c) and `lexer_symbol_names[]` (compiler.c).

**Shared structures = inter-module protocol.**

| Structure | Producer → consumer |
| --- | --- |
| `Token[]` | `lexer.c` → `compiler.c` |
| `Grammar` | `grammar.c` → `lr_items.c`, `syntax_table.c`, `compiler.c` |
| `LRCollection` (inside `SLRTable`) | `lr_items.c` → `syntax_table.c` |
| `SLRTable` (ACTION/GOTO) | `syntax_table.c` → `compiler.c` (read-only queries) |
| `ReductionHistory` | `compiler.c` writes → `main.c` prints |
| `Operand` (semantic values) | `ir.c` constructors → parse stack → `ir_binary/unary` |
| `IR` (TAC array) | `compiler.c`/`ir.c` → `optimizer.c` → `codegen.c` |
| `OptLog` | `optimizer.c` passes → `optimizer.c` `report` |
| `Target` | `codegen.c` → `cg_run`, `cg_print` |

---

## 3. Dependency map

### 3.1 Include relationships (from the actual `#include "…"` lines)

| File | Includes (project headers) |
| --- | --- |
| `main.c` | `compiler.h`, `optimizer.h`, `codegen.h` |
| `compiler.c` | `compiler.h`, `reduction.h` |
| `compiler.h` | `grammar.h`, `syntax_table.h`, `lexer.h`, `ir.h`, `reduction.h` |
| `lexer.c` | `lexer.h` |
| `grammar.c` | `grammar.h` |
| `lr_items.c` / `lr_items.h` | `lr_items.h` / `grammar.h` |
| `syntax_table.c` / `syntax_table.h` | `syntax_table.h` / `grammar.h`, `lr_items.h` |
| `reduction.c` | `reduction.h` |
| `ir.c` | `ir.h` |
| `optimizer.c` / `optimizer.h` | `optimizer.h` / `ir.h` |
| `codegen.c` / `codegen.h` | `codegen.h` / `ir.h` |
| `test_slr.c` | `grammar.h`, `lr_items.h`, `syntax_table.h` |
| `test_opt.c` | `compiler.h`, `optimizer.h`, `codegen.h` |

(`grammar.h`, `lexer.h`, `ir.h`, `reduction.h` include no project headers — they are the leaves.)

### 3.2 Cross-module calls (extracted from the code)

| Caller | Calls into | Functions |
| --- | --- | --- |
| `main.c` | lexer | `lexer_tokenize` |
| | grammar | `grammar_load_compiler`, `grammar_init`, `grammar_add_terminal`, `grammar_add_rule` (conflict demo) |
| | syntax_table | `slr_generate`, `slr_is_slr1`, `slr_free`, `slr_get_action`, `slr_get_goto`, `slr_conflict_count`, `slr_get_conflict`, `slr_print_*` |
| | compiler | `compiler_parse`, `compiler_print_tokens`, `compiler_print_derivation` |
| | reduction | `reduction_init`, `reduction_free`, `reduction_print`, `reduction_print_emitters` |
| | ir | `ir_init`, `ir_finish`, `ir_copy`, `ir_eval`, `ir_print`, `ir_free` |
| | optimizer / codegen | `opt_run`, `opt_print` / `cg_generate`, `cg_print`, `cg_run`, `cg_free` |
| `compiler.c` | lexer | `token_format`, `token_name`, `token_symbol` |
| | grammar | `grammar_find_symbol` |
| | syntax_table | `slr_get_action`, `slr_get_goto` |
| | reduction | `reduction_add`, `reduction_set_emitted` |
| | ir | `ir_int`, `ir_float`, `ir_binary`, `ir_unary`, `ir_promote`, `ir_fmt_tac` |
| `syntax_table.c` | grammar | `grammar_augment`, `grammar_print`, `grammar_print_production` |
| | lr_items | `lr_collection_init/_build/_free`, `item_is_complete`, `item_next_symbol`, `lr_print_collection`, `lr_print_transitions` |
| `optimizer.c` | ir | `ir_apply`, `ir_copy`, `ir_delete`, `ir_fmt`, `ir_fmt_tac`, `ir_free`, `ir_int`, `ir_print` |
| `codegen.c` | ir | `ir_apply`, `ir_fmt_double`, `ir_var_get`, `ir_var_name` |
| `lexer.c`, `grammar.c`, `lr_items.c`, `reduction.c`, `ir.c` | — | leaf modules (call only each other's own functions / the C library) |

### 3.3 Simplified diagram

```
                     ┌─────────┐
                     │ main.c  │  (drives everything, prints 11 sections)
                     └────┬────┘
        ┌─────────────┬───┴─────────┬───────────────┬──────────────┐
        ▼             ▼             ▼               ▼              ▼
   ┌─────────┐  ┌────────────┐ ┌──────────┐   ┌───────────┐  ┌──────────┐
   │ lexer.c │  │ grammar.c  │ │compiler.c│   │optimizer.c│  │codegen.c │
   └────┬────┘  └─────┬──────┘ └─┬──┬──┬──┘   └─────┬─────┘  └────┬─────┘
        │ Token[]     │ Grammar  │  │  │            │ IR           │ IR
        └─────────────┼──────────┘  │  │            │              │
                      ▼             │  │            └──────┬───────┘
              ┌──────────────┐      │  │                   ▼
              │ lr_items.c   │      │  │               ┌───────┐
              └──────┬───────┘      │  └──────────────►│ ir.c  │  Operand / TAC / IR, ir_apply
                     ▼              │                  └───────┘
              ┌──────────────┐ ACTION/GOTO queries
              │syntax_table.c│◄─────┘
              └──────────────┘          compiler.c ──► reduction.c  (history)
```

### 3.4 Data flow between phases

```
string ─lexer_tokenize→ Token[] ─compiler_parse(+table)→ semantic values (Operand) ─ir_binary/ir_unary→ IR
IR ─ir_finish→ IR ─ir_copy→ IR' ─opt_run→ IR' (optimized) ─cg_generate→ Target ─cg_run→ Operand
                                                       (also: ir_eval(IR) and ir_eval(IR') are used only to cross-check)
Grammar ─slr_generate→ SLRTable {FIRST/FOLLOW, LRCollection, ACTION, GOTO, conflicts}   (once per run)
```

---

## 4. Build files

* `Makefile` — object files for `mini_compiler` (`main.o compiler.o lexer.o grammar.o lr_items.o syntax_table.o reduction.o ir.o optimizer.o codegen.o`), separate `test_slr` and `test_opt` programs, `make test` runs both test programs, the demo (`--quiet --demo`) and the conflict demo. Flags: `-std=c99 -Wall -Wextra -pedantic -O2`, libraries `-lm`.
* `build.bat` — Windows one-shot `gcc` command for `mini_compiler.exe` (no separate objects), then runs the quiet demo.
* `README.md`, `AUDIT_REPORT.md` — documentation.
