# Study Guide — Sarvesh S V
## Intermediate Code Generation, Optimization & Target Code Generation

Real program output is used wherever possible; **(illustrative)** marks teaching examples. The full optimizer description is in `Optimization_Walkthrough.md`; this guide gives you what you need to explain it (and the other two phases) in a viva.

---

## A. Assigned files

| File | Responsibility | Know these |
| --- | --- | --- |
| `ir.h` / `ir.c` | **Entire pair**: the TAC representation, operand arithmetic, TAC construction and printing. | `Operand`, `TAC`, `IR`, `DType`, `Op`, `OKind`, `Form`; `ir_binary`, `ir_unary`, `conv`, `emit`, `ir_finish`, `ir_apply`, `ir_eval`, `ir_copy`, `ir_delete`, `ir_fmt`, `ir_fmt_tac`, `ir_print`. |
| `optimizer.h` / `optimizer.c` | **Entire pair**: four passes, driver, change log. | `opt_fold`, `opt_propagate`, `opt_simplify`, `opt_dead`, `opt_run`, `OptStats`, `OptChange`, `OptLog`. |
| `codegen.h` / `codegen.c` | **Entire pair**: register-machine code generator + simulator. | `cg_generate`, `gen`, `operand`, `getreg`, `rel`, `pick`, `cg_run`, `MInstr`, `Target`, `MOp`, statics `occ[]`, `last[]`. |
| `test_opt.c` | Your test suite (36 checks incl. 6000 random expressions). | `unit_tests`, `fuzz`. |
| `main.c` (part) | Sections 9–11 in `run_one`, the final `Check:` line, `--opt-brief`, `--no-opt`. | – |

**Overlap.** The semantic actions in `compiler.c` (Arnav) *call* your `ir_binary` / `ir_unary`. Arnav decides **when** and with **which values**; you decide **what instruction is built** (including the int→float conversion). Both of you should be able to explain the sentence "a reduction of `Term → Term STAR Unary` emits `tN = a * b`".

---

## B. Code walkthrough

### B.1 The intermediate representation (`ir.h`)

```c
typedef enum { K_NONE, K_CONST, K_TEMP, K_VAR } OKind;
typedef struct { OKind k; DType d; long long i; double f; int t; } Operand;       // a constant (i or f), a temp (t), or a variable (t)
typedef struct { Op op; Form form; Operand a, b; int res; DType type; } TAC;     // res = id of the temp this instruction defines
typedef struct { TAC *code; int n, cap, ntemp; } IR;                              // growable array + temp counter
```
* `form`: `F_BINARY` (`t = a op b`), `F_UNARY` (`t = op a`, includes `OP_NEG`, `OP_NOT`, `OP_ITOF`), `F_ASSIGN` (`t = a`).
* **Every instruction defines a brand-new temporary** (`res = ++ir->ntemp` in `emit`). So **each temp is assigned exactly once** — which is what makes propagation and dead-code analysis simple and safe.
* `K_VAR` (named variables) exists in the IR but the current grammar cannot produce one.

`emit` appends one instruction (doubling the array when full) and returns the temp operand. `ir_binary(ir, op, l, r, type)` first calls `conv` on both operands: if the result type is float and an operand is int, a constant is converted at once (`ir_float((double)o.i)`) while a non-constant gets an explicit `OP_ITOF` instruction. `ir_unary` for `OP_POS` returns its operand and emits nothing. `ir_finish(ir, top)` emits `tN = top` only if `top` is not already the last instruction's result.

Real TAC for `3 + 5 * 2` (and which reduction produced each instruction):
```
TAC emitted by semantic actions attached to reductions:
  reduction #10  Term -> Term STAR Unary    -> t1 = 5 * 2
  reduction #11  Sum -> Sum PLUS Term       -> t2 = 3 + t1

--- Generated TAC ---
  t1 = 5 * 2                     [int]
  t2 = 3 + t1                    [int]
```
Float conversion example:
```
TAC emitted by semantic actions attached to reductions:
  reduction #8   Sum -> Sum PLUS Term       -> t1 = 1 + 2
  reduction #17  Term -> Term STAR Unary    -> t2 = (float) t1 ; t3 = t2 * 2.5

--- Generated TAC ---
  t1 = 1 + 2                     [int]
  t2 = (float) t1                [float]
  t3 = t2 * 2.5                  [float]
```
`t2 = (float) t1` was inserted by `conv` because `t1` is an int temp used in a float multiplication.

### B.2 `ir_apply` — the one arithmetic routine

All evaluation goes through `ir_apply(op, type, a, b, &out)`:
* **int**: operands are converted to `uint32_t`, so `+ - *` wrap around like 32-bit hardware (`2147483647 + 1 = -2147483648`); `INT_MIN / -1` is special-cased; **division by zero returns 0 (= "cannot evaluate")**; `& | ^ ~ -` act on bits. Float operands in an int-typed operation are truncated (`iv()`).
* **float**: IEEE double arithmetic; division by 0.0 returns 0 ("cannot evaluate").

It is used by (1) `ir_eval` (the TAC interpreter), (2) `opt_fold` (compile-time evaluation), (3) `cg_run` (the machine simulator). **One routine ⇒ the three agree by construction** — the `Check:` line in section 11 compares them.

### B.3 The optimizer (`optimizer.c`)

Driver `opt_run(ir, verbose)`: repeat up to `MAXIT = 10` rounds; in each round run, **in this order**, `opt_fold` → `opt_propagate` → `opt_simplify` → `opt_dead`; stop after a round in which no pass changed anything (a *fixed point*). Each pass returns how many transformations it made; with `verbose` the driver copies the IR before each pass (`ir_copy`), passes a fresh `OptLog` to the pass, and prints before / each change / after.

| Pass | Rule (what the code does) |
| --- | --- |
| `opt_fold` | For every non-assign instruction whose operands are all constants, call `ir_apply`; on success rewrite as `t = <result>` (`to_assign`). Division by zero is not folded. |
| `opt_propagate` | Walk top-down with `v[temp]` = the known value of a temp that was assigned a constant or a copy (`t = const` / `t = tK`); replace each later **use** of that temp by its value. (So it performs *constant propagation and copy propagation* — one pass, two kinds.) |
| `opt_simplify` | Algebraic identities on binary instructions: `x+0, 0+x, x-0, x-x (int), x*1, 1*x, x*0 (int), x/1, x&0, x&-1, x&x, x\|-1, x\|0, x\|x, x^0, x^x`. Float-unsafe ones (`x+0`, `x*0`, `x-x`) are skipped for floats, and bitwise identities that return an operand require that operand to be `int`. |
| `opt_dead` | Backward scan with `live[temp]`: the last instruction's result is live; an instruction whose result is not live is deleted (`ir_delete`); otherwise its operand temps become live. |

Why this order? Folding creates constants; propagation spreads them to later uses; simplification and folding can then fire; dead-code removal deletes the assignments that propagation made unnecessary. Repeating rounds lets effects cascade (e.g. after propagation + dead removal, a new instruction has two constant operands and folds in the next round).

**Not implemented:** code motion, strength reduction, common-subexpression elimination, peephole optimization, loop optimizations. (The language has no variables, loops or branches, so code motion has nothing to move.)

Real run for `3 + 5 * 2` — the end of the pipeline output (full text in `Optimization_Walkthrough.md`):
```
--- Optimized TAC (this is what the target-code generator receives) ---
  t2 = 13                        [int]
  [folded=2 propagated=1 simplified=0 removed=1 | 2 -> 1 instructions | 3 rounds, the last one changed nothing]
```
and for `(2 + 3) * 1 + 0`, which exercises all four passes:
```
--- Optimized TAC (this is what the target-code generator receives) ---
  t3 = 5                         [int]
  [folded=1 propagated=2 simplified=2 removed=2 | 3 -> 1 instructions | 3 rounds, the last one changed nothing]
```

**Why does everything fold to one instruction?** Because the language only has constants, `opt_fold` + `opt_propagate` + `opt_dead` evaluate the whole expression at compile time. That is a property of the language, not a bug.

### B.4 The code generator (`codegen.c`)

Target: a simulated machine with **4 registers** (`R0–R3`) and memory slots `[T1]…` for spilled temps plus `[RESULT]`.

Instruction format: `MInstr { MOp op; int rd, rs1, rs2, mem; Operand imm; }`. Opcodes: `LOADI/FLOADI` (load immediate int/float), `LOAD/STORE` (memory ↔ register), `MOV`, `ADD SUB MUL DIV AND OR XOR NOT NEG`, `FADD FSUB FMUL FDIV FNEG`, `ITOF`, `HALT`.

`cg_generate(ir, &target)`:
1. Scan the TAC once to fill `last[t]` = index of the **last instruction that uses temp t**.
2. For each instruction `gen(ir, i)`: `operand()` finds each source in a register (`find(t)`), or allocates a register and loads it (`LOADI #c`, or `LOAD [Tn]` if it was spilled earlier). `rel()` frees registers whose value is dead after this instruction (`last[t] <= i`, or a constant). The destination reuses a freed source register if possible, otherwise `getreg`.
3. `getreg(lock)`: a free register if any; otherwise **spill**: choose an unlocked register whose temp has the greatest `last[]` (used furthest in the future), emit `STORE [Tn], R`, mark it free.
4. The last instruction's value is stored to `[RESULT]`; finally `HALT`.

`occ[r]` records what register `r` holds: `0` free, `-1` a constant/variable, `>0` the id of a temp.

**Input is the optimized TAC.** In normal runs it is a single assignment, so the real output is:
```

--- Target Code ---
   0: LOADI   R0, #13
   1: STORE   [RESULT], R0
   2: HALT    

Check: original TAC = 13 | optimized TAC = 13 | target machine = 13 -> PASS
```
To see allocation work, bypass the optimizer: `--no-opt`.
```
TAC emitted by semantic actions attached to reductions:
  reduction #8   Sum -> Sum PLUS Term       -> t1 = 1 + 2
  reduction #22  Sum -> Sum PLUS Term       -> t2 = 3 + 4
  reduction #28  Term -> Term STAR Unary    -> t3 = t1 * t2

--- Generated TAC ---
  t1 = 1 + 2                     [int]
  t2 = 3 + 4                     [int]
  t3 = t1 * t2                   [int]

--- Target Code ---
   0: LOADI   R0, #1
   1: LOADI   R1, #2
   2: ADD     R0, R0, R1
   3: LOADI   R1, #3
   4: LOADI   R2, #4
   5: ADD     R1, R1, R2
   6: MUL     R0, R0, R1
   7: STORE   [RESULT], R0
   8: HALT    

Check: original TAC = 21 | TAC (not optimized) = 21 | target machine = 21 -> PASS
```
With more live temps than registers, spilling appears (`STORE [T1], R0` … later `LOAD R0, [T3]`), real output for `(1+2)*((3+4)*((5+6)*((7+8)*((9+1)*(2+3)))))`:
```

--- Target Code ---
   0: LOADI   R0, #1
   1: LOADI   R1, #2
   2: ADD     R0, R0, R1
   3: LOADI   R1, #3
   4: LOADI   R2, #4
   5: ADD     R1, R1, R2
   6: LOADI   R2, #5
   7: LOADI   R3, #6
   8: ADD     R2, R2, R3
   9: LOADI   R3, #7
  10: STORE   [T1], R0
  11: LOADI   R0, #8
  12: ADD     R3, R3, R0
  13: LOADI   R0, #9
  14: STORE   [T2], R1
  15: LOADI   R1, #1
  16: ADD     R0, R0, R1
  17: LOADI   R1, #2
  18: STORE   [T3], R2
  19: LOADI   R2, #3
  20: ADD     R1, R1, R2
  21: MUL     R0, R0, R1
  22: MUL     R3, R3, R0
  23: LOAD    R0, [T3]
  24: MUL     R0, R0, R3
  25: LOAD    R1, [T2]
  26: MUL     R1, R1, R0
  27: LOAD    R0, [T1]
  28: MUL     R0, R0, R1
  29: STORE   [RESULT], R0
  30: HALT    

Check: original TAC = 173250 | TAC (not optimized) = 173250 | target machine = 173250 -> PASS
```
`cg_run` executes the machine code (`ir_apply` for arithmetic) and returns `[RESULT]`; `main` compares it with `ir_eval` of the original and optimized TAC.

---

## C. Concepts you must understand

* **Intermediate representation** and why compilers use one (machine independence, easier optimization).
* **Three-address code**: at most one operator and three addresses per instruction; **temporaries**; quadruple-style storage (`op, a, b, res`) here.
* **Syntax-directed generation**: TAC emitted in reduction order = evaluation order (operands before operators).
* **Type conversion** (`OP_ITOF`) in IR.
* **Constant folding, constant & copy propagation, algebraic simplification, dead-code elimination**; **fixed point**; why pass order matters; **semantic equivalence** (an optimization must not change the result).
* **Why float identities are dangerous** (`x*0` with NaN/∞, `-0.0 + 0.0`).
* **Basic block**: the whole TAC is one straight-line block (no branches), so liveness is a single backward scan.
* **Target code generation**: instruction selection (`pick`), **register allocation**, **spilling**, memory slots, simulation.
* **Dependence on earlier phases**: wrong parse or wrong semantic action ⇒ wrong TAC ⇒ every later phase faithfully computes the wrong thing.

---

## D. Important functions and data structures

| Item | What / why | In → out | Used by | If wrong or removed |
| --- | --- | --- | --- | --- |
| `Operand` | One value: constant/temp/var + type. | – | everywhere | Wrong type tag ⇒ wrong arithmetic (int vs float). |
| `TAC` / `IR` | One instruction / the instruction list + temp counter. | – | parser, optimizer, codegen | – |
| `emit` | Append an instruction; allocate a fresh temp. | op, form, a, b, type → temp operand | `ir_binary`, `ir_unary`, `ir_finish` | Temp reuse would break the single-assignment assumption used by propagation and dead-code analysis. |
| `conv` | int→float conversion. | operand, type → operand | `ir_binary/unary` | Missing ⇒ float ops on int-tagged temps. |
| `ir_apply` | Arithmetic semantics. | op, type, a, b → out, success flag | `ir_eval`, `opt_fold`, `cg_run` | Differences between evaluators would show as `Check: FAIL`. |
| `ir_eval` | Interpreter: run TAC top to bottom. | IR → Operand | `main`, tests | Used only as a cross-check. |
| `ir_copy`, `ir_delete` | Snapshot / remove an instruction. | – | optimizer driver, `opt_dead` | – |
| `ir_fmt_tac` | One instruction as text. | TAC → string | printing, optimizer log, emitters list | Display and the log text. |
| `OptLog`/`OptChange` | What each pass did: line, before, after, rule, why. | – | `opt_*`, `report` | Without it the output would only show counts. |
| `opt_run` | Pass pipeline to a fixed point. | IR (in place) → `OptStats` | `main`, tests | Without the loop, cascading opportunities are missed. |
| `Target`/`MInstr` | Generated machine code. | – | `cg_*` | – |
| `getreg` + `last[]` | Spill choice. | lock mask → register | `gen`, `operand` | Wrong spill ⇒ overwritten live value ⇒ wrong result (detected by tests). |

---

## E. Viva preparation

**Fundamentals**

1. *What is TAC?* An IR whose instructions have at most one operator: `t2 = 3 + t1`. Easy to optimize and translate.
2. *Why temporaries?* Each operator result needs a name so later instructions can use it; the parser creates a new one per operator (`t1, t2, …`).
3. *Why TAC rather than going straight to machine code?* Machine independence and simpler optimization; the optimizer works on TAC regardless of the target.
4. *How is TAC different from target code?* TAC has unlimited temporaries and typed operands; target code has 4 registers, explicit loads/stores and a specific instruction set.

**Implementation**

5. *How does a reduction produce TAC?* The semantic action for `Term → Term STAR Unary` calls `ir_binary(OP_MUL, rhs[0], rhs[2], …)`; `emit` appends `tN = a * b` and returns temp `tN`, which becomes the value of the new `Term`.
6. *In what order are instructions emitted?* In **reduction order**, which for an LR parser is operand-before-operator evaluation order.
7. *Why does `1 + 2.5` have no `ITOF` but `(1+2) * 2.5` has one?* A constant is converted at compile time inside `conv`; a temp needs a run-time `ITOF` instruction.
8. *Which optimizations does your project actually implement?* Folding, constant+copy propagation, algebraic simplification, dead-temporary elimination. Not: code motion, strength reduction, CSE, peephole.
9. *Why is code motion not implemented?* There are no loops or branches — the whole program is one straight-line block, so there is nothing to hoist.
10. *What does a pass do when nothing applies?* Returns 0; the driver prints "no transformations (…)". Round with zero changes ⇒ fixed point ⇒ stop.
11. *Why does pass order matter?* Example: if dead-code ran first, nothing would be removed (every temp still used); propagation must run first to make `t1` unused. Another: `5 * 1` shows up as **simplification** (not folding) in `(2+3)*1+0` because propagation produced it after folding already ran in that round.
12. *Why is dead-code elimination safe here?* Every instruction is pure (no store, call, I/O). Only caveat: removing a dead division by zero removes a would-be trap (`(8/0)*0` becomes `0`).
13. *How do you know `x * 0 → 0` is valid?* For **int** it is always true; for **float** it is not (NaN, ∞, −0.0), so the code guards `!fl`. Similarly `x + 0` is skipped for floats.
14. *What bug did testing find in the simplifier?* `0 ^ 0.5` was rewritten to `t = 0.5` but the instruction was typed `int`, so the target machine returned `0.5` instead of `0`. Fix: identities that return an operand require it to be `int` (`a.d == T_INT`). Regression test: `0 | 2.5` must give int `2` on the target.
15. *Why is `ir_apply` shared?* So folding at compile time is exactly the arithmetic the machine performs at run time.
16. *How does register spilling choose a victim?* The unlocked register whose temp has the largest `last[]` (used furthest in the future).
17. *What does the final instruction do?* `STORE [RESULT], Rd` then `HALT`.
18. *What does the optimizer return to `main`, and who consumes it?* The IR is modified in place; `main` passes that `optimized` IR to `cg_generate`; `--no-opt` passes the original copy instead.

**Design alternatives**

19. *How would you add common-subexpression elimination?* Within the block keep a table of `(op, a, b) → temp`; when an identical instruction appears, replace it by an assign from the earlier temp. Needs commutativity handling. (Not implemented.)
20. *How would you add strength reduction (`x * 2 → x + x`)?* A new rule in `opt_simplify` for `OP_MUL` with constant 2 (int only).
21. *How would you support variables?* Grammar: `IDENT` token; semantic value `ir_var`; `K_VAR` operands already supported by `ir_fmt`, `ir_eval` (`VT[]`), codegen (`LOAD [name]`). Then optimization would no longer collapse everything.

**Edge cases / limits**

22. Division by zero: not folded; the interpreter returns 0, the machine leaves the register unchanged ⇒ the `Check:` line reports FAIL (documented limitation).
23. Integer overflow wraps (32-bit), also in folding.
24. Max 10 optimization rounds (not reached by any expression tested).
25. `codegen.c` uses file-level statics (`T`, `occ`, `last`): not re-entrant.

**Interaction**

26. *What do you need from the parser to be correct?* `tN` ids unique and instructions in evaluation order; correct types (`ir_promote`).
27. *If the parser's semantic action for `-` emitted `OP_ADD`?* TAC, optimization and code would all be consistent with each other and all wrong; only comparing with the expected value reveals it. (This is why the test suite checks concrete expected values for `3 + 5 * 2` etc.)

**Understanding vs memorizing**

28. *Predict the optimization of `(2 + 3) * 1 + 0`.* Round 1: fold `t1=5`; propagate `t2 = 5 * 1`; simplify `t2 = 5` and `t3 = t2`; dead removes `t1`. Round 2: propagate `t3 = 5`; dead removes `t2`. Round 3: nothing. Final `t3 = 5`. (This is the real output above.)
29. *Why doesn't `x - x` appear from the parser?* The grammar evaluates each sub-expression once, so a temp is never used twice; the tests build such TAC by hand to test the rule.

---

## F. Beyond your section

| Level | Topics |
| --- | --- |
| **Know thoroughly** | TAC, temporaries, the four passes and their order, `ir_apply`, codegen allocation/spilling, how your phases verify each other. |
| **Understand at high level** | the grammar and production numbers (Aditya); LR table construction (Mahendra); the parse stack and the exact moment semantic actions run (Arnav). |
| **Be familiar with** | `semantic switch` in `compiler.c`; `main.c` `run_one` sections 9–11. |
| **Interfaces** | Arnav → you: calls to `ir_binary/ir_unary/ir_finish` with `Operand` values. You → `main`: `IR`, `OptStats`, `Target`, final value for the `Check:` line. |

Run: `./mini_compiler "(2 + 3) * 1 + 0"`, `./mini_compiler --no-opt "(1 + 2) * (3 + 4)"`, `./test_opt`.
