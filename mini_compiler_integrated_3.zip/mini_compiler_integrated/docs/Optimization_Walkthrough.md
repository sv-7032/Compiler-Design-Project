# Optimization Walkthrough

The optimizer is a **supporting phase**. This document explains exactly what it does, shows the transformations the program prints, and states what is *not* implemented. Source: `optimizer.h`, `optimizer.c` (driver output in `main.c`, section 10).

**Provenance of examples.** Every block labelled *"real output"* was produced by running `./mini_compiler` while this document was generated. Items labelled *"unit-test constructed"* are TAC built by hand in `test_opt.c` (because the expression grammar cannot produce them); the expected result is asserted by the test. Items labelled *(illustrative)* are explanations only.

---

## 1. Audit of the optimizer (done before changing anything)

| Technique | Implemented? | Where | Notes from the audit |
| --- | --- | --- | --- |
| Constant folding | **Yes** | `opt_fold` | Folds binary *and* unary instructions (`-5`, `~3`, `(float) 3`) via `ir_apply`. Does not fold division by zero. |
| Constant propagation | **Yes** | `opt_propagate` | Misnamed by omission: the same pass also does **copy propagation** (`t3 = t1` then uses of `t3` → `t1`). Now reported separately as "constant propagation" / "copy propagation" in the rule text; one counter. |
| Algebraic simplification | **Yes** | `opt_simplify` | 19 identity rules (table in §5). One **bug found and fixed** (§9). |
| Dead code elimination | **Yes** (dead *temporary* elimination) | `opt_dead` | Backward liveness; only removes instructions whose result temp is unused. All instructions are side-effect free in this IR. |
| Code motion | **No** | – | There are no loops or branches; the whole program is one straight-line block. Nothing was added to pretend otherwise. |
| Strength reduction | **No** | – | `x*2 → x+x` etc. do not exist. (`x*1`, `x/1` etc. are *identities*, listed under simplification, not strength reduction.) |
| Common-subexpression elimination | **No** | – | The grammar never repeats a sub-expression with a shared temp. |
| Peephole optimization | **No** | – | – |
| Copy propagation (stand-alone) | **Partly** | inside `opt_propagate` | See above. |

**Which passes run in normal execution?** All four, in the fixed order *fold → propagate → simplify → dead*, repeated until a whole round changes nothing (limit `MAXIT = 10`). `--no-opt` skips the optimizer; `--opt-brief` runs it but prints only the final TAC and summary.

**What IR do they use?** The TAC array (`IR`, `TAC`, `Operand` from `ir.h`). Passes modify it in place: `to_assign()` rewrites an instruction as `t = value`; `opt_dead` removes entries with `ir_delete`.

**Were the old counts accurate?** Yes — each counter was incremented exactly where a rewrite/removal happened (`folded`, `propagated` = operand replacements, `simplified`, `removed`). Two reporting problems existed: (1) only counts (and, in a verbose mode never used by `main`, the code *after* a pass) were shown — no before/after, no rule, no reason; (2) `rounds` includes the final round that changed nothing (so "3 rounds" means two productive rounds plus the confirming round). The new output prints the confirming round explicitly and says so in the summary.

---

## 2. The pipeline

```
IR (original TAC)
  │
  ▼  round r = 1 .. 10
  ├─ Pass 1  opt_fold        constants evaluated at compile time
  ├─ Pass 2  opt_propagate   known constants / copies substituted into later uses
  ├─ Pass 3  opt_simplify    algebraic identities
  ├─ Pass 4  opt_dead        unused temporaries deleted
  └─ if no pass changed anything this round → fixed point → stop
  │
  ▼
IR (optimized)  ──►  code generator
```

**Why this order.** Folding creates constants → propagation makes them visible in later instructions → simplification/folding exploit them → dead-code removal deletes the assignments that propagation left unused. Repeating lets effects cascade: after `t1` is propagated and removed, `t2 = 3 + 10` only becomes foldable *in the next round*.

**Why order matters (real example below).** In `(2 + 3) * 1 + 0`, after propagation the instruction is `t2 = 5 * 1`. Folding already ran this round, so **simplification** (`x * 1 → x`) rewrites it, not folding. Had simplification run before propagation it could not have matched at all.

---

## 3. How to read the printed output

For every pass in every round the program prints one line, or a block when something changed:

```
Pass N  <name>: K transformation(s)
   Before:   numbered TAC entering the pass
   Changes:  line L: <instruction before>   =>   <instruction after>
                     rule: <the rewrite rule applied>
                     why : <why it is valid for this instruction>
   After:    numbered TAC leaving the pass
```
A pass with nothing to do prints `no transformations (<what it looks for>)`. Line numbers are positions in the "Before" listing. All text is generated from the instruction actually examined (operand values, temp names) — nothing is a fixed message except the rule description for each identity.

---

## 4. Real output: `3 + 5 * 2`

*(real output; section 10 of `./mini_compiler --no-table "3 + 5 * 2"`)*
```
Pass order in every round: 1 folding -> 2 propagation -> 3 simplification -> 4 dead-temporary elimination.
Rounds repeat until one full round changes nothing (limit 10).
   Input TAC:
      1: t1 = 5 * 2
      2: t2 = 3 + t1

-- Round 1 --
Pass 1  Constant Folding: 1 transformation
   Before:
      1: t1 = 5 * 2
      2: t2 = 3 + t1
   Changes:
     line 1: t1 = 5 * 2   =>   t1 = 10
             rule: fold binary operation on two constants
             why : operands 5 and 2 are both constants, so the operation is evaluated now with the same arithmetic the target machine uses (32-bit wraparound for int, IEEE double for float)
   After:
      1: t1 = 10
      2: t2 = 3 + t1
Pass 2  Constant & Copy Propagation: 1 transformation
   Before:
      1: t1 = 10
      2: t2 = 3 + t1
   Changes:
     line 2: t2 = 3 + t1   =>   t2 = 3 + 10
             rule: constant propagation
             why : t1 was assigned the constant 10 and every temporary is assigned exactly once, so t1 still holds 10 at this use
   After:
      1: t1 = 10
      2: t2 = 3 + 10
Pass 3  Algebraic Simplification: no transformations (no identity pattern such as x+0, x*1, x&x found)
Pass 4  Dead Temporary Elimination: 1 transformation
   Before:
      1: t1 = 10
      2: t2 = 3 + 10
   Changes:
     line 1: t1 = 10   =>   (removed)
             rule: dead temporary elimination
             why : t1 is not read by any later instruction and is not the final result; the instruction has no side effect, so deleting it cannot change the result
   After:
      1: t2 = 3 + 10

-- Round 2 --
Pass 1  Constant Folding: 1 transformation
   Before:
      1: t2 = 3 + 10
   Changes:
     line 1: t2 = 3 + 10   =>   t2 = 13
             rule: fold binary operation on two constants
             why : operands 3 and 10 are both constants, so the operation is evaluated now with the same arithmetic the target machine uses (32-bit wraparound for int, IEEE double for float)
   After:
      1: t2 = 13
Pass 2  Constant & Copy Propagation: no transformations (no temporary currently holds a known constant or copy)
Pass 3  Algebraic Simplification: no transformations (no identity pattern such as x+0, x*1, x&x found)
Pass 4  Dead Temporary Elimination: no transformations (every temporary is used or is the final result)

-- Round 3 --
Pass 1  Constant Folding: no transformations (no instruction has only constant operands)
Pass 2  Constant & Copy Propagation: no transformations (no temporary currently holds a known constant or copy)
Pass 3  Algebraic Simplification: no transformations (no identity pattern such as x+0, x*1, x&x found)
Pass 4  Dead Temporary Elimination: no transformations (every temporary is used or is the final result)
Round 3 changed nothing: the code has reached a fixed point, so the optimizer stops.

--- Optimized TAC (this is what the target-code generator receives) ---
  t2 = 13                        [int]
  [folded=2 propagated=1 simplified=0 removed=1 | 2 -> 1 instructions | 3 rounds, the last one changed nothing]
```
Summary of what happened: round 1 folded `5 * 2`, propagated `t1` into `t2`, found nothing to simplify, removed `t1`; round 2 folded `3 + 10`; round 3 confirmed the fixed point. Counters: `folded=2 propagated=1 simplified=0 removed=1`, 2 → 1 instructions.

## 5. Real output: all four passes — `(2 + 3) * 1 + 0`

```
Pass order in every round: 1 folding -> 2 propagation -> 3 simplification -> 4 dead-temporary elimination.
Rounds repeat until one full round changes nothing (limit 10).
   Input TAC:
      1: t1 = 2 + 3
      2: t2 = t1 * 1
      3: t3 = t2 + 0

-- Round 1 --
Pass 1  Constant Folding: 1 transformation
   Before:
      1: t1 = 2 + 3
      2: t2 = t1 * 1
      3: t3 = t2 + 0
   Changes:
     line 1: t1 = 2 + 3   =>   t1 = 5
             rule: fold binary operation on two constants
             why : operands 2 and 3 are both constants, so the operation is evaluated now with the same arithmetic the target machine uses (32-bit wraparound for int, IEEE double for float)
   After:
      1: t1 = 5
      2: t2 = t1 * 1
      3: t3 = t2 + 0
Pass 2  Constant & Copy Propagation: 1 transformation
   Before:
      1: t1 = 5
      2: t2 = t1 * 1
      3: t3 = t2 + 0
   Changes:
     line 2: t2 = t1 * 1   =>   t2 = 5 * 1
             rule: constant propagation
             why : t1 was assigned the constant 5 and every temporary is assigned exactly once, so t1 still holds 5 at this use
   After:
      1: t1 = 5
      2: t2 = 5 * 1
      3: t3 = t2 + 0
Pass 3  Algebraic Simplification: 2 transformations
   Before:
      1: t1 = 5
      2: t2 = 5 * 1
      3: t3 = t2 + 0
   Changes:
     line 2: t2 = 5 * 1   =>   t2 = 5
             rule: x * 1  =>  x
             why : multiplying by 1 never changes a value
     line 3: t3 = t2 + 0   =>   t3 = t2
             rule: x + 0  =>  x
             why : adding integer 0 never changes a value
   After:
      1: t1 = 5
      2: t2 = 5
      3: t3 = t2
Pass 4  Dead Temporary Elimination: 1 transformation
   Before:
      1: t1 = 5
      2: t2 = 5
      3: t3 = t2
   Changes:
     line 1: t1 = 5   =>   (removed)
             rule: dead temporary elimination
             why : t1 is not read by any later instruction and is not the final result; the instruction has no side effect, so deleting it cannot change the result
   After:
      1: t2 = 5
      2: t3 = t2

-- Round 2 --
Pass 1  Constant Folding: no transformations (no instruction has only constant operands)
Pass 2  Constant & Copy Propagation: 1 transformation
   Before:
      1: t2 = 5
      2: t3 = t2
   Changes:
     line 2: t3 = t2   =>   t3 = 5
             rule: constant propagation
             why : t2 was assigned the constant 5 and every temporary is assigned exactly once, so t2 still holds 5 at this use
   After:
      1: t2 = 5
      2: t3 = 5
Pass 3  Algebraic Simplification: no transformations (no identity pattern such as x+0, x*1, x&x found)
Pass 4  Dead Temporary Elimination: 1 transformation
   Before:
      1: t2 = 5
      2: t3 = 5
   Changes:
     line 1: t2 = 5   =>   (removed)
             rule: dead temporary elimination
             why : t2 is not read by any later instruction and is not the final result; the instruction has no side effect, so deleting it cannot change the result
   After:
      1: t3 = 5

-- Round 3 --
Pass 1  Constant Folding: no transformations (no instruction has only constant operands)
Pass 2  Constant & Copy Propagation: no transformations (no temporary currently holds a known constant or copy)
Pass 3  Algebraic Simplification: no transformations (no identity pattern such as x+0, x*1, x&x found)
Pass 4  Dead Temporary Elimination: no transformations (every temporary is used or is the final result)
Round 3 changed nothing: the code has reached a fixed point, so the optimizer stops.

--- Optimized TAC (this is what the target-code generator receives) ---
  t3 = 5                         [int]
  [folded=1 propagated=2 simplified=2 removed=2 | 3 -> 1 instructions | 3 rounds, the last one changed nothing]
```
Note the **two** simplification changes in one pass, and that round 2 propagates `t2 = 5` into `t3 = t2` (a *copy* created by simplification; because `t2` holds a constant, it is reported as constant propagation).

## 6. Real output: int→float conversion — `(1 + 2) * 2.5`

Only the end of the pipeline is shown (full text: run the program):
```
  t3 = 7.5                       [float]
  [folded=3 propagated=2 simplified=0 removed=2 | 3 -> 1 instructions | 4 rounds, the last one changed nothing]
```
The `(float) t1` instruction was folded to the constant `3.0` in round 2 (*"fold unary operation on a constant"*), then `t3 = 3.0 * 2.5` folded to `7.5` in round 3.

---

## 7. Each pass in detail

### 7.1 Constant folding — `opt_fold`

**Algorithm.** For each instruction that is not an assign: if operand `a` is a constant (and, for binary, `b` too), call `ir_apply(op, type, a, b, &result)`. If it succeeds, `to_assign(c, result)` rewrites the instruction to `t = result`.
```c
if (c->form == F_ASSIGN || c->a.k != K_CONST) continue;
if (c->form == F_BINARY && c->b.k != K_CONST) continue;
if (ir_apply(c->op, c->type, c->a, c->b, &o)) { to_assign(c, o); n++; }
```
**Valid because** `ir_apply` is the same arithmetic the interpreter and the target machine use (32-bit wraparound ints, IEEE doubles). **Not applied** when `ir_apply` refuses: integer or float division by zero (the instruction stays, so the run-time behaviour is not silently changed). Example: `2147483647 + 1` folds to `-2147483648`; `8 / 0` stays `t1 = 8 / 0`.

### 7.2 Constant and copy propagation — `opt_propagate`

**Algorithm.** One top-down walk with `v[t]` = "value currently known for temp t" (a constant or another temp/var): when an instruction `t = X` (assign) is seen, remember `v[t] = X`; for every later instruction, replace each *use* of a temp that has a known value by that value. Each replacement counts one transformation.
```c
if (p[j]->k == K_TEMP && v[p[j]->t].k != K_NONE) { *p[j] = v[p[j]->t]; n++; }
```
**Valid because** every temp is assigned exactly once (`emit` always makes a new one), so its value cannot change between definition and use. The *defining* assignment is not removed here — that is dead-code elimination's job (Pass 4), which is why the two passes cooperate.

*Constant* propagation: `t1 = 10`, `t2 = t1 + 5` ⇒ `t2 = 10 + 5` (this exact shape appears in the real outputs above). *Copy* propagation: `t3 = t1`, `t4 = t3 + t2` ⇒ `t4 = t1 + t2` (*unit-test constructed*, the grammar cannot create a temp-to-temp copy that is used later).

### 7.3 Algebraic simplification — `opt_simplify`

**Algorithm.** For each **binary** instruction pick the rule by operator; if an operand is the identity element (`isc(b, 0)` …) or both operands are the same temp (`same(a, b)`), rewrite to `t = x` or `t = constant`. Every rule carries its own explanation text, printed in the "rule" / "why" lines.

| Rule | Condition | Why valid |
| --- | --- | --- |
| `x + 0`, `0 + x` ⇒ `x` | **int only** | integer zero never changes a value (not for float: `-0.0 + 0.0 = +0.0`) |
| `x - 0` ⇒ `x` | int, or float when the 0 is not `-0.0` | subtracting zero |
| `x - x` ⇒ `0` | **int only**, same temp both sides | an int minus itself (float: NaN/∞) |
| `x * 1`, `1 * x` ⇒ `x` | int or float | multiplying by 1 |
| `x * 0`, `0 * x` ⇒ `0` | **int only** | float would be wrong for NaN, ∞, −0.0 |
| `x / 1` ⇒ `x` | int or float | dividing by 1 |
| `x & 0`, `0 & x` ⇒ `0` | bitwise | clears all bits |
| `x & -1`, `-1 & x` ⇒ `x` | operand must be **int** | −1 has all bits set |
| `x & x` ⇒ `x`; `x \| x` ⇒ `x` | same temp, operand int | idempotent |
| `x \| -1`, `-1 \| x` ⇒ `-1` | bitwise | sets all bits |
| `x \| 0`, `0 \| x`, `x ^ 0`, `0 ^ x` ⇒ `x` | operand must be **int** | no bit changes |
| `x ^ x` ⇒ `0` | same temp | cancels |

Real occurrences: `x * 1` and `x + 0` in §5. *Unit-test constructed* (hand-built TAC, asserted by `test_opt.c`): `t2 = t1 - t1 ⇒ t2 = 0`, `t1 & t1 ⇒ t1`, `t1 | t1 ⇒ t1`, `t1 ^ t1 ⇒ 0`, and the negative cases: `(2.5+1.5)*0` and `(2.5*2.5)+0` are **not** simplified.

### 7.4 Dead (temporary) elimination — `opt_dead`

**Algorithm.** Backward scan with `live[t]`. The last instruction's result is live (it *is* the program result). For instruction *i* from last to first: if `live[res]` is false, delete the instruction (counted and logged); otherwise clear `live[res]` and mark its operand temps live.
```c
if (!live[c->res]) { ir_delete(ir, i); n++; continue; }
live[c->res] = 0;  if (c->a.k == K_TEMP) live[c->a.t] = 1;  if (binary && c->b.k == K_TEMP) live[c->b.t] = 1;
```
**Valid because** no instruction in this IR has an observable side effect (no memory write, call or I/O). *Distinction asked for in the requirements:* an instruction **whose result is unused** is removable; an instruction with an **observable effect** would not be — this IR has none, so the question never arises. One subtle consequence: a dead `t = x / 0` would also be removed, which removes a would-be run-time trap (`(8 / 0) * 0` becomes `0` after simplification). Division by zero is undefined behaviour in C as well, so this is accepted and documented as a limitation.

---

## 8. Why the whole expression collapses to one instruction

The language has only literal constants, so every temp is a compile-time constant and *folding + propagation + dead removal* evaluate the entire expression. That is expected, not a defect. It also means the code generator normally receives a single assignment — use `--no-opt` to see real code generation:
```

--- Target Code ---
   0: LOADI   R0, #1
   1: LOADI   R1, #2
   2: ADD     R0, R0, R1
   3: LOADI   R1, #3
   4: LOADI   R2, #4
   5: ADD     R1, R1, R2
   6: MUL     R0, R0, R1
   7: STORE   [RESULT], R0
   8: HALT    

Check: original TAC = 21 | TAC (not optimized) = 21 | target machine = 21 -> PASS
```
With `--opt-brief` the optimizer still runs but only the result is printed:
```

--- Optimized TAC (this is what the target-code generator receives) ---
  t2 = 13                        [int]
  [folded=2 propagated=1 simplified=0 removed=1 | 2 -> 1 instructions | 3 rounds, the last one changed nothing]
```

---

## 9. Bug found and fixed during this work

*Found by:* the randomized test in `test_opt.c` (3000 expressions with floats, fixed seed): **87 mismatches** before the fix, e.g. `(0.0) | ((1.0) * (1.0))` — original TAC and optimized TAC (via the interpreter) gave int `1`, but the target machine returned float `1`.

*Cause:* `opt_simplify` applied bitwise identities (`0 | x ⇒ x`, `x ^ 0 ⇒ x`, `x & x ⇒ x`, …) even when `x` was a **float** operand. A bitwise operator truncates floats to int, so the instruction is typed `int`; replacing it with `t = x` left a *float* value inside an *int* instruction. The interpreter re-truncated it (hiding the bug); the machine did not.

*Fix:* the operand-returning bitwise identities now require `operand.d == T_INT`. Constant-result identities (`x & 0 ⇒ 0`, `x | -1 ⇒ -1`, `x ^ x ⇒ 0`) are unaffected because their result is an int constant.

*Regression test:* `0 | 2.5` — `opt_simplify` must report 0 changes and the target machine must return **int 2**. After the fix the randomized test reports 0 mismatches.

---

## 10. Tests (all executed; results from this run)

`make test_opt && ./test_opt` — real output:
```
-- unit tests: each pass on its own --
-- randomized semantic check (fixed seed, 3000 expressions) --
  int only: 917 expressions run (2083 skipped), 0 mismatches
  int+float: 3000 expressions run (0 skipped), 0 mismatches

=== 36 checks passed, 0 failed ===
```
What is covered:

| Test | Checks |
| --- | --- |
| fold | `5 * 4 + 3`: exactly 1 change, `t1 = 20`, log entry content (`before`, `after`, line 1); second run finds nothing |
| propagate | `t2 = 20 + 3`, rule text "constant propagation"; copy propagation case (hand-built) |
| fold after propagate / dead | `t2 = 23`, `t1` removed, log says `(removed)`, value 23 preserved |
| simplify | `x*1`, `x+0` from the parser; `x-x`, `x&x`, `x\|x`, `x^x` hand-built; **negative** float cases |
| dead | removes only the unused temp; correct line number logged |
| edge | `8 / 0` not folded; single constant `7` untouched; full pipeline counters for `3 + 5 * 2` (`folded=2 propagated=1 simplified=0 removed=1`, 3 rounds, fixed point) |
| regression | `0 \| 2.5` stays `int` on the target machine |
| randomized (fixed seeds) | 3000 integer-only and 3000 int+float random expressions: original TAC = optimized TAC = target(optimized) = target(**unoptimized**, which exercises spilling), equal in **value and type** |

Additionally `./mini_compiler --quiet --demo` runs 9 valid expressions through the entire pipeline (each with its `Check:` line) and 3 invalid ones.

---

## 11. Known limitations

* No variables ⇒ every expression folds to one constant (language property).
* Division by zero is never folded; the interpreter yields 0 and the simulated machine leaves a register unchanged, so the `Check:` line reports FAIL for such input (`8 / 0`). `(8 / 0) * 0` optimizes to `0` (division removed as dead).
* Counters count transformations, not instructions; `rounds` includes the confirming round.
* `MAXIT = 10` is a safety limit; no test expression reaches it.
* Not implemented: code motion, strength reduction, CSE, peephole, loop optimizations, interprocedural anything.
* Float-specific folding follows C `double` arithmetic; no special handling for NaN/∞ beyond not simplifying risky identities.
