# Beginner's Complete Learning Guide

For someone who knows basic C but has not yet worked in a multi-file compiler. Read it in order; each part uses **this** project's code and **real** program output. Things marked *(illustrative)* are small examples written for teaching; things marked *(experiment)* were actually run on a scratch copy of the project while writing this guide.

Contents: 1. What happens when you run the program · 2. C files, header files, compiling and linking · 3. The whole pipeline for one expression · 4. The important data structures · 5. The important algorithms · 6. How to read and modify this codebase · 7. FAQ.

---

## 1. What happens when I run `./mini_compiler "3 + 5 * 2"`?

1. The shell starts the program; the C runtime calls `main(argc, argv)` in `main.c`. `argv[1]` is the text `3 + 5 * 2` (quotes keep it as one argument).
2. `main` reads flags (`--quiet`, `--demo`, …), then calls **`frontend_build`**: this loads the grammar and **generates the parsing table** — the heavy, once-per-run work (grammar → item sets → ACTION/GOTO → conflict check).
3. If the table has conflicts the program stops. Otherwise `run_one` is called for the expression: it **uses** the table to parse, then runs the later phases and prints 11 numbered sections.
4. `main` returns 0 (success) or 1 (a failure/rejection), which is what the shell sees in `$?`.

> **Key distinction.** *Generating* the parsing table happens once per program run and does not depend on the input. *Using* the table to parse happens once per expression.

---

## 2. C files, header files, compiling and linking

### 2.1 What is a `.c` file? A `.h` file? Are they the same?

They are both plain text; they differ in **role** (by convention, not by compiler rule).
* A **`.c` file** (translation unit) contains **definitions**: function bodies and variables that actually take space. Each `.c` is compiled separately into an object file. Example: `ir.c` contains the body of `ir_binary`.
* A **`.h` file** contains **declarations and type definitions**: *what exists* so other files can use it. Example: `ir.h` contains `void ir_print(const IR *ir, const char *title);` (declaration) and the `struct` types `Operand`, `TAC`, `IR`.

### 2.2 Declaration vs definition (examples from this project)

```c
/* ir.h  -- DECLARATION: "a function with this name and signature exists somewhere" */
Operand ir_binary(IR *ir, Op op, Operand l, Operand r, DType result);

/* ir.c  -- DEFINITION: the actual code */
Operand ir_binary(IR *ir, Op op, Operand l, Operand r, DType ty) {
    l = conv(ir, l, ty); r = conv(ir, r, ty);
    return emit(ir, op, F_BINARY, l, r, ty);
}

/* compiler.c -- USE: the compiler only needs the declaration to check the call is well-formed */
out = ir_binary(ir, OP_MUL, rhs[0], rhs[2], ir_promote(rhs[0].d, rhs[2].d));
```
Declarations go in headers because **many** files need them; the definition must exist **once**.

### 2.3 What does `#include` do? What is the preprocessor?

Before real compilation the **preprocessor** processes lines starting with `#`. `#include "ir.h"` is replaced by the **entire text** of `ir.h` — literally copy-paste. So after preprocessing, `compiler.c` contains the `Operand`, `TAC`, `IR` definitions and the `ir_*` declarations. `#define` makes text substitutions (e.g. `MAX_SYMBOLS 64`, `NREG 4`), `#ifndef/#define/#endif` do conditional inclusion.

### 2.4 Header guards

Every header in this project starts and ends like this:
```c
#ifndef IR_H
#define IR_H
   ...declarations...
#endif
```
`compiler.h` includes `ir.h`; `optimizer.h` also includes `ir.h`; `main.c` includes both. Without a guard, `ir.h` would be pasted twice into `main.c` and the compiler would complain about redeclarations (see the real error below). With the guard, the second paste is skipped because `IR_H` is already defined. *(experiment)* — removing the guard from a copy of `ir.h`:
```
In file included from optimizer.h:3,
                 from main.c:2:
ir.h:2:16: error: redeclaration of enumerator ‘T_INT’
    2 | typedef enum { T_INT, T_FLOAT } DType;
      |                ^~~~~
In file included from compiler.h:6,
```

### 2.5 Structures and enumerations — why this project needs them

* `struct` groups related data: `Token {type, int_value, float_value, lexeme, line, column}`, `TAC {op, form, a, b, res, type}`, `Grammar {symbols[], prods[], …}`. Passing one `struct` between phases is how phases communicate (see the table in the Source Code Reference).
* `enum` gives names to small integer sets: `TokenType`, `ActionType {ACTION_ERROR, ACTION_SHIFT, …}`, `Op {OP_ADD, …}`. Code like `if (a.type == ACTION_REDUCE)` is readable and checked by the compiler.

### 2.6 Sharing data between modules: `static`, `extern`, and what this project does

* A **global variable defined in a `.c` file** can be used in another `.c` only if the other file has an **`extern` declaration**: `extern int counter;` says "this exists elsewhere" (declaration); `int counter = 0;` in exactly one `.c` is the definition. *(illustrative)*
* **This project has no shared global variables.** Modules share data by passing pointers to structs as arguments (`compiler_parse(g, table, tokens, n, ir, hist, sum, verbose)`).
* `static` at file level means "private to this file": e.g. `static Target *T; static int occ[NREG], *last;` in `codegen.c`, `static ... VT[32]` in `ir.c`, and every helper function marked `static` (`scan` in `lexer.c`, `set_action` in `syntax_table.c`). These cannot clash with names in other files.

### 2.6b Compilation and linking

1. **Compilation** (`gcc -c ir.c -o ir.o`): preprocess → compile one `.c` into an **object file** `.o` of machine code with *unresolved references* (calls to functions it only saw declared).
2. **Linking** (`gcc main.o compiler.o … -o mini_compiler`): the linker joins all object files, matches each call to a definition, and produces the executable. A program with several `.c` files must be compiled to objects and **linked together** because each `.c` alone is incomplete.

The `Makefile`:
```make
OBJS = main.o compiler.o lexer.o grammar.o lr_items.o syntax_table.o reduction.o ir.o optimizer.o codegen.o
mini_compiler: $(OBJS)                         # link step
	$(CC) $(CFLAGS) -o $@ $(OBJS) $(LDLIBS)
%.o: %.c                                       # compile step: any X.o is made from X.c
	$(CC) $(CFLAGS) -c $< -o $@
```
`make` rebuilds only objects whose `.c` changed. **Caveat:** this rule does not know which headers each `.c` includes, so after editing a **header** run `make clean && make`. `build.bat` does the same job on Windows with one `gcc` command (no separate objects).

### 2.7 Linker errors, with real examples *(experiments on a scratch copy)*

**Undefined reference** — a function is declared and called but no linked object defines it (here `codegen.c` was left out of the link):
```
/usr/bin/ld: /tmp/cc9FB53H.o: in function `run_one':
main.c:(.text+0x8bc): undefined reference to `cg_generate'
/usr/bin/ld: main.c:(.text+0x8cb): undefined reference to `cg_print'
/usr/bin/ld: main.c:(.text+0x9a4): undefined reference to `cg_run'
```
Meaning: compilation succeeded (declarations existed), but the linker found no definition of `cg_generate`. Fix: add the missing file/object, or check the function name/spelling in the `.c`.

**Multiple definition** — the same name is defined in two objects. Typical cause: defining something *in a header* (so every `.c` that includes it gets its own copy). Here `int shared_counter = 0;` was added to `ir.h` (included by `ir.c`, `optimizer.c`, …):
```
/usr/bin/ld: compiler.o:(.bss+0x0): multiple definition of `shared_counter'; main.o:(.bss+0x0): first defined here
/usr/bin/ld: ir.o:(.bss+0x0): multiple definition of `shared_counter'; main.o:(.bss+0x0): first defined here
/usr/bin/ld: optimizer.o:(.bss+0x0): multiple definition of `shared_counter'; main.o:(.bss+0x0): first defined here
/usr/bin/ld: codegen.o:(.bss+0x0): multiple definition of `shared_counter'; main.o:(.bss+0x0): first defined here
collect2: error: ld returned 1 exit status
```
Fix: put only a declaration (`extern int shared_counter;`) in the header and the single definition in one `.c`; or make it `static`.

### 2.8 How to trace a function: header → definition → caller

Example: `slr_get_action`.
1. **Declaration** in `syntax_table.h`: `Action slr_get_action(const SLRTable *t, int state, int terminal);`
2. **Definition** in `syntax_table.c`: bounds checks, then `return t->action[state * t->num_symbols + terminal];`
3. **Callers**: `compiler.c` (`compiler_parse`), `main.c` (`print_table_report`), `test_slr.c`. Find them with `grep -n slr_get_action *.c`.

---

## 3. One expression through the whole compiler: `3 + 5 * 2`

### 3.0 What is done at program start (once)

| Step | Function (file) | Result |
| --- | --- | --- |
| Load grammar | `grammar_load_compiler` (`grammar.c`) | `Grammar` with 12 terminals + `$`, 7 non-terminals, 19 productions |
| Augment | `grammar_augment` (`grammar.c`) | adds `Expr'` and production 0 |
| FIRST/FOLLOW | `first_follow_compute` (`syntax_table.c`) | `SymSet` masks |
| LR(0) item sets | `lr_collection_build` (`lr_items.c`) | 33 states |
| ACTION/GOTO + conflict detection | `slr_build_tables` (`syntax_table.c`) | tables; 0 conflicts |

### 3.1 Phase 1–2: lexical analysis and token management
**Input:** the string. **Operation:** `lexer_tokenize` → `scan` loops. **Data structure:** `Token[]` (array in `run_one`). **Output:** (real)
```
Input: 3 + 5 * 2

#    Token                    Position
1    INTEGER(3)               1:1
2    PLUS                     1:3
3    INTEGER(5)               1:5
4    MULTIPLY                 1:7
5    INTEGER(2)               1:9
6    END_OF_INPUT             1:10
```
Passed on by: the array and its length `n` are handed to `compiler_parse`.

### 3.2 Phase 3: grammar and production rules
Not executed per expression — the grammar was loaded at startup (printed as section 2):
```
Terminals   : $ PLUS MINUS STAR SLASH AMP PIPE CARET TILDE LPAREN RPAREN INT_CONST FLOAT_CONST
Non-terminals: Expr Xor And Sum Term Unary Factor Expr'
Start symbol : Expr
Productions (0 = augmented):
  [ 0] Expr' -> Expr
  [ 1] Expr -> Expr PIPE Xor
  [ 2] Expr -> Xor
  [ 3] Xor -> Xor CARET And
  [ 4] Xor -> And
  [ 5] And -> And AMP Sum
  [ 6] And -> Sum
  [ 7] Sum -> Sum PLUS Term
  [ 8] Sum -> Sum MINUS Term
  [ 9] Sum -> Term
  [10] Term -> Term STAR Unary
  [11] Term -> Term SLASH Unary
  [12] Term -> Unary
  [13] Unary -> PLUS Unary
  [14] Unary -> MINUS Unary
  [15] Unary -> TILDE Unary
  [16] Unary -> Factor
  [17] Factor -> LPAREN Expr RPAREN
  [18] Factor -> INT_CONST
  [19] Factor -> FLOAT_CONST
```

### 3.3 Phase 4–5: LR items, SLR(1) table, conflict detection
Also done at startup. A real fragment (state 0, the start state) and the conflict verdict:
```
State 0:
  Kernel:
    Expr' -> . Expr
  Closure:
    Expr -> . Expr PIPE Xor
    Expr -> . Xor
    Xor -> . Xor CARET And
    Xor -> . And
    And -> . And AMP Sum
    And -> . Sum
    Sum -> . Sum PLUS Term
    Sum -> . Sum MINUS Term
    Sum -> . Term
    Term -> . Term STAR Unary
    Term -> . Term SLASH Unary
    Term -> . Unary
    Unary -> . PLUS Unary
    Unary -> . MINUS Unary
    Unary -> . TILDE Unary
    Unary -> . Factor
    Factor -> . LPAREN Expr RPAREN
    Factor -> . INT_CONST
    Factor -> . FLOAT_CONST
  Transitions:
    on PLUS         -> State 1
    on MINUS        -> State 2
    on TILDE        -> State 3
    on LPAREN       -> State 4
    on INT_CONST    -> State 5
    on FLOAT_CONST  -> State 6
    on Expr         -> State 7
    on Xor          -> State 8
    on And          -> State 9
    on Sum          -> State 10
    on Term         -> State 11
    on Unary        -> State 12
    on Factor       -> State 13
```
```
No conflicts: the grammar is SLR(1).

Shift/reduce conflicts: 0 | Reduce/reduce conflicts: 0 | Other: 0
Parsing table is CONFLICT-FREE (the grammar is SLR(1)).
```

### 3.4 Phase 6–7: shift-reduce parsing and reduction tracking
**Input:** `Token[]` + the table. **Operation:** `compiler_parse`: repeat { look up ACTION[state, token]; shift or reduce }. **Data structures:** `ParseStack` (state, symbol, value per cell), `ReductionHistory`. **Output:** the trace (section 6) — real:
```
Step  State  Parsing stack (state symbol state ...)         Remaining input                Action Description
-------------------------------------------------------------------------------------------------------------------------------------
1     0      0                                              3 + 5 * 2 $                    s5     SHIFT INT_CONST, push state 5
2     5      0 INT_CONST 5                                  + 5 * 2 $                      r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[0,Factor]=13
3     13     0 Factor 13                                    + 5 * 2 $                      r16    REDUCE Unary -> Factor : pop 1, GOTO[0,Unary]=12
4     12     0 Unary 12                                     + 5 * 2 $                      r12    REDUCE Term -> Unary : pop 1, GOTO[0,Term]=11
5     11     0 Term 11                                      + 5 * 2 $                      r9     REDUCE Sum -> Term : pop 1, GOTO[0,Sum]=10
6     10     0 Sum 10                                       + 5 * 2 $                      s21    SHIFT PLUS, push state 21
7     21     0 Sum 10 PLUS 21                               5 * 2 $                        s5     SHIFT INT_CONST, push state 5
8     5      0 Sum 10 PLUS 21 INT_CONST 5                   * 2 $                          r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[21,Factor]=13
9     13     0 Sum 10 PLUS 21 Factor 13                     * 2 $                          r16    REDUCE Unary -> Factor : pop 1, GOTO[21,Unary]=12
10    12     0 Sum 10 PLUS 21 Unary 12                      * 2 $                          r12    REDUCE Term -> Unary : pop 1, GOTO[21,Term]=29
11    29     0 Sum 10 PLUS 21 Term 29                       * 2 $                          s23    SHIFT STAR, push state 23
12    23     0 Sum 10 PLUS 21 Term 29 STAR 23               2 $                            s5     SHIFT INT_CONST, push state 5
13    5      0 Sum 10 PLUS 21 Term 29 STAR 23 INT_CONST 5   $                              r18    REDUCE Factor -> INT_CONST : pop 1, GOTO[23,Factor]=13
14    13     0 Sum 10 PLUS 21 Term 29 STAR 23 Factor 13     $                              r16    REDUCE Unary -> Factor : pop 1, GOTO[23,Unary]=31
15    31     0 Sum 10 PLUS 21 Term 29 STAR 23 Unary 31      $                              r10    REDUCE Term -> Term STAR Unary : pop 3, GOTO[21,Term]=29
16    29     0 Sum 10 PLUS 21 Term 29                       $                              r7     REDUCE Sum -> Sum PLUS Term : pop 3, GOTO[0,Sum]=10
17    10     0 Sum 10                                       $                              r6     REDUCE And -> Sum : pop 1, GOTO[0,And]=9
18    9      0 And 9                                        $                              r4     REDUCE Xor -> And : pop 1, GOTO[0,Xor]=8
19    8      0 Xor 8                                        $                              r2     REDUCE Expr -> Xor : pop 1, GOTO[0,Expr]=7
20    7      0 Expr 7                                       $                              acc    ACCEPT: input is a valid sentence of the grammar
```
and the reduction history, which records for each reduction the production and the stack change (excerpt of the two reductions that generated code):
```
#10 [r10] Term -> Term STAR Unary
     stack : 0 Sum 10 PLUS 21 Term 29 STAR 23 Unary 31   =>   0 Sum 10 PLUS 21 Term 29
     input : $ 
     emits : t1 = 5 * 2
#11 [r7] Sum -> Sum PLUS Term
     stack : 0 Sum 10 PLUS 21 Term 29   =>   0 Sum 10
     input : $ 
     emits : t2 = 3 + t1
```
How to read one trace line (step 2): *state 5 on top, remaining input `+ 5 * 2 $`; ACTION[5, PLUS] = `r18`; reduce `Factor → INT_CONST`: pop one cell, GOTO[0, Factor] = 13, push `Factor 13`.*

### 3.5 Phase 8–9: semantic processing and TAC generation
During each reduce the **semantic action** (`switch (pno)` in `compiler.c`) computes the value of the new non-terminal. Operator productions call `ir_binary`, which **emits TAC**. Output (real):
```
TAC emitted by semantic actions attached to reductions:
  reduction #10  Term -> Term STAR Unary    -> t1 = 5 * 2
  reduction #11  Sum -> Sum PLUS Term       -> t2 = 3 + t1

--- Generated TAC ---
  t1 = 5 * 2                     [int]
  t2 = 3 + t1                    [int]
```
Passed on by: `ParseSummary.result` (the final operand `t2`) and the `IR` (array of `TAC`); `main` calls `ir_finish`, then `ir_copy` to keep the original for comparison.

### 3.6 Phase 10: optimization
**Input:** the `IR`. **Operation:** `opt_run` runs fold → propagate → simplify → dead until nothing changes. **Output:** (real; the end of the printed pipeline — full detail in `Optimization_Walkthrough.md`)
```
--- Optimized TAC (this is what the target-code generator receives) ---
  t2 = 13                        [int]
  [folded=2 propagated=1 simplified=0 removed=1 | 2 -> 1 instructions | 3 rounds, the last one changed nothing]
```

### 3.7 Phase 11: target code generation
**Input:** the optimized `IR`. **Operation:** `cg_generate`. **Output** (real):
```

--- Target Code ---
   0: LOADI   R0, #13
   1: STORE   [RESULT], R0
   2: HALT    

Check: original TAC = 13 | optimized TAC = 13 | target machine = 13 -> PASS
```
Finally `main` runs the original TAC (`ir_eval`), the optimized TAC (`ir_eval`) and the machine code (`cg_run`) and prints whether the three results agree.

---

## 4. The important data structures

| Name | File | Holds | Created by | Read/modified by |
| --- | --- | --- | --- | --- |
| `Token` / `Token[2048]` | `lexer.h`, `main.c` | type, lexeme, value, position | `scan` / `lexer_tokenize` | `compiler_parse` |
| `Symbol`, `Production`, `Grammar` | `grammar.h` | symbol table, 19 productions (+ production 0) | `grammar_load_compiler`, `grammar_augment` | `lr_items.c`, `syntax_table.c`, `compiler.c` |
| `LRItem {prod,dot}`, `ItemSet` | `lr_items.h` | an item / a sorted set of items | `itemset_add`, `closure`, `goto` | `lr_collection_build`, `slr_build_tables` |
| `LRCollection` / `LRState` | `lr_items.h` | the 33 states and their transitions `next[X]` | `lr_collection_build` | `slr_build_tables`, printers |
| `FirstFollow` (`SymSet` bit masks) | `syntax_table.h` | FIRST, FOLLOW, nullable | `first_follow_compute` | `slr_build_tables` |
| `SLRTable` (`action[]`, `go[]`, `conflicts[]`) | `syntax_table.h` | the parsing table and conflict list | `slr_generate` | `slr_get_action/goto` (parser), `print_table_report` |
| `ParseStack`/`ParseEntry` | `compiler.c` | state, symbol, semantic value per cell | `compiler_parse` | `compiler_parse` only |
| `ParseSummary` | `compiler.h` | accepted?, counts, error info, result | `compiler_parse` | `main.c` |
| `ReductionHistory` | `reduction.h` | log of reductions | `reduction_add` | `main.c` prints |
| `Operand`, `TAC`, `IR` | `ir.h` | values and the instruction list | `ir_binary`, `ir_unary`, `ir_finish` | optimizer, codegen, evaluator |
| `OptLog`/`OptChange`, `OptStats` | `optimizer.h` | per-change record; counters | `opt_*` passes | `opt_run` printing, `main.c` |
| `Target`/`MInstr` | `codegen.h` | machine code | `cg_generate` | `cg_print`, `cg_run` |

How `action[]` is indexed: `action[state * num_symbols + terminal]`; the table is a flat array of `Action {type, value}`.

---

## 5. The important algorithms, step by step

Each: idea → why → implementation pointer → tiny example → limits. (The member study guides go deeper.)

### 5.1 Tokenization (`scan`, `lexer.c`)
*Idea:* walk the characters, grouping them into the longest valid token. *Implementation:* skip spaces; digits (and an optional `.` + digits) ⇒ number token; single characters ⇒ operator tokens; end ⇒ `$`. *Example:* `3.5+.5` → `FLOAT(3.5) PLUS FLOAT(.5) $`. *Limits:* no exponents or identifiers.

### 5.2 Grammar representation (`grammar.c`)
*Idea:* a grammar is data: symbols and productions. *Implementation:* arrays; symbol ids shared by terminals and non-terminals; production 0 = `Expr' → Expr`. *Example:* production 7 is `{lhs = Sum, rhs = [Sum, PLUS, Term]}`.

### 5.3 FIRST and FOLLOW (`first_follow_compute`)
*Idea:* FIRST(X) = what can start a string from X; FOLLOW(A) = what can come right after A. FOLLOW decides *when* the parser may reduce. *Implementation:* repeat the defining rules until nothing changes (a fixed point), with 64-bit masks. *Example:* `FOLLOW(Sum) = { $, PLUS, MINUS, AMP, PIPE, CARET, RPAREN }` — a `Sum` can be reduced when the next token is one of these, but **not** when it is `STAR` (then the `Term` must grow first).

### 5.4 LR(0) closure and GOTO (`lr_items.c`)
*Idea:* an item `A → α . β` says how far we are inside a rule. *Closure:* if the dot is before a non-terminal `B`, we may be at the start of any `B` rule, so add them. *GOTO(I, X):* move the dot over X, then close. *Example:* from state 0, GOTO on `INT_CONST` moves the dot in `Factor → . INT_CONST` ⇒ state 5 `Factor → INT_CONST .`.

### 5.5 Canonical collection (`lr_collection_build`)
*Idea:* find all item sets reachable by GOTO from state 0 — they are the DFA states. *Implementation:* a queue (the growing array); for each state and symbol compute GOTO; if the set already exists reuse it, else add a new state. *Result:* 33 states.

### 5.6 SLR(1) ACTION/GOTO construction (`slr_build_tables`)
*Idea:* turn each item into a table entry: dot before terminal ⇒ **shift**; dot at the end ⇒ **reduce on FOLLOW(lhs)**; `Expr' → Expr .` ⇒ **accept on `$`**; transition on a non-terminal ⇒ **GOTO**. Blank = error.

### 5.7 Conflict detection (`set_action`)
*Idea:* if a cell would receive two different actions, the grammar is not SLR(1). *Implementation:* keep the first, record `{type, state, lookahead, existing, conflicting}`. *Example:* `E → E PLUS E | ID` gives a shift/reduce conflict in state 4 on `PLUS` (real output in the Mahendra guide).

### 5.8 Shift-reduce parsing (`compiler_parse`)
*Idea:* a stack of (state, symbol, value). Table says shift or reduce. *Why a stack:* nested constructs (parentheses) need memory of *what was left open*. *Example:* the trace in §3.4.

### 5.9 Reduction tracking (`reduction.c`)
*Idea:* log every reduce. *Implementation:* one `ReductionRecord` per reduce, created in the reduce branch (so it cannot differ from actual parser behaviour).

### 5.10 Semantic processing and TAC generation
*Idea:* attach computation to productions; compute a value for each non-terminal from its children's values at reduce time. *Example:* `Term → Term STAR Unary` with values `5` and `2` ⇒ emit `t1 = 5 * 2`, value `t1`.

### 5.11 The optimizer (four passes)
*Folding:* evaluate constant operations (`5 * 2` ⇒ `10`). *Propagation:* replace uses of a temp that holds a known constant/copy. *Simplification:* identities like `x * 1 ⇒ x`. *Dead-temp elimination:* delete instructions whose result is never used. Repeat until nothing changes. *Why order matters:* propagation exposes new folds and unused definitions. See the Optimization Walkthrough.

### 5.12 Target code generation
*Idea:* map each TAC instruction to machine instructions using 4 registers; when more than 4 values are live, **spill** the one used furthest in the future to memory (`STORE [Tn]`) and reload later (`LOAD`). Real spilling example in `Sarvesh_Study_Guide.md`.

---

## 6. How to read and modify this codebase

| I want to… | Look at / change |
| --- | --- |
| **Change the grammar** | `grammar_load_compiler` in `grammar.c` (the `rules[][2]` array). Then update the `switch (pno)` in `compiler.c` (production numbers shift!). The table regenerates automatically; run it and check section 5 says conflict-free. |
| **Add a token type** | `lexer.h` (enum, before `TOK_TERMINAL_COUNT`), `lexer.c` (`scan` case, `NAMES[]`, `SYMBOLS[]`), `compiler.c` (`lexer_symbol_names[]`, same order), `grammar.c` (terminal + rule). |
| **Understand why an expression is accepted** | Run it: section 6 (trace) and 7 (reductions); follow each `ACTION[state, token]`. Cross-check with section 4's table. |
| **Trace a parsing conflict** | Section 5 gives state + lookahead + both actions. Look up that state in section 3 (items) — the two conflicting items are there. Remember conflicts are recorded in `set_action` (`syntax_table.c`). |
| **The reduction history looks wrong** | `compiler_parse` reduce branch (`reduction_add` call), `reduction.c`, `format_stack`. |
| **TAC is wrong** | Section 9 lists *which reduction emitted each instruction*; open the `case` for that production in `compiler.c`, then `ir_binary`/`ir_unary`/`conv` in `ir.c`. |
| **Optimization output is wrong** | Run with `--no-opt` to compare; section 10 names the pass and rule for every change — find the rule text in `optimizer.c`. `./test_opt` tests each pass alone. |
| **Target code is wrong** | Run `--no-opt`: if the `Check:` line passes there, the bug is in the optimizer; if it fails with and without, suspect TAC generation or `codegen.c`. Compare `ir_eval` (TAC) with `cg_run` (machine). |
| **Linker error** | "undefined reference to `f`": find where `f` is declared (`grep -n "f(" *.h`) and defined (`grep -n "^.* f(" *.c`); check the defining `.c` is in the build (`OBJS` in the Makefile / `build.bat`). "multiple definition of `x`": something is defined in a header or two `.c` files; make it `static` or move it. |
| **A header change has no effect** | The Makefile does not track headers: `make clean && make`. |

---

## 7. FAQ

**Why so many files? Why not one `.c`?** Each file has one job (lexer, table generator, parser…), can be understood and tested separately (`test_slr` links without the parser), and can be assigned to different people.

**Why are functions declared in headers but defined elsewhere?** So other files can call them (declaration) while the code lives once (definition). Compile time also stays low.

**Declaration vs definition?** See §2.2.

**Token vs grammar symbol?** A *token* is what the lexer produces (`TOK_MULTIPLY`, with text and position). A *grammar symbol* is a name in the grammar (`STAR`). `lexer_symbol_names[]` maps one to the other.

**Lexer vs parser?** Lexer: characters → tokens (words). Parser: tokens → structure/validity (grammar).

**Grammar vs parsing table?** The grammar is the human-written rules; the table is the machine form computed from it that tells the parser what to do for each (state, token).

**What is an LR item? What does the dot mean?** A production with a dot showing how much has been recognised: `Sum → Sum . PLUS Term` = "seen a Sum, expecting PLUS".

**What are FIRST and FOLLOW for?** FIRST: which tokens can start a construct; FOLLOW: which tokens can follow it — used to decide when to reduce.

**ACTION and GOTO?** ACTION[state, token] → shift/reduce/accept/error; GOTO[state, non-terminal] → next state after a reduce.

**What is a shift-reduce conflict?** A state where, for one lookahead, the table could both shift and reduce. This grammar has none; `--conflict-demo` shows real ones.

**Why is the parser stack necessary?** To remember what has been recognised but not yet reduced — essential for nesting like `((1+2)*3)`.

**What is a reduction?** Replacing the right-hand side of a production on top of the stack by its left-hand non-terminal.

**Why states *and* symbols on the stack?** States drive all decisions; symbols are kept for display/derivation (each state has a unique accessing symbol, so they are redundant for decisions).

**How does the parser know to accept?** In state 7 (`Expr' → Expr .`) with lookahead `$`, ACTION is `acc`.

**What is semantic processing?** Computing meaning (here: values/TAC) while parsing, by running code attached to productions at reduce time.

**Why is TAC useful? How does it differ from target code?** TAC is simple, machine-independent, with unlimited temporaries — good for optimization. Target code uses real registers/instructions of a machine.

**What exactly does the optimizer change?** Rewrites TAC instructions (folds, substitutes, simplifies, deletes). Each change is now printed with before/after/rule/reason.

**Why can pass order matter?** Passes create opportunities for each other; e.g. dead-code elimination does nothing until propagation has made a definition unused.

**What if an optimization can't be applied?** The pass reports "no transformations" and leaves the code unchanged.

**How does the compiler know which function runs first?** The C runtime calls `main`. In `main.c`, `main` → `frontend_build` → `run_one` → phases.

**What happens when I run the executable?** §1.

**How do compiler, linker, headers and sources fit together?** Headers are pasted into sources by the preprocessor; each source is compiled into an object file; the linker joins objects into the executable (§2).

**Why do the three evaluators agree?** They share `ir_apply`. The `Check:` line verifies it every run.

**Why does `8 / 0` print FAIL?** Division by zero cannot be evaluated; the interpreter returns 0, the simulated machine leaves a register unchanged. It is a documented limitation, not a parser error.

**Why is optimization output so long?** Because every pass of every round is shown. Use `--opt-brief` for a short summary or `--no-opt` to skip.

**What does `-lm` mean in the build?** Link the math library (`fabs`, `signbit` are used by the optimizer and checks).
