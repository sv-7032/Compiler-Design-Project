/* reduction.h -- reduction history. Knows nothing about stacks/tables: it just
 * stores formatted snapshots, so it can be unit-tested alone. */
#ifndef REDUCTION_H
#define REDUCTION_H
#include <stdio.h>

typedef struct {
    int   seq;              /* 1-based reduction sequence number */
    int   prod_no;
    char *production;       /* "S -> S + T"                      */
    char *stack_before;
    char *stack_after;
    char *remaining_input;
    char *action;           /* "r7"                              */
    char *emitted;          /* TAC emitted by this reduction's semantic action ("" if none) */
} ReductionRecord;

typedef struct { ReductionRecord *recs; int count, cap; } ReductionHistory;

void reduction_init(ReductionHistory *h);
void reduction_free(ReductionHistory *h);
int  reduction_add(ReductionHistory *h, int prod_no, const char *production,
                   const char *before, const char *after,
                   const char *input, const char *action);
int  reduction_set_emitted(ReductionHistory *h, const char *tac);   /* attaches to the latest record */
void reduction_print(const ReductionHistory *h, FILE *out);
void reduction_print_emitters(const ReductionHistory *h, FILE *out); /* only reductions that emitted TAC */

#endif
