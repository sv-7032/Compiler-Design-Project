/* test_opt.c -- optimizer tests: each pass alone, then a randomized end-to-end semantic check.
 *   make test_opt && ./test_opt        (add -v to print every failing/passing expression) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "compiler.h"
#include "optimizer.h"
#include "codegen.h"

static int pass_n, fail_n, verbose;
static Grammar G;
static SLRTable T;

#define CHECK(c, ...) do { if (c) pass_n++; else { fail_n++; printf("  [FAIL] "); printf(__VA_ARGS__); printf("  (line %d)\n", __LINE__); } } while (0)

static int parse_expr(const char *src, IR *ir)
{
    Token tk[512]; ReductionHistory h; ParseSummary s;
    size_t n = lexer_tokenize(src, tk, 512);
    int ok;
    ir_init(ir); reduction_init(&h);
    ok = compiler_parse(&G, &T, tk, (int)n, ir, &h, &s, 0);
    if (ok) ir_finish(ir, s.result);
    reduction_free(&h);
    return ok;
}

static const char *txt(const IR *ir, int i) { static char b[4][160]; static int k; k = (k + 1) & 3; ir_fmt_tac(&ir->code[i], b[k]); return b[k]; }
static double num(Operand o) { return o.d == T_INT ? (double)o.i : o.f; }
static int same_value(Operand a, Operand b) { return a.d == b.d && fabs(num(a) - num(b)) <= 1e-9 * (1 + fabs(num(a))); }

static Operand tmp(int id, DType d) { Operand o = {0}; o.k = K_TEMP; o.t = id; o.d = d; return o; }

static void unit_tests(void)
{
    IR ir; OptLog lg = {0}; Operand before, after; int k;
    puts("-- unit tests: each pass on its own --");

    CHECK(parse_expr("5 * 4 + 3", &ir) && ir.n == 2, "parse 5*4+3");
    before = ir_eval(&ir);
    k = opt_fold(&ir, &lg);
    CHECK(k == 1 && lg.n == 1, "fold: expected 1 change, got %d", k);
    CHECK(!strcmp(txt(&ir, 0), "t1 = 20") && !strcmp(txt(&ir, 1), "t2 = t1 + 3"), "fold result: %s ; %s", txt(&ir, 0), txt(&ir, 1));
    CHECK(!strcmp(lg.v[0].before, "t1 = 5 * 4") && !strcmp(lg.v[0].after, "t1 = 20") && lg.v[0].line == 1, "fold log entry");
    CHECK(opt_fold(&ir, NULL) == 0, "fold: second run must find nothing (t2 still has a temp operand)");
    opt_log_free(&lg);

    k = opt_propagate(&ir, &lg);
    CHECK(k == 1 && !strcmp(txt(&ir, 1), "t2 = 20 + 3") && !strcmp(lg.v[0].rule, "constant propagation"), "propagate: %s", txt(&ir, 1));
    opt_log_free(&lg);
    CHECK(opt_fold(&ir, NULL) == 1 && !strcmp(txt(&ir, 1), "t2 = 23"), "fold after propagate");
    k = opt_dead(&ir, &lg);
    CHECK(k == 1 && ir.n == 1 && !strcmp(txt(&ir, 0), "t2 = 23") && !strcmp(lg.v[0].after, "(removed)"), "dead: removed t1");
    opt_log_free(&lg);
    after = ir_eval(&ir);
    CHECK(same_value(before, after) && after.i == 23, "value preserved (23)");
    ir_free(&ir);

    CHECK(parse_expr("(2 + 3) * 1", &ir), "parse (2+3)*1");               /* t1 = 2+3 ; t2 = t1 * 1 */
    CHECK(opt_fold(&ir, NULL) == 1 && opt_simplify(&ir, &lg) == 1, "simplify x*1");
    CHECK(!strcmp(txt(&ir, 1), "t2 = t1") && !strcmp(lg.v[0].rule, "x * 1  =>  x"), "simplify: %s", txt(&ir, 1));
    opt_log_free(&lg); ir_free(&ir);

    CHECK(parse_expr("(2 * 3) + 0", &ir), "parse (2*3)+0");              /* t1 = 2*3 ; t2 = t1 + 0 */
    CHECK(opt_simplify(&ir, &lg) == 1 && !strcmp(txt(&ir, 1), "t2 = t1") && !strcmp(lg.v[0].rule, "x + 0  =>  x"), "simplify x+0");
    opt_log_free(&lg); ir_free(&ir);

    CHECK(parse_expr("(2 * 3) * 0", &ir) && opt_simplify(&ir, NULL) == 1 && !strcmp(txt(&ir, 1), "t2 = 0"), "simplify x*0 (int)");
    ir_free(&ir);
    CHECK(parse_expr("(2.5 + 1.5) * 0", &ir) && opt_fold(&ir, NULL) == 1 && opt_simplify(&ir, NULL) == 0, "x*0 must NOT be simplified for float (NaN/-0.0)");
    ir_free(&ir);
    CHECK(parse_expr("(2.5 * 2.5) + 0", &ir) && opt_simplify(&ir, NULL) == 0, "x+0 must NOT be simplified for float (-0.0 + 0.0 = +0.0)");
    ir_free(&ir);

    {   /* x-x, x&x, x|x, x^x need the SAME temporary on both sides: the grammar can't produce that, so build the TAC by hand */
        static const Op ops[4] = {OP_SUB, OP_AND, OP_OR, OP_XOR};
        static const char *want[4] = {"t2 = 0", "t2 = t1", "t2 = t1", "t2 = 0"};
        for (int i = 0; i < 4; i++) {
            Operand x;
            ir_init(&ir);
            x = ir_binary(&ir, OP_ADD, ir_int(2), ir_int(3), T_INT);
            ir_binary(&ir, ops[i], x, x, T_INT);
            before = ir_eval(&ir);
            CHECK(opt_simplify(&ir, NULL) == 1 && !strcmp(txt(&ir, 1), want[i]), "same-operand rule %d: %s", i, txt(&ir, 1));
            after = ir_eval(&ir);
            CHECK(same_value(before, after), "same-operand rule %d keeps the value", i);
            ir_free(&ir);
        }
    }

    {   /* copy propagation: t3 = t1 (copy), then t4 = t3 + t2 must read t1 */
        Operand t1, t2;
        ir_init(&ir);
        t1 = ir_binary(&ir, OP_ADD, ir_int(2), ir_int(3), T_INT);
        t2 = ir_binary(&ir, OP_MUL, t1, ir_int(4), T_INT);
        ir_finish(&ir, t1);                                    /* emits t3 = t1 */
        ir_binary(&ir, OP_ADD, tmp(3, T_INT), t2, T_INT);      /* t4 = t3 + t2 */
        before = ir_eval(&ir);
        CHECK(opt_propagate(&ir, &lg) == 1 && !strcmp(txt(&ir, 3), "t4 = t1 + t2") && !strcmp(lg.v[0].rule, "copy propagation"), "copy propagation: %s", txt(&ir, 3));
        after = ir_eval(&ir);
        CHECK(same_value(before, after), "copy propagation keeps the value");
        opt_log_free(&lg); ir_free(&ir);
    }

    {   /* dead code: unused temporaries removed, used ones kept */
        Operand a;
        ir_init(&ir);
        a = ir_binary(&ir, OP_ADD, ir_int(1), ir_int(2), T_INT);          /* t1 : used by t3 */
        ir_binary(&ir, OP_MUL, ir_int(3), ir_int(4), T_INT);              /* t2 : never used */
        ir_binary(&ir, OP_SUB, a, ir_int(1), T_INT);                      /* t3 : final result */
        CHECK(opt_dead(&ir, &lg) == 1 && ir.n == 2 && lg.v[0].line == 2 && !strcmp(lg.v[0].before, "t2 = 3 * 4"), "dead removes only t2");
        opt_log_free(&lg); ir_free(&ir);
    }

    {   /* regression: 0 | 2.5 is int 2 (bitwise truncates the float); returning the float operand would change the type */
        Target tg; Operand v;
        CHECK(parse_expr("0 | 2.5", &ir) && opt_simplify(&ir, NULL) == 0, "x|0 must not return a float operand");
        opt_run(&ir, 0); cg_generate(&ir, &tg); v = cg_run(&tg);
        CHECK(v.d == T_INT && v.i == 2, "0 | 2.5 on the target machine: got %g (%s)", num(v), v.d == T_INT ? "int" : "float");
        cg_free(&tg); ir_free(&ir);
    }
    CHECK(parse_expr("8 / 0", &ir) && opt_fold(&ir, NULL) == 0, "division by zero is never folded");
    ir_free(&ir);
    CHECK(parse_expr("7", &ir) && ir.n == 1 && opt_fold(&ir, NULL) == 0 && opt_dead(&ir, NULL) == 0, "single constant: nothing to optimize");
    ir_free(&ir);
    {   OptStats s; CHECK(parse_expr("3 + 5 * 2", &ir), "parse"); s = opt_run(&ir, 0);
        CHECK(s.folded == 2 && s.propagated == 1 && s.simplified == 0 && s.removed == 1 && s.rounds == 3 && s.fixed && s.before_n == 2 && s.after_n == 1,
              "pipeline stats for 3+5*2: f=%d p=%d s=%d d=%d rounds=%d", s.folded, s.propagated, s.simplified, s.removed, s.rounds);
        ir_free(&ir); }
}

/* ---- randomized end-to-end check: original TAC == optimized TAC == target machine ---- */
static unsigned rs = 12345;
static int rnd(int n) { rs = rs * 1103515245u + 12345u; return (int)((rs >> 16) % (unsigned)n); }

static void gen(char *out, int depth)
{
    static const char *ops[] = {"+", "-", "*", "&", "|", "^"};
    static const char *fl[] = {"0.5", "1.0", "2.5", "3.25", "0.0"};
    char a[200], b[200];
    int c = depth <= 0 ? rnd(2) : rnd(9);
    if (c == 0) sprintf(out, "%d", rnd(10) < 3 ? rnd(2) : rnd(10));
    else if (c == 1) sprintf(out, "%s", fl[rnd(5)]);
    else if (c <= 3) { gen(a, depth - 1); sprintf(out, "(%s)", a); }
    else if (c == 4) { gen(a, depth - 1); sprintf(out, "%c(%s)", "+-~"[rnd(3)], a); }
    else if (c == 5) { gen(a, depth - 1); sprintf(out, "(%s) / %d", a, 1 + rnd(9)); }
    else { gen(a, depth - 1); gen(b, depth - 1); sprintf(out, "(%s) %s (%s)", a, ops[rnd(6)], b); }
}

static void fuzz(int count, int allow_float)
{
    int bad = 0, skipped = 0, ran = 0;
    for (int i = 0; i < count; i++) {
        char src[1200]; IR o, p; Target t, t0; Operand v0, v1, v2, v3; int has_float = 0;
        gen(src, 3);
        has_float = strchr(src, '.') != NULL;
        if (has_float && !allow_float) { skipped++; continue; }
        if (!parse_expr(src, &o)) { CHECK(0, "valid-by-construction expression rejected: %s", src); continue; }
        ir_copy(&p, &o);
        opt_run(&p, 0);
        cg_generate(&p, &t); cg_generate(&o, &t0);       /* t0: target code from the UNoptimized TAC (exercises registers and spills) */
        v0 = ir_eval(&o); v1 = ir_eval(&p); v2 = cg_run(&t); v3 = cg_run(&t0);
        ran++;
        if (!same_value(v0, v1) || !same_value(v0, v2) || !same_value(v0, v3)) {
            bad++;
            if (bad <= 5) printf("  mismatch: %s\n    original=%.9g(%s) optimized=%.9g(%s) target=%.9g(%s) target-no-opt=%.9g(%s)\n", src,
                num(v0), v0.d == T_INT ? "int" : "float", num(v1), v1.d == T_INT ? "int" : "float", num(v2), v2.d == T_INT ? "int" : "float", num(v3), v3.d == T_INT ? "int" : "float");
        }
        ir_free(&o); ir_free(&p); cg_free(&t); cg_free(&t0);
    }
    CHECK(bad == 0, "%s: %d of %d random expressions disagree between original TAC, optimized TAC and target machine", allow_float ? "with floats" : "integers only", bad, ran);
    printf("  %s: %d expressions run (%d skipped), %d mismatches\n", allow_float ? "int+float" : "int only", ran, skipped, bad);
}

int main(int argc, char **argv)
{
    verbose = argc > 1 && !strcmp(argv[1], "-v");
    if (grammar_load_compiler(&G) || slr_generate(&T, &G) || !slr_is_slr1(&T)) { puts("cannot build parser"); return 2; }
    unit_tests();
    puts("-- randomized semantic check (fixed seed, 3000 expressions) --");
    fuzz(3000, 0);
    rs = 777; fuzz(3000, 1);
    printf("\n=== %d checks passed, %d failed ===\n", pass_n, fail_n);
    (void)verbose;
    slr_free(&T);
    return fail_n ? 1 : 0;
}
